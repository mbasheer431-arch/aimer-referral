# AIMER Ambassador Program

Referral and ambassador platform for AIMER Business School. Partners register, get a personal link, and track referrals, rewards and payouts. AIMER teams manage partners, leads, admissions, incentives and payouts by role. Every student registration is sent to LeadSquared.

Full requirements and architecture: https://claude.ai/artifact/1DNNxTqhF8yH51cNmYx7DM (a shared document; ask for access if you cannot open it).

## What is in this repository

| Folder | What it holds |
| --- | --- |
| `site/` | What is published: `index.html` (the whole web app), `config.js` (connection details), `_redirects` |
| `app/` | The source of the web app, in small files. `sh app/build.sh` builds them into `site/index.html` |
| `supabase/migrations/` | The database, in numbered files 001 to 018. All are already applied to the live project |
| `supabase/functions/` | The five server functions: `submit-referral`, `register`, `lsq-webhook`, `admin-partners`, `lsq-admin` |
| `docs/` | `launch-checklist.md` (start here), the LeadSquared field mapping, capacity notes, and backup and restore |
| `scripts/` | `backup.sh`, the encrypted database backup used by the nightly workflow |
| `tests/` | Automated tests (252 checks). See `tests/README.md` |

Hosting: the site on Netlify, the backend on Supabase (project `ymkajhoxwhkgznyklwtt`, Mumbai), leads in LeadSquared.

## Deploy through GitHub and Netlify

1. Create a **private** GitHub repository and push this folder to it. The repository holds no secrets.
2. In Netlify, choose **Add new site, Import an existing project, GitHub**, and pick the repository.
3. Leave the build command empty. The publish directory is `site`; `netlify.toml` sets it for you.
4. Deploy. Every push to `main` now publishes the site automatically.
5. In Supabase, open Authentication, URL Configuration, set the Site URL to your Netlify address, and add it to Redirect URLs.

Pull requests get a Netlify preview address. Previews use the same live Supabase project, so anything created in a preview is real data. Use a test partner account.

### Final address: referral.aimerbschool.com
The app is set up for `https://referral.aimerbschool.com` (`siteUrl` in `site/config.js`). Add the domain in Netlify (Domain management, Add a domain) and one DNS record where `aimerbschool.com` is managed: a **CNAME** named `referral` pointing to your Netlify site address. Netlify shows the exact value and turns on HTTPS by itself. Do this **before** sharing any referral link, because every link and QR code is built on that address.

**Follow `docs/launch-checklist.md` in order.** It lists every Supabase and LeadSquared setting that has to match this address.

## Making changes

**Web app.** Edit the files in `app/`, run `sh app/build.sh`, and commit both the changed source and the rebuilt `site/index.html`. The check on every push fails if `site/index.html` does not match the sources.

**Database.** Add a new numbered file in `supabase/migrations/` (for example `016_...sql`) and apply it to the live project, either in the Supabase SQL editor or with the Supabase CLI. Never edit or re-run the old files; the live database already has them.

**Server functions.** Edit the file, then deploy it with the Supabase CLI:

    supabase functions deploy submit-referral --no-verify-jwt --project-ref ymkajhoxwhkgznyklwtt
    supabase functions deploy register --no-verify-jwt --project-ref ymkajhoxwhkgznyklwtt
    supabase functions deploy lsq-webhook --no-verify-jwt --project-ref ymkajhoxwhkgznyklwtt
    supabase functions deploy admin-partners --project-ref ymkajhoxwhkgznyklwtt
    supabase functions deploy lsq-admin --project-ref ymkajhoxwhkgznyklwtt

`submit-referral`, `register` and `lsq-webhook` are called by people who are not signed in, and by LeadSquared, so they run without a login check. The other two check the caller's admin role themselves.

## Secrets: what goes where

- **Never commit:** the LeadSquared keys, the webhook secret, or the Supabase service key.
- **Supabase, Edge Functions, Secrets:** `LSQ_API_HOST`, `LSQ_ACCESS_KEY`, `LSQ_SECRET_KEY`, `LSQ_WEBHOOK_SECRET`, `ALLOWED_ORIGIN` (comma-separated addresses allowed to call the functions), `SITE_URL`.
- **`site/config.js`:** the project address and the public (anon) key. These are meant to be public. The database rules protect the data.
- **Bank account numbers:** encrypted in the database with a key kept in Supabase Vault.

## Sign-up speed: instant registration

By default a new partner is created by the `register` function as an already-verified account, so signing up never waits on an email. The app then signs them in. If `register` is unavailable the app falls back to the normal email-link route by itself. Super Admin can switch to the email-link route in Integrations & Settings ("Require email confirmation at sign-up"); that needs a working email sender in Supabase.

Because no email is sent, nobody proves they own the address they register with. The function limits attempts (generously per network, tighter per email and per mobile number) and ignores a hidden bot-trap field. Payouts still need bank details and Finance and Management approval. Password reset is still done by email, so it still needs a working email sender.

## Backups

A nightly encrypted backup runs from GitHub (`.github/workflows/backup.yml`). Setup and the restore steps are in `docs/backup-and-restore.md`. Save the bank encryption key in your password manager first; no backup contains it.

## Checks

GitHub Actions (`.github/workflows/ci.yml`) rebuilds the site from `app/` and runs the tests on every push and pull request. It has not yet run on GitHub itself; the same steps pass locally. Protect the `main` branch so a change cannot merge while the check is failing.
