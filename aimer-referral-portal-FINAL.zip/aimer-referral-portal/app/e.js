/* ---------- public pages ---------- */
const COUNTRIES=['India','United Arab Emirates','Qatar','Saudi Arabia','Oman','Kuwait','Bahrain'];
const MKC_INST=['Markaz Knowledge City','Markaz Garden School','Markaz Law College','Markaz Unani Medical College','Other MKC institution'];
const newJ=()=>({step:'account',d:{cat:'Student',sprog:'',aprog:'',inst:MKC_INST[0],acountry:'India',country:'India'},err:'',adding:false,busy:false});
const newL=()=>({step:'form',d:{},err:'',last:null});
let J=newJ(),L=newL(),F={step:'id',err:'',email:''};
const fv=(o,k)=>esc(o.d[k]||'');
const isEmail=e=>/^\S+@\S+\.\S+$/.test(e);
const catalogCourses=()=>((S.catalog||{}).courses||[]);
const progOptions=()=>{const c=catalogCourses().map(x=>x.code);return c.length?c:PROGS};
function vLanding(){
  const cat=S.catalog||{courses:[],show_rates:true},cs=cat.courses||[],showRates=cat.show_rates&&cs.length;
  const reg=(cls='primary')=>`<button class="btn ${cls}" data-act="goto" data-v="join">REGISTER NOW ${icon('userplus')}</button>`;
  const why=[['coins','Attractive referral incentives'],['link','Unique referral link'],['home','Personalised ambassador dashboard'],['pulse','Referral and admission tracking']];
  const steps=['Register as an Ambassador.','Get your account verified.','Share your referral link.','Track admissions and earn rewards.'];
  const range=c=>{const r=(c.rates||[]).filter(x=>x>0);return r.length?`${money(Math.min(...r))}–${money(Math.max(...r))}`:'Coming soon'};
  return `${hero('Earn More from Your Network.<span class="subline">Help Students Build the Right Skills and Shape Their Future Careers.</span>','Connect aspiring students with the right educational opportunities at AIMER Business School while earning attractive referral incentives.',`${reg()}<button class="btn" data-act="goto" data-v="login">Partner login</button>`,'AIMER AMBASSADOR PROGRAM')}
  <h2 class="mt2" style="font-size:26px">Why Join?</h2>
  <div class="grid g4 mt whyjoin">${why.map(([ic,t])=>`<div class="card why"><span class="wi">${icon(ic)}</span><h3>${t}</h3></div>`).join('')}</div>
  <div class="row mt" style="justify-content:center">${reg()}</div>
  ${showRates?`<h2 class="mt2" style="font-size:26px">Referral Incentives</h2>
  <div class="card mt"><div class="tbl"><table><thead><tr><th>Programme</th><th class="num">Incentive Range</th></tr></thead><tbody>${cs.map(c=>`<tr><td><strong>${esc(c.name)}</strong></td><td class="num"><strong>${range(c)}</strong></td></tr>`).join('')}</tbody></table></div>
  <p class="small muted" style="margin:12px 0 0">Based on successful admissions and applicable referral slabs.</p></div>
  <div class="row mt" style="justify-content:center">${reg()}</div>`:''}
  <h2 class="mt2" style="font-size:26px">How It Works</h2>
  <div class="grid g4 mt howto">${steps.map((t,i)=>`<div class="card"><span class="n">${i+1}</span><p style="margin:0;font-size:16px;font-weight:500">${t}</p></div>`).join('')}</div>
  <div class="card mt2 row" style="justify-content:space-between"><div><h3 style="font-size:18px">Are you a student or a parent?</h3><p class="muted" style="margin:4px 0 0">Register your interest in AIMER Business School and our admissions team will get in touch.</p></div><button class="btn" data-act="goto" data-v="enquire">Student registration</button></div>
  <section class="joinband mt2"><div><h2>Join the AIMER Network</h2><p>Turn your connections into opportunities and make a meaningful impact on students’ careers.</p></div><div>${reg('on-band')}</div></section>
  <p class="small muted" style="text-align:center;margin:20px 0 0">Terms and conditions apply. Incentives are subject to AIMER’s official referral policy.</p>
  <div class="stickyspace"></div><div class="stickycta"><button class="btn primary" data-act="goto" data-v="join">REGISTER NOW</button></div>`;
}
function vLogin(){return `<div class="authbox"><div class="card"><p class="stepno">Ambassador portal</p><h1 style="font-size:28px">Partner login</h1><p class="muted" style="margin:6px 0 0">Use the email and password you registered with.</p>
  ${S.ui.notice?`<div class="notice info" style="margin-top:14px">${esc(S.ui.notice)}</div>`:''}
  <label class="field">Email<input id="li-id" type="email" autocomplete="username" value="${esc(S.ui.lemail||'')}"></label><label class="field">Password<input id="li-pw" type="password" autocomplete="current-password"></label>
  <p class="err" role="alert">${esc(S.ui.lerr||'')}</p><button class="btn primary wide" data-act="plogin">Log in</button>
  <div class="row mt" style="justify-content:space-between"><button class="linkbtn" data-act="goto" data-v="forgot">Forgot password?</button><button class="linkbtn" data-act="goto" data-v="join">New partner? Register</button></div></div></div>`}
function vAdminLogin(){return `<div class="authbox"><div class="card"><p class="stepno">AIMER team</p><h1 style="font-size:28px">Admin login</h1><p class="muted" style="margin:6px 0 0">For Super Admin, Marketing, Admissions, Finance, Management, Support and Event admins. Each account only sees its own tools.</p>
  <label class="field">Work email<input id="ad-id" type="email" autocomplete="username"></label><label class="field">Password<input id="ad-pw" type="password" autocomplete="current-password"></label>
  <p class="err" role="alert">${esc(S.ui.aerr||'')}</p><button class="btn primary wide" data-act="alogin">Log in</button><div class="row mt" style="justify-content:flex-end"><button class="linkbtn" data-act="goto" data-v="forgot">Forgot password?</button></div></div></div>`}
function vForgot(){const err=`<p class="err" role="alert">${esc(F.err)}</p>`;
  return `<div class="authbox"><div class="card"><h1 style="font-size:28px">Reset your password</h1>${F.step==='sent'
    ?`<div class="success-ico" style="margin-top:14px">${icon('mail')}</div><p class="muted" style="margin:0">If an account exists for <strong>${esc(F.email)}</strong>, we’ve sent a link to choose a new password. It can take a minute to arrive. Check your spam folder too, and if it still hasn’t come after ten minutes, contact the AIMER team.</p>`
    :`<p class="muted" style="margin:6px 0 0">Enter your email and we’ll send you a link to choose a new password.</p><label class="field">Email<input id="fg-id" type="email" autocomplete="username"></label>${err}<button class="btn primary wide" data-act="fsend">Send reset link</button>`}
  <button class="linkbtn mt" data-act="goto" data-v="login">Back to login</button></div></div>`}
function vSetPw(){const err=`<p class="err" role="alert">${esc(S.ui.perr||'')}</p>`;
  return `<div class="authbox"><div class="card"><p class="stepno">${S.ui.pwKind==='invite'?'Welcome to AIMER':'Almost done'}</p><h1 style="font-size:28px">Choose a password</h1><p class="muted" style="margin:6px 0 0">Use at least 8 characters. You’ll use it with your email to log in.</p>
  <label class="field">New password<input id="sp-pw" type="password" autocomplete="new-password"></label><label class="field">Confirm password<input id="sp-pw2" type="password" autocomplete="new-password"></label>${err}<button class="btn primary wide" data-act="setpw">Save password and continue</button></div></div>`}
const NOTE_LABEL={Student:'Student ID (optional)',Employee:'Employee ID (optional)',Alumni:'Year of graduation (optional)','MKC Network':'Institution (optional)',Ambassador:'City (optional)'};
const empDomains=()=>((S.catalog&&S.catalog.employee_domains)||[]).map(d=>'name@'+d);
const CC_LIST=[['+91','India'],['+971','UAE'],['+974','Qatar'],['+966','Saudi Arabia'],['+968','Oman'],['+965','Kuwait'],['+973','Bahrain'],['+44','UK'],['+1','US / Canada'],['+65','Singapore'],['+60','Malaysia']];
const CC_OF={India:'+91','United Arab Emirates':'+971',Qatar:'+974','Saudi Arabia':'+966',Oman:'+968',Kuwait:'+965',Bahrain:'+973'};
// Flexible mobile numbers: the person picks a country code and types the number any way they like (spaces, a leading 0, or the full number with + or 00).
function composePhone(cc,raw){let s=String(raw||'').replace(/[^\d+]/g,'');if(!s)return '';if(s.startsWith('+'))return '+'+s.replace(/\D/g,'');if(s.startsWith('00'))return '+'+s.slice(2);
  const code=String(cc||'').replace(/\D/g,''),d=s.replace(/^0+/,'');if(code&&d.startsWith(code)){const rest=d.length-code.length;if(code==='91'?rest===10:rest>=7&&rest<=10)return '+'+d}return '+'+code+d}
const phoneField=(label,p,o,country)=>{const cc=o.d.cc||CC_OF[country]||'+91';return `<div class="field" style="flex:1.5;min-width:240px"><label for="${p}-phone">${label}</label><div class="phonerow"><select id="${p}-cc" aria-label="Country code">${CC_LIST.map(([c,n])=>`<option value="${c}" ${c===cc?'selected':''}>${c} ${n}</option>`).join('')}</select><input id="${p}-phone" value="${fv(o,'phone')}" inputmode="tel" placeholder="50 123 4567" autocomplete="tel-national"></div></div>`};
const empNote=c=>c==='Employee'?`<p class="small muted" style="margin:8px 0 0">Employees sign up with their official AIMER email${empDomains().length?', '+empDomains().join(' or '):''}. Not AIMER staff? Choose another category.</p>`:'';
const catTiles=(c,p)=>`<div class="types" role="radiogroup" aria-label="I am a">${CATS.map(x=>`<label class="type"><input type="radio" name="jcat" value="${x}" data-change="jcat" ${x===c?'checked':''}${p&&p.affs.includes(x)?' disabled':''}><b>${x}</b><span>${p&&p.affs.includes(x)?'Already on your account':CAT_INFO[x]}</span></label>`).join('')}</div>`;
function vJoin(){
  const err=`<p class="err" role="alert">${esc(J.err)}</p>`,needPhone=!S.catalog||S.catalog.require_phone_otp!==false;
  if(J.step==='account')return `<div class="narrow"><div class="card">${(S.catalog&&S.catalog.email_confirmation_required?2:1)+(needPhone?1:0)>1?`<p class="stepno">Step 1 of ${(S.catalog&&S.catalog.email_confirmation_required?2:1)+(needPhone?1:0)}</p>`:''}<h1 style="font-size:26px">Join the AIMER Ambassador Program</h1>
    <label class="field">Full name<input id="j-name" value="${fv(J,'name')}" autocomplete="name"></label>
    <div class="formrow" style="margin-top:0">${phoneField('Mobile number','j',J,J.d.country||'India')}<label class="field">Email<input id="j-email" type="email" value="${fv(J,'email')}" autocomplete="email"></label></div>
    <label class="field">Country<select id="j-country">${opt(COUNTRIES,J.d.country||'India')}</select></label>
    <div class="field" style="margin-top:14px">I am a ${catTiles(J.d.cat)}${empNote(J.d.cat)}</div>
    <label class="field">${NOTE_LABEL[J.d.cat]}<input id="j-note" value="${fv(J,'note')}" autocomplete="off"></label>
    <div class="formrow" style="margin-top:0"><label class="field">Create a password<input id="j-pw" type="password" autocomplete="new-password" value="${fv(J,'pw')}"></label><label class="field">Confirm password<input id="j-pw2" type="password" autocomplete="new-password" value="${fv(J,'pw2')}"></label></div>
    <p class="small muted" style="margin:6px 0 0">At least 8 characters. You’ll log in with your email and this password.</p>
    <label class="check"><input type="checkbox" id="j-terms" ${J.d.terms?'checked':''}><span>I agree to the AIMER Ambassador Program terms and privacy notice, including how my referral link is tracked.</span></label>
    ${err}<button class="btn primary wide" data-act="jsend" ${J.busy?'disabled':''}>${J.busy?esc(J.busyMsg||'Creating your account…'):'Create my account'}</button>
    <div class="row mt" style="justify-content:space-between"><span class="small muted">${S.catalog&&S.catalog.email_confirmation_required?`You’re verified automatically once your email${needPhone?' and mobile number are':' is'} confirmed.`:`Your account is ready the moment you submit. No email link to wait for${needPhone?', then a code to your mobile':''}.`}</span><button class="linkbtn" data-act="goto" data-v="login">Already registered? Log in</button></div></div></div>`;
  if(J.step==='confirm')return `<div class="narrow"><div class="card"><div class="success-ico">${icon('mail')}</div><h1 style="font-size:26px">Check your email</h1>
    <p class="muted" style="margin:6px 0 0">We sent a confirmation link to <strong>${fv(J,'email')}</strong>. Open it to confirm your address${needPhone?', then confirm your mobile number with a code and you’re in':' and you’re in'}.</p>
    <p class="small muted">Nothing in your inbox after a few minutes? Check spam, or <button class="linkbtn" data-act="jresend">send it again</button>.</p>${err}
    <div class="row mt"><button class="btn" data-act="goto" data-v="login">I’ve confirmed. Log in</button></div></div></div>`;
  if(J.step==='phone'){const p=person(meId());if(!p)return `<div class="narrow"><div class="card empty">Loading…</div></div>`;
    return `<div class="narrow"><div class="card"><p class="stepno">Step 3 of 3</p><h1 style="font-size:26px">Verify your mobile number</h1>
    <p class="muted" style="margin:6px 0 0">We’ll text a 6-digit code to <strong>${esc(p.phone)}</strong>.</p>
    ${J.codeSent?`<label class="field">Verification code<input id="j-code" class="otp" inputmode="numeric" maxlength="6" autocomplete="one-time-code"></label>${err}<div class="row mt"><button class="btn" data-act="jphonesend">Send again</button><button class="btn primary" data-act="jphoneverify">Verify</button></div>`
      :`${err}<button class="btn primary wide" data-act="jphonesend">Send code</button>`}</div></div>`}
  if(J.step==='category'){const p=person(meId())||{affs:[]},c=J.d.cat;
    return `<div class="narrow"><div class="notice info">Adding a category to your account. <button class="linkbtn" data-act="goto" data-v="profile">Cancel</button></div><div class="card"><h1 style="font-size:26px">Add a category</h1>
    <div class="field" style="margin-top:14px">I am also a ${catTiles(c,p)}</div><label class="field">${NOTE_LABEL[c]}<input id="j-note" value="${fv(J,'note')}" autocomplete="off"></label>${err}<button class="btn primary wide" data-act="jcatgo" ${J.busy?'disabled':''}>${J.busy?'Saving…':'Add category'}</button></div></div>`}
  const p=person(meId()),ok=p&&p.status==='VERIFIED';
  return `<div class="narrow"><div class="card"><div class="success-ico">${icon(ok?'check':'pulse')}</div><h1 style="font-size:26px">${ok?`You’re verified, ${esc(firstName(p))}`:'Almost there'}</h1>
  <p class="muted" style="margin:6px 0 16px">${ok?'Your referral link is ready. Students don’t need an account to register through it.':'We’re finishing your verification. Refresh in a moment.'}</p>
  ${ok?`<div class="linkfield">${icon('link')}<span>${esc(linkFor(p))}</span></div><p class="small muted">Your code: <strong>${p.code}</strong></p>`:''}
  <button class="btn primary mt" data-act="jdash">Open my dashboard</button></div></div>`;
}
function leadForm(mode){
  const pub=S.pub||{},list=(pub.courses&&pub.courses.length?pub.courses:catalogCourses()).map(c=>({code:c.code,name:c.name})),cur=L.d.prog||pub.course||(list[0]||{}).code,withCode=mode==='code',prev=!!pub.preview;
  if(!list.length)return `<div class="card empty">Enquiries aren’t open right now. Please check back soon.</div>`;
  return `<div class="card"><label class="field" style="margin-top:0">Programme<select id="l-prog">${list.map(c=>`<option value="${esc(c.code)}" ${c.code===cur?'selected':''}>${esc(c.name)}</option>`).join('')}</select></label>
  <label class="field" style="margin-top:12px">Student’s full name<input id="l-name" value="${fv(L,'name')}" autocomplete="off"></label>
  <div class="formrow">${phoneField('Parent or contact WhatsApp number','l',L,L.d.country||'United Arab Emirates')}<label class="field">Email (optional)<input id="l-email" type="email" value="${fv(L,'email')}" autocomplete="email"></label></div>
  <div class="formrow"><label class="field">Country<select id="l-country">${opt(COUNTRIES,L.d.country||'United Arab Emirates')}</select></label><label class="field">Current level<select id="l-level">${opt(['Class 10','Class 11 to 12','Undergraduate','Graduate','Working professional'],L.d.level)}</select></label></div>
  ${withCode?`<label class="field" style="margin-top:12px">Referral code (optional)<input id="l-code" value="${fv(L,'code')}" placeholder="For example MBX7K92" autocomplete="off" style="text-transform:uppercase"></label>`:''}
  <input id="l-website" tabindex="-1" autocomplete="off" aria-hidden="true" style="position:absolute;left:-9999px;opacity:0;height:0;width:0">
  <label class="check"><input type="checkbox" id="l-consent" ${L.d.consent?'checked':''}><span>I agree to be contacted by AIMER Business School about admissions.</span></label>
  <p class="err" role="alert">${esc(L.err)}</p>${prev?'<p class="small muted">This is a preview of your page. Students see it when they open your link.</p>':''}
  <button class="btn primary wide" data-act="lsubmit" data-mode="${mode}" ${(prev||L.busy)?'disabled':''}>${L.busy?'Sending…':withCode?'Send enquiry':'Register'}</button></div>`;
}
function leadDone(){return `<div class="card"><div class="success-ico">${icon('check')}</div><h1 style="font-size:26px">Thank you, we’ve received your details</h1>
  <p class="muted" style="margin:6px 0 0">An AIMER admissions counsellor will contact you on WhatsApp within one working day.</p><button class="btn primary mt" data-act="lnew">Submit another enquiry</button></div>`}
function vRegister(){
  const pub=S.pub;
  if(!pub)return `<div class="narrow"><div class="card empty">Loading…</div></div>`;
  if(pub.invalid)return `<div class="narrow" style="max-width:760px">${hero('This referral link isn’t valid','The link may have been typed incorrectly. You can still enquire about AIMER directly.',`<button class="btn primary" data-act="goto" data-v="enquire">Enquire about AIMER</button>`,'AIMER Business School',true)}</div>`;
  const vc=pub.course&&catalogCourses().concat(pub.courses||[]).find(c=>c.code===pub.course);
  const banner=pub.preview?`<div class="demo"><span>Preview of your referral page, exactly as students see it.</span><button class="btn sm" data-act="goto" data-v="home">Back to my dashboard</button></div>`:'';
  return `<div class="narrow" style="max-width:760px">${banner}${hero(vc?`${esc(pub.first)} invited you to explore ${esc(vc.name)}`:`${esc(pub.first)} invited you to AIMER`,`${vc&&vc.short?esc(vc.short)+'. ':''}Tell us about the student and the programme you’re interested in. No account needed.${pub.event?' Registering via '+esc(pub.event)+'.':''}`,'','AIMER Business School',true)}<div class="mt">${L.step==='done'?leadDone():leadForm('link')}</div></div>`;
}
function vEnquire(){return `<div class="narrow" style="max-width:760px">${hero('Enquire about AIMER','Planning your next step? Tell us what you’re interested in. If someone referred you, add their referral code.','','Admissions enquiry',true)}<div class="mt">${L.step==='done'?leadDone():leadForm('code')}</div></div>`}
function capture(e){const id=e.target.id||'';const o=id.startsWith('j-')?J:id.startsWith('l-')?L:null;if(!o||id==='l-website')return;o.d[id.slice(2)]=e.target.type==='checkbox'?e.target.checked:e.target.value;
  if(id==='j-country'||id==='l-country'){const el=document.getElementById(id[0]+'-cc'),c=CC_OF[e.target.value];if(el&&c&&!o.d.ccManual){el.value=c;o.d.cc=c}}
  if(id==='j-cc'||id==='l-cc')o.d.ccManual=true}
