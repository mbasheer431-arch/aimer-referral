#!/bin/sh
# Builds the whole web app into one file: ../site/index.html
cd "$(dirname "$0")"
mkdir -p ../site
cat head.html assets.js data.js a.js b.js c.js d.js g.js ov.js e.js f.js x.js h.js > ../site/index.html
printf "</script>\n</body>\n</html>\n" >> ../site/index.html
