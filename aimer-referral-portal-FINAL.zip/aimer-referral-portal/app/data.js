/* ---------- configuration, Supabase client and data layer ---------- */
const CFG=window.AIMER_CONFIG||{};
const siteBase=()=>(CFG.siteUrl||location.origin).replace(/\/$/,'');
const sb=(window.supabase&&CFG.url&&CFG.key)?window.supabase.createClient(CFG.url,CFG.key,{auth:{persistSession:true,autoRefreshToken:true,detectSessionInUrl:true}}):null;
const FRIENDLY={'Invalid login credentials':'That email or password isn’t right.','Email not confirmed':'Please confirm your email first. Check your inbox for our message.',
  'User already registered':'An account with this email already exists. Log in instead.','New password should be different from the old password.':'Choose a password you haven’t used before.',
  'Password should be at least 6 characters.':'Use at least 8 characters for your password.','Failed to fetch':'We couldn’t reach the server. Check your connection and try again.'};
const errOf=e=>{const m=(e&&e.message)||String(e);return new Error(FRIENDLY[m]||m.replace(/^FunctionsHttpError:?\s*/,''))};
const SIGNED_CACHE={};
const DB={
  async select(table,o={}){let q=sb.from(table).select(o.cols||'*');for(const[k,v]of Object.entries(o.eq||{}))q=q.eq(k,v);for(const[k,v]of Object.entries(o.in||{}))q=q.in(k,v);
    if(o.order)q=q.order(o.order,{ascending:o.asc===true});q=q.limit(o.limit||1000);const{data,error}=await q;if(error)throw errOf(error);return data||[]},
  async one(table,o={}){const r=await DB.select(table,{...o,limit:1});return r[0]||null},
  async rpc(name,args){const{data,error}=await sb.rpc(name,args||{});if(error)throw errOf(error);return data},
  async insert(table,row){const{data,error}=await sb.from(table).insert(row).select();if(error)throw errOf(error);return data},
  async update(table,patch,eq){let q=sb.from(table).update(patch);for(const[k,v]of Object.entries(eq))q=q.eq(k,v);const{data,error}=await q.select();if(error)throw errOf(error);return data},
  async del(table,eq){let q=sb.from(table).delete();for(const[k,v]of Object.entries(eq))q=q.eq(k,v);const{error}=await q;if(error)throw errOf(error)},
  async remove(bucket,paths){try{await sb.storage.from(bucket).remove(paths)}catch(e){}},
  async upsert(table,row,conflict){const{data,error}=await sb.from(table).upsert(row,{onConflict:conflict}).select();if(error)throw errOf(error);return data},
  async upload(bucket,path,file){const{error}=await sb.storage.from(bucket).upload(path,file,{upsert:true,contentType:file.type||undefined});if(error)throw errOf(error);return path},
  publicUrl(bucket,path){return path?sb.storage.from(bucket).getPublicUrl(path).data.publicUrl:null},
  async signed(bucket,paths){const out={},now=Date.now(),need=[];   // links last an hour, so reuse them until 10 minutes before they expire
    for(const p of paths){const c=SIGNED_CACHE[bucket+'/'+p];if(c&&c.exp>now+600000)out[p]=c.url;else need.push(p)}
    if(!need.length)return out;
    const{data,error}=await sb.storage.from(bucket).createSignedUrls(need,3600);if(error)return out;
    (data||[]).forEach(x=>{if(x.signedUrl){out[x.path]=x.signedUrl;SIGNED_CACHE[bucket+'/'+x.path]={url:x.signedUrl,exp:now+3600000}}});return out},
  async signedOne(bucket,path,download){const{data,error}=await sb.storage.from(bucket).createSignedUrl(path,300,download?{download:true}:undefined);if(error)throw errOf(error);return data.signedUrl},
  async register(body){try{const{data,error}=await sb.functions.invoke('register',{body});
    if(error){let j=null;const st=error.context&&error.context.status;try{j=await error.context.json()}catch(_){}
      if(st&&st<500&&j&&j.error)return{ok:false,error:j.error};return{ok:false,fallback:true}}
    if(data&&data.ok)return{ok:true};if(data&&data.error)return{ok:false,error:data.error};return{ok:false,fallback:true}}catch(_){return{ok:false,fallback:true}}},
  async invoke(fn,body){const{data,error}=await sb.functions.invoke(fn,{body});
    if(error){let msg=error.message;try{const j=await error.context.json();msg=j.error||j.message||msg}catch(_){}throw errOf({message:msg})}
    if(data&&data.error)throw errOf({message:data.error});return data},
  auth:{
    async signIn(email,password){const{data,error}=await sb.auth.signInWithPassword({email,password});if(error)throw errOf(error);return data},
    async signUp(email,password,meta){const{data,error}=await sb.auth.signUp({email,password,options:{data:meta,emailRedirectTo:siteBase()+'/login'}});if(error)throw errOf(error);return data},
    async resend(email){const{error}=await sb.auth.resend({type:'signup',email,options:{emailRedirectTo:siteBase()+'/login'}});if(error)throw errOf(error)},
    async updatePhone(phone){const{error}=await sb.auth.updateUser({phone});if(error)throw errOf(error)},
    async verifyPhone(phone,token){const{error}=await sb.auth.verifyOtp({phone,token,type:'phone_change'});if(error)throw errOf(error)},
    async signOut(){await sb.auth.signOut()},
    async user(){const{data}=await sb.auth.getUser();return data&&data.user||null},
    async sessionUser(){const{data}=await sb.auth.getSession();return data&&data.session&&data.session.user||null},   // read from the device, no network request
    async hasSession(){const{data}=await sb.auth.getSession();return !!(data&&data.session)},
    async resetPassword(email){const{error}=await sb.auth.resetPasswordForEmail(email,{redirectTo:siteBase()+'/login'});if(error)throw errOf(error)},
    async updatePassword(password){const{error}=await sb.auth.updateUser({password});if(error)throw errOf(error)},
    onChange(cb){sb.auth.onAuthStateChange((ev,sess)=>setTimeout(()=>cb(ev,sess),0))}
  }
};

/* ---------- state ---------- */
function newState(){return{session:null,view:'landing',ui:{},people:[],refs:[],camps:[],courses:[],batches:[],adj:[],intlog:[],audit:[],approvals:[],tickets:[],resources:[],usage:[],notifs:[],announcements:[],admins:[],leaderboard:[],catalog:null,
  pol:{v:0,rates:{},approved:[],history:[]},settings:{attributionDays:90,dupRule:'mobile_or_email',minPayout:0,lastTest:null,showRates:true,requirePhone:false,requireEmailConfirm:false,fieldMap:{}},lsq:null,seq:0,crm:[],pub:null,verify:{}}}
const day=t=>t?String(t).slice(0,10):null;
const LABEL={student_id:'ID',programme:'Programme',employee_id:'ID',department:'Department',year:'Graduated',alumni_id:'ID',institution:'Institution',role:'Role',member_id:'ID',city:'City',country:'Country',profession:'Does',how:'Promotes via',social:'Profile'};
function detailText(affs){if(!affs.length)return 'Has not chosen a category yet';
  return affs.map(a=>{const bits=Object.entries(a.details||{}).filter(([k,v])=>v&&k!=='imported'&&k!=='event').map(([k,v])=>`${LABEL[k]||k}: ${v}`);
    return `${a.category}${bits.length?' ('+bits.join(', ')+')':''}${a.status==='UNDER_REVIEW'?', waiting for review':''}`}).join('; ')}

/* ---------- load everything the signed-in person is allowed to see ---------- */
async function hydrate(){
  const ses=S.session;if(!ses)return;
  const isAdmin=ses.kind==='admin',uid=ses.id;
  const safe=p=>p.catch(()=>[]);
  // partners load everything in one request; admins keep the detailed loader
  let pre=null;if(!isAdmin){pre=S._pre||await DB.rpc('session_bootstrap');S._pre=null;if(!pre||pre.kind!=='partner')throw new Error('Your session has ended. Please log in again.')}
  const [courses,camps,cc,pvs,rates,resources,partners,affs,notifs,recips,tickets,msgs]=!isAdmin?[pre.courses,pre.campaigns,pre.campaign_courses,pre.policy_versions,pre.incentive_rates,pre.resources,pre.partners,pre.partner_affiliations,pre.notifications,pre.notification_recipients,pre.support_tickets,pre.ticket_messages]:await Promise.all([
    DB.select('courses',{order:'created_at',asc:true}),DB.select('campaigns',{order:'created_at',asc:true}),DB.select('campaign_courses'),DB.select('policy_versions',{order:'version',asc:true}),DB.select('incentive_rates'),
    safe(DB.select('resources',{order:'created_at'})),DB.select('partners',{order:'created_at',asc:true}),DB.select('partner_affiliations'),
    safe(DB.select('notifications',{order:'created_at'})),safe(DB.select('notification_recipients')),safe(DB.select('support_tickets',{order:'created_at'})),safe(DB.select('ticket_messages',{order:'created_at',asc:true}))]);
  const adminOnly=isAdmin?await Promise.all([DB.rpc('admin_list_referrals'),safe(DB.select('reward_transactions')),safe(DB.select('payout_batches',{order:'created_at',asc:true})),safe(DB.select('adjustments',{order:'created_at',asc:true})),
    safe(DB.select('approvals',{order:'created_at',asc:true})),DB.rpc('staff_names'),safe(DB.rpc('admin_bank_summary')),safe(DB.select('resource_events',{order:'created_at'})),safe(DB.select('course_events',{order:'created_at'})),
    safe(DB.select('audit_logs',{order:'created_at',limit:300})),safe(DB.select('integration_logs',{order:'created_at',limit:150})),safe(DB.select('admin_users',{order:'created_at',asc:true})),safe(DB.select('app_settings'))])
    :[pre.referrals,pre.reward_transactions,pre.payout_batches,pre.adjustments,pre.bank,pre.leaderboard,pre.verification];

  /* programmes, campaigns, policy */
  const cById={};courses.forEach(c=>cById[c.id]=c);
  S.courses=courses.map(c=>({id:c.id,uid:c.id,code:c.code,name:c.name,short:c.short_description||c.name,color:c.color||'#008BA5',desc:c.description||'',duration:c.duration||'',eligibility:c.eligibility||'',
    fee:Number(c.fee)||0,mode:c.mode||'',benefits:c.benefits||[],brochure:c.brochure_path?c.brochure_path.split('/').pop():null,brochurePath:c.brochure_path,brochureUrl:DB.publicUrl('course-media',c.brochure_path),
    landing:c.landing_url||'',image:DB.publicUrl('course-media',c.image_path),imagePath:c.image_path,status:c.status,refEligible:c.referral_eligible,cats:c.eligible_categories||[],
    launchedOn:day(c.launched_at),createdOn:day(c.created_at),downloads:0,views:0}));
  const campById={};camps.forEach(c=>campById[c.id]=c);
  S.camps=camps.map(c=>({id:c.code,uid:c.id,name:c.name,kind:c.kind,progs:cc.filter(x=>x.campaign_id===c.id).map(x=>cById[x.course_id]&&cById[x.course_id].code).filter(Boolean),
    organizer:c.organizer_id||null,location:c.location||'',start:c.start_date,end:c.end_date,status:c.status,desc:c.description||'',terms:c.terms||''}));
  const v=pvs.length?Math.max(...pvs.map(p=>p.version)):0;
  S.pol={v,rates:{},approved:[],history:pvs.map(p=>({v:p.version,on:day(p.approved_at),by:'Management',note:p.note||''}))};
  courses.forEach(c=>{const rs=rates.filter(r=>r.course_id===c.id&&r.policy_version===v).sort((a,b)=>a.slab-b.slab);if(rs.length===4){S.pol.rates[c.code]=rs.map(r=>Number(r.amount));S.pol.approved.push(c.code)}});
  PROGS.splice(0,PROGS.length,...S.courses.map(c=>c.code));S.courses.forEach(c=>{PCOL[c.code]=c.color;if(!S.pol.rates[c.code])S.pol.rates[c.code]=[0,0,0,0]});

  /* people */
  const affBy={};affs.forEach(a=>(affBy[a.partner_id]=affBy[a.partner_id]||[]).push(a));
  const bankBy={};
  if(isAdmin)(adminOnly[6]||[]).forEach(b=>bankBy[b.partner_id]={holder:'',last4:b.last4||'••••',ifsc:''});
  else{const mb=(adminOnly[4]||[])[0];if(mb)bankBy[uid]={holder:mb.account_holder,last4:mb.last4,ifsc:mb.ifsc}}
  const staff={};if(isAdmin)(adminOnly[5]||[]).forEach(x=>staff[x.user_id]=x);
  S.people=partners.map(p=>{const a=(affBy[p.id]||[]).filter(x=>x.status!=='REJECTED'),ev=camps.find(c=>c.id===p.event_campaign_id);
    return{id:p.id,name:p.full_name,affs:a.map(x=>x.category),vaffs:a.filter(x=>x.status==='VERIFIED').map(x=>x.category),status:p.status,detail:detailText(a),code:p.referral_code,phone:p.phone,email:p.email,
      clicks:p.visits||0,joined:day(p.created_at),bank:bankBy[p.id]||null,event:ev?ev.code:null}});
  const pById={};S.people.forEach(p=>pById[p.id]=p);

  /* referrals and rewards */
  const refRows=adminOnly[0]||[];
  S.refs=isAdmin?refRows.map(r=>({id:r.ref_no,uid:r.id,by:r.partner_id,name:r.student_name,phone:r.phone,email:'',prog:r.course_code,camp:r.campaign_code,src:r.source,stage:r.stage,date:day(r.created_at),
      lsq:r.lsq_lead_id,sync:r.sync_status==='ok'?'ok':r.sync_status==='held'?'held':'failed',flag:r.flag,attribution:r.attribution,cancelled:r.cancelled,reward:null,counsellor:r.counsellor,admNo:r.admission_no,receipts:{},
      via:(r.via_course_link||r.via_resource_id)?{course:r.via_course_link?r.course_code:null,res:r.via_resource_id}:null,feeOn:day(r.fee_verified_at)}))
    :refRows.map(r=>({id:r.ref_no,uid:r.id,by:uid,name:r.student_name,phone:'',email:'',prog:r.course_code,camp:null,src:r.source,stage:r.stage,date:day(r.created_at),lsq:null,sync:'ok',flag:null,
      attribution:r.attribution,cancelled:r.cancelled,reward:null,counsellor:null,admNo:null,receipts:{},via:null,feeOn:null}));
  const refByUid={};S.refs.forEach(r=>refByUid[r.uid]=r);
  const rewardRows=adminOnly[1]||[],batchRows=adminOnly[2]||[],adjRows=adminOnly[3]||[];
  const batchNo={};batchRows.forEach(b=>batchNo[b.id]=b.batch_no);
  const byRef={};rewardRows.forEach(x=>(byRef[x.referral_id]=byRef[x.referral_id]||[]).push(x));
  S.refs.forEach(r=>{const l=byRef[r.uid];if(!l||!l.length)return;l.sort((a,b)=>a.tranche-b.tranche);const f=l[0];
    r.reward={n:f.admission_number,slab:f.slab,rate:Number(f.rate),v:f.policy_version,t:l.map(x=>({amt:Number(x.amount),status:x.status,batch:batchNo[x.batch_id]||null,paidOn:day(x.paid_at)}))};
    r.feeOn=r.feeOn||day(f.created_at)});
  const nameOf=id=>id?(staff[id]?`${staff[id].full_name} (${ROLES[staff[id].role]})`:(pById[id]?pById[id].name:'AIMER team')):'';
  S.batches=batchRows.map(b=>{const items=[];rewardRows.filter(x=>x.batch_id===b.id).forEach(x=>{const r=refByUid[x.referral_id];if(r)items.push({ref:r.id,t:x.tranche-1})});
    return{id:b.batch_no,uid:b.id,created:day(b.created_at),status:b.status,items,total:Number(b.total),preparedBy:nameOf(b.prepared_by),approvedBy:b.approved_by?nameOf(b.approved_by):undefined,
      transferRef:b.transfer_ref,paidOn:day(b.paid_at),proof:b.proof_path?b.proof_path.split('/').pop():null,reconciled:b.reconciled}});
  S.adj=adjRows.map(a=>({id:a.id,uid:a.id,ref:a.referral_id&&refByUid[a.referral_id]?refByUid[a.referral_id].id:null,by:a.partner_id,amount:Number(a.amount),date:day(a.created_at),note:a.reason,batch:a.batch_id||null,status:a.status,kind:a.kind}));

  /* approvals */
  const codeOf=id=>(cById[id]||{}).code||id;
  S.approvals=(isAdmin?adminOnly[4]||[]:[]).map(a=>{const p=a.payload||{},o={id:a.id,uid:a.id,type:a.type,by:nameOf(a.requested_by),on:day(a.created_at),status:a.status,summary:a.summary,decidedBy:nameOf(a.decided_by),decidedOn:day(a.decided_at)};
    if(a.type==='campaign'){const c=campById[p.campaign_id];o.target=c?c.code:''}
    if(a.type==='policy'){o.rates={};Object.entries(p.rates||{}).forEach(([k,r])=>o.rates[codeOf(k)]=r);o.note=p.note||''}
    if(a.type==='attribution'){const r=refByUid[p.referral_id];o.target=r?r.id:'';o.from=r?r.by:null;o.to=p.to_partner;o.note=p.note||''}
    if(a.type==='adjustment'){o.partner=p.partner_id;o.amount=Number(p.amount);o.note=p.reason||''}
    return o});

  /* resources, usage and notifications */
  const signs=await DB.signed('resources',[...new Set(resources.map(r=>r.thumb_path||(/\.(jpe?g|png|webp)$/i.test(r.file_path||'')?r.file_path:null)).filter(Boolean))]);
  S.resources=resources.map(r=>({id:r.id,uid:r.id,type:r.type,title:r.title,course:r.course_id?codeOf(r.course_id):'All',camp:r.campaign_id&&campById[r.campaign_id]?campById[r.campaign_id].code:null,lang:r.language,
    text:r.body_text,file:r.file_path?r.file_path.split('/').pop().replace(/^\d+-/,''):null,filePath:r.file_path,thumb:signs[r.thumb_path]||signs[r.file_path]||null,status:r.status,date:day(r.created_at),stats:{}}));
  const rById={};S.resources.forEach(r=>rById[r.id]=r);
  S.usage=[];
  if(isAdmin){(adminOnly[7]||[]).forEach(e=>{const r=rById[e.resource_id];if(r)r.stats[e.action]=(r.stats[e.action]||0)+1});
    S.usage=(adminOnly[7]||[]).slice(0,60).map(e=>({t:e.created_at,pid:e.partner_id,res:e.resource_id,action:e.action}));
    (adminOnly[8]||[]).forEach(e=>{const c=S.courses.find(x=>x.id===e.course_id);if(c){if(e.action==='brochure')c.downloads++;if(e.action==='view')c.views++}})}
  const recBy={};recips.forEach(r=>(recBy[r.notification_id]=recBy[r.notification_id]||[]).push(r));
  const tgt=t=>({view:(t||{}).view,id:(t||{}).course||(t||{}).resource});
  S.notifs=notifs.map(n=>{const rs=recBy[n.id]||[];
    return{id:n.id,kind:n.kind,title:n.title,body:n.body||'',target:tgt(n.target),date:n.created_at,aud:rs.map(r=>r.partner_id),read:rs.filter(r=>r.read_at).map(r=>r.partner_id)}});
  S.announcements=S.notifs.filter(n=>n.kind==='announcement').sort((a,b)=>b.date.localeCompare(a.date)).map(n=>({...n,date:day(n.date)}));

  /* support */
  S.tickets=tickets.map(t=>({id:'TK-'+t.ticket_no,uid:t.id,by:t.partner_id,cat:t.category,subject:t.subject,status:t.status,team:t.team,created:day(t.created_at),
    msgs:msgs.filter(m=>m.ticket_id===t.id).map(m=>({from:m.is_staff?'staff':t.partner_id,who:m.is_staff?(staff[m.author]?`${staff[m.author].full_name} (${ROLES[staff[m.author].role]})`:'AIMER team'):'',t:m.created_at,text:m.body}))})).sort((a,b)=>b.created.localeCompare(a.created));

  /* admin extras */
  S.admins=[];S.audit=[];S.intlog=[];S.leaderboard=[];S.verify=isAdmin?{}:((adminOnly[6]||[])[0]||{});
  if(isAdmin){
    S.audit=(adminOnly[9]||[]).map(a=>({t:a.created_at,who:a.actor?nameOf(a.actor):'System',role:a.actor_role||'system',a:a.action}));
    S.intlog=(adminOnly[10]||[]).map(l=>({t:l.created_at,ref:l.referral_id&&refByUid[l.referral_id]?refByUid[l.referral_id].id:'–',ev:l.event,ok:l.ok,msg:l.message||''}));
    S.admins=(adminOnly[11]||[]).map(a=>({id:a.user_id,name:a.full_name,email:a.email,role:a.role,status:a.status,lastLogin:day(a.last_login_at)}));
    const st={};(adminOnly[12]||[]).forEach(x=>st[x.key]=x.value);
    S.settings={attributionDays:Number(st.attribution_window_days)||90,dupRule:st.duplicate_rule||'mobile_or_email',minPayout:Number(st.minimum_payout)||0,lastTest:st.lsq_last_test||null,showRates:st.public_show_rates!==false,requirePhone:st.require_phone_otp===true,requireEmailConfirm:st.email_confirmation_required===true,fieldMap:st.lsq_field_map||{}};
    COUNSELLORS=Array.isArray(st.counsellors)?st.counsellors:[];
  }else S.leaderboard=adminOnly[5]||[];
}
async function loadCatalog(){S.connErr=null;try{S.catalog=await DB.rpc('public_catalog')}catch(e){S.connErr=e.message;S.catalog={show_rates:true,courses:[]}}}
