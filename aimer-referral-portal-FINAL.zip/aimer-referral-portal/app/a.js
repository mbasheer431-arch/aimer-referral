const PROGS=['UGBP','PGBP','HSBC'];
const PCOL={UGBP:'#22B8D8',PGBP:'#2F7DE1',HSBC:'#F2A531',MBA:'#8B5CF0',BBA:'#C06BDE',HR:'#EC5454','Short Courses':'#EE6FA8',Others:'#5DBB3F'};
const STAGES=['Enquiry','Contacted','Application','Admission','Fee paid','First instalment'];
const CATS=['Student','Employee','Alumni','MKC Network','Ambassador'];
const CAT_INFO={Student:'Current AIMER students',Employee:'AIMER staff and faculty',Alumni:'AIMER graduates','MKC Network':'Markaz Knowledge City institutions and staff',Ambassador:'Community champions who promote AIMER'};
const CAT_VER={Student:'Verified automatically once your email and mobile number are confirmed',Employee:'Verified automatically once your email and mobile number are confirmed',Alumni:'Verified automatically once your email and mobile number are confirmed','MKC Network':'Verified automatically once your email and mobile number are confirmed',Ambassador:'Verified automatically once your email and mobile number are confirmed'};
const VSTAT={PENDING:['Pending','grey'],EMAIL_VERIFIED:['Contact verified','grey'],UNDER_REVIEW:['Under review','warn'],VERIFIED:['Verified','ok'],REJECTED:['Rejected','bad'],SUSPENDED:['Suspended','bad']};
const TSTAT={not_due:['Not yet due','grey'],eligible:['Eligible','warn'],on_hold:['On hold','grey'],in_batch:['Awaiting approval','warn'],approved:['Approved','warn'],paid:['Paid','ok'],reversed:['Reversed','bad']};
const FLAG={
  crm_unchecked:['CRM check failed','We couldn’t check whether this student is already in LeadSquared. Check the CRM, then confirm or reject. Nothing is sent to LeadSquared until you decide.'],
  existing_lead:['Already in LeadSquared','This student existed in the CRM before the referral. Confirm only if the partner genuinely brought them back.'],
  related_party:['Related-party referral','The partner and the student are related. Programme terms decide whether this qualifies.'],
  conflict:['Claimed by another partner','Another partner’s verified referral reached LeadSquared first. The first verified referral owns attribution unless Management approves an exception.'],
  risk:['Risk signal','Several enquiries came from the same device in a short time. Shared devices are common at schools and events, so check before deciding.']
};
const SRC={link:'Tracked link',code:'Manual code',event:'Event list'};
const SLAB_LBL=['1–5','6–10','11–15','16+'];
const slabIdx=n=>n<=5?0:n<=10?1:n<=15?2:3;
let COUNSELLORS=[];
const ROLES={superadmin:'Super Admin',marketing:'Marketing Admin',admissions:'Admissions Admin',finance:'Finance Admin',ceo:'Management / CEO',support:'Support Admin',event:'Event Admin'};
const MENU=[['dashboard','Dashboard','home'],['partners','Partner Management','users'],['campaigns','Campaign Management','megaphone'],['links','Referral Links','link'],['leads','Lead Management','inbox'],['admissions','Admission Management','cap'],['incentives','Incentive Management','coins'],['payouts','Payout Management','wallet'],['approvals','Approvals','check'],['courses','Course Catalogue','book'],['events','Event Management','calendar'],['resources','Resource Centre','image'],['reports','Reports & Analytics','chart'],['support','Support & Disputes','help'],['roles','Roles & Permissions','key'],['settings','Integrations & Settings','plug'],['audit','Audit Logs','list']];
const PMENU=[['home','Dashboard','home'],['courses','Explore Courses','book'],['resources','Resource Centre','image'],['referrals','My Referrals','share'],['earnings','Earnings & Payouts','coins'],['leaders','Leaderboard','trophy'],['help','Help & Support','help']];
const ACCESS={
  dashboard:{superadmin:'Full',marketing:'Full',admissions:'Limited',finance:'Limited',ceo:'Full',support:'Limited',event:'Limited'},
  partners:{superadmin:'Full',marketing:'Full',admissions:'View',finance:'View',ceo:'View',support:'View'},
  campaigns:{superadmin:'Full',marketing:'Create',finance:'View',ceo:'Approve'},
  links:{superadmin:'Full',marketing:'Full',admissions:'View',finance:'View',ceo:'View',support:'View'},
  leads:{superadmin:'Full',marketing:'View',admissions:'Full',finance:'View',ceo:'View'},
  admissions:{superadmin:'Full',marketing:'View',admissions:'Full',finance:'View',ceo:'View'},
  incentives:{superadmin:'Full',marketing:'View',finance:'Verify',ceo:'View'},
  payouts:{superadmin:'Full',finance:'Process',ceo:'Approve'},
  approvals:{superadmin:'Full',ceo:'Approve'},
  events:{superadmin:'Full',marketing:'Full',event:'Full',ceo:'View'},
  courses:{superadmin:'Full',marketing:'Full',admissions:'View',finance:'View',ceo:'View',support:'View',event:'View'},
  resources:{superadmin:'Full',marketing:'Full',ceo:'View',event:'View'},
  reports:{superadmin:'Full',marketing:'Full',admissions:'Limited',finance:'Full',ceo:'Full',event:'Limited'},
  support:{superadmin:'Full',support:'Full',marketing:'Escalated',finance:'Escalated'},
  roles:{superadmin:'Full',ceo:'View'},
  settings:{superadmin:'Full',marketing:'View'},
  audit:{superadmin:'Full',marketing:'Limited',finance:'Limited',ceo:'View'}
};
const CAN={'partner.manage':['superadmin','marketing'],'attr.review':['superadmin','marketing'],'lead.update':['superadmin','admissions'],'payment.verify':['superadmin','finance'],
  'payout.process':['superadmin','finance'],'approve':['superadmin','ceo'],'campaign.create':['superadmin','marketing'],'campaign.status':['superadmin','marketing'],
  'policy.propose':['marketing','superadmin'],'materials':['superadmin','marketing'],'courses':['superadmin','marketing'],'events':['superadmin','marketing','event'],'tickets':['superadmin','support'],
  'admins':['superadmin'],'links.manage':['superadmin','marketing'],'settings':['superadmin'],'bank.view':['superadmin','finance'],'contact.view':['superadmin','admissions','support'],'adjust.propose':['superadmin','finance']};

const ICONS={home:'M3 10.5 12 3l9 7.5V20a1 1 0 0 1-1 1h-5v-6h-6v6H4a1 1 0 0 1-1-1z',
  share:'M18 8a3 3 0 1 0-2.8-4M6 15a3 3 0 1 0 0-6 3 3 0 0 0 0 6Zm12 6a3 3 0 1 0 0-6 3 3 0 0 0 0 6ZM8.6 13.5l6.8 4M15.4 6.5l-6.8 4',
  users:'M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2M9 11a4 4 0 1 0 0-8 4 4 0 0 0 0 8Zm13 10v-2a4 4 0 0 0-3-3.9M16 3.1a4 4 0 0 1 0 7.8',
  megaphone:'M3 11v2a1 1 0 0 0 1 1h3l6 4V6L7 10H4a1 1 0 0 0-1 1Zm13-3a5 5 0 0 1 0 8M7 14l1 6h3',
  link:'M10 14a5 5 0 0 0 7 0l3-3a5 5 0 0 0-7-7l-1.5 1.5M14 10a5 5 0 0 0-7 0l-3 3a5 5 0 0 0 7 7l1.5-1.5',
  inbox:'M22 12h-6l-2 3h-4l-2-3H2M5.5 5h13l3.5 7v6a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2v-6z',
  cap:'M22 10 12 5 2 10l10 5 10-5ZM6 12v5c3 2 9 2 12 0v-5',
  coins:'M12 8c4.4 0 8-1.3 8-3s-3.6-3-8-3-8 1.3-8 3 3.6 3 8 3Zm-8-3v6c0 1.7 3.6 3 8 3s8-1.3 8-3V5M4 11v6c0 1.7 3.6 3 8 3s8-1.3 8-3v-6',
  wallet:'M3 7a2 2 0 0 1 2-2h13v4M3 7v11a2 2 0 0 0 2 2h15V9H5a2 2 0 0 1-2-2Zm14 7h.01',
  check:'M9 12l2 2 4-4M12 22a10 10 0 1 0 0-20 10 10 0 0 0 0 20Z',
  calendar:'M8 2v4M16 2v4M3 9h18M5 4h14a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2Z',
  image:'M5 3h14a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2Zm4 8a2 2 0 1 0 0-4 2 2 0 0 0 0 4Zm12 4-5-5L5 21',
  chart:'M3 3v18h18M8 17v-5M13 17V8M18 17v-9',
  help:'M12 22a10 10 0 1 0 0-20 10 10 0 0 0 0 20Zm-3-13a3 3 0 1 1 4 2.8c-.6.3-1 .9-1 1.6V14m0 3h.01',
  key:'M15 7a4 4 0 1 1-3.9 5H9v2H7v2H4v-3l6.1-6.1A4 4 0 0 1 15 7Zm1.5 1.5h.01',
  plug:'M9 2v6M15 2v6M6 8h12v4a6 6 0 0 1-12 0zM12 18v4',
  list:'M8 6h13M8 12h13M8 18h13M3 6h.01M3 12h.01M3 18h.01',
  trophy:'M8 21h8M12 17v4M7 4h10v5a5 5 0 0 1-10 0zM7 6H4a3 3 0 0 0 3 4M17 6h3a3 3 0 0 1-3 4',
  logout:'M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4M16 17l5-5-5-5M21 12H9',
  settings:'M12 15a3 3 0 1 0 0-6 3 3 0 0 0 0 6Zm7.4-3a7.4 7.4 0 0 0-.1-1.3l2-1.6-2-3.4-2.4 1a7.6 7.6 0 0 0-2.2-1.3L14.4 3h-4l-.3 2.4a7.6 7.6 0 0 0-2.2 1.3l-2.4-1-2 3.4 2 1.6a7.4 7.4 0 0 0 0 2.6l-2 1.6 2 3.4 2.4-1a7.6 7.6 0 0 0 2.2 1.3l.3 2.4h4l.3-2.4a7.6 7.6 0 0 0 2.2-1.3l2.4 1 2-3.4-2-1.6c.1-.4.1-.9.1-1.3Z',
  copy:'M9 9h11v11H9zM5 15H4V4h11v1',
  qr:'M3 3h7v7H3zM14 3h7v7h-7zM3 14h7v7H3zM14 14h3v3h-3zM20 14v.01M14 20h.01M17 20h4M20 17v3',
  send:'M22 2 11 13M22 2l-7 20-4-9-9-4z',
  chat:'M21 12a8.5 8.5 0 0 1-12.6 7.4L3 21l1.6-5.2A8.5 8.5 0 1 1 21 12Z',
  userplus:'M15 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2M8.5 11a4 4 0 1 0 0-8 4 4 0 0 0 0 8ZM20 8v6M23 11h-6',
  eye:'M2 12s3.6-7 10-7 10 7 10 7-3.6 7-10 7S2 12 2 12Zm10 3a3 3 0 1 0 0-6 3 3 0 0 0 0 6Z',
  menu:'M3 6h18M3 12h18M3 18h18',
  pulse:'M3 12h4l3-8 4 16 3-8h4',
  shield:'M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10Zm-3-10 2 2 4-4',
  user:'M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2M12 11a4 4 0 1 0 0-8 4 4 0 0 0 0 8Z',
  trend:'M3 17l6-6 4 4 8-8M15 7h6v6',
  mail:'M3 5h18v14H3zM3 6l9 7 9-7',
  book:'M4 19.5A2.5 2.5 0 0 1 6.5 17H20V3H6.5A2.5 2.5 0 0 0 4 5.5zM4 19.5A2.5 2.5 0 0 0 6.5 22H20v-5',
  download:'M12 3v12M7 10l5 5 5-5M5 21h14',
  bell:'M18 8a6 6 0 1 0-12 0c0 7-3 9-3 9h18s-3-2-3-9M13.7 21a2 2 0 0 1-3.4 0',
  play:'M6 4l14 8-14 8z',star:'M12 3l2.8 5.7 6.2.9-4.5 4.4 1 6.2L12 17.3 6.5 20.2l1-6.2L3 9.6l6.2-.9z',
  globe:'M12 22a10 10 0 1 0 0-20 10 10 0 0 0 0 20ZM2 12h20M12 2a15 15 0 0 1 0 20M12 2a15 15 0 0 0 0 20',
  edit:'M12 20h9M16.5 3.5a2.1 2.1 0 0 1 3 3L7 19l-4 1 1-4z',archive:'M3 4h18v4H3zM5 8v12h14V8M10 12h4'};
const icon=(n,c='')=>`<svg class="i ${c}" viewBox="0 0 24 24" aria-hidden="true"><path d="${ICONS[n]||''}"/></svg>`;

let S=newState();
const $=id=>document.getElementById(id);
const esc=s=>String(s==null?'':s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const person=id=>S.people.find(p=>p.id===id);
const camp=id=>S.camps.find(c=>c.id===id);
const ref=id=>S.refs.find(r=>r.id===id);
const batch=id=>S.batches.find(b=>b.id===id);
const live=r=>r.attribution!=='rejected';
const admitted=r=>r.stage>=3&&!r.cancelled&&live(r);
const liveR=r=>r.reward&&!r.cancelled;
const money=n=>(n<0?'−':'')+'₹'+Math.abs(Math.round(n)).toLocaleString('en-IN');
const kfmt=n=>'₹'+(n>=100000?(n/100000)+'L':(n/1000)+'k');
const num=n=>Number(n).toLocaleString('en-IN');
const digits=s=>String(s||'').replace(/\D/g,'');
const mask=p=>{const d=digits(p);return String(p).split(' ')[0]+' ••• '+d.slice(-4)};
const nowLocal=()=>new Date(Date.now()-new Date().getTimezoneOffset()*6e4).toISOString().slice(0,16);
const today=()=>nowLocal().slice(0,10);
const daysAgo=n=>new Date(Date.now()-n*864e5-new Date().getTimezoneOffset()*6e4).toISOString().slice(0,10);
const dayDiff=d=>Math.round((new Date(today())-new Date(d.slice(0,10)))/864e5);
const fmtDate=d=>d?new Date(d.slice(0,10)+'T00:00:00').toLocaleDateString('en-GB',{day:'numeric',month:'short',year:'numeric'}):'';
const fmtTime=t=>{const d=new Date(t);return d.toLocaleDateString('en-GB',{day:'numeric',month:'short'})+', '+d.toLocaleTimeString('en-GB',{hour:'2-digit',minute:'2-digit'})};
const monthName=d=>new Date(d.slice(0,10)+'T00:00:00').toLocaleDateString('en-GB',{month:'long',year:'numeric'});
const meId=()=>S.session&&S.session.kind==='partner'&&person(S.session.id)?S.session.id:null;
const adminUser=()=>S.session&&S.session.kind==='admin'?{id:S.session.id,name:S.session.name,role:S.session.role,status:'Active'}:null;
const role=()=>(adminUser()||{}).role;
const can=a=>!!role()&&CAN[a].includes(role());
const access=v=>(ACCESS[v]||{})[role()];
const linkFor=(p,o={})=>{const q=[o.course&&'course='+encodeURIComponent(o.course.toLowerCase().replace(/\s+/g,'-')),o.c&&'c='+o.c,o.res&&'res='+o.res].filter(Boolean);return `${siteBase()}/r/${p.code}${q.length?'?'+q.join('&'):''}`};
const course=code=>(S.courses||[]).find(c=>c.code===code);
function syncProgs(){PROGS.splice(0,PROGS.length,...S.courses.map(c=>c.code));S.courses.forEach(c=>{PCOL[c.code]=c.color;if(!S.pol.rates[c.code])S.pol.rates[c.code]=[0,0,0,0]})}
const openCourses=()=>S.courses.filter(c=>c.status==='Active'&&c.refEligible&&activeCamp(c.code));
const eligibleFor=(p,code)=>{const c=course(code);return !!c&&c.status==='Active'&&c.refEligible&&!!activeCamp(code)&&p.status==='VERIFIED'&&(p.vaffs||p.affs).some(a=>c.cats.includes(a))};
const isNew=d=>d&&dayDiff(d)<=30;
function track(pid,resId,action){DB.rpc('track_resource',{p_resource:resId,p_action:action}).catch(()=>{})}
const cats=p=>p.affs.length?p.affs.join(', '):'Category not chosen';
const firstName=p=>p.name.split(' ')[0];
const shortName=p=>{const w=p.name.split(' ');return w[0]+(w[1]?' '+w[1][0]+'.':'')};
const who=()=>{const m=meId();if(m)return person(m).name;const a=adminUser();return a?`${a.name} (${ROLES[a.role]})`:'Public page'};
const log=()=>{};
const ilog=()=>{};
const lsqId=()=>'LSQ-'+(480000+S.seq*37);
const tsum=(list,sts)=>list.reduce((s,r)=>s+(r.reward?r.reward.t.filter(t=>sts.includes(t.status)).reduce((a,t)=>a+t.amt,0):0),0);
const activeCamp=pg=>S.camps.filter(c=>c.kind==='programme'&&c.status==='Active'&&c.start<=today()&&c.end>=today()&&c.progs.includes(pg)).sort((a,b)=>a.progs.length-b.progs.length)[0];
function genCode(){const ch='ABCDEFGHJKLMNPQRSTUVWXYZ23456789';let c;do{c='';for(let i=0;i<7;i++)c+=ch[Math.floor(Math.random()*ch.length)]}while(S.people.some(p=>p.code===c));return c}
function countAdm(pid,pg){return S.refs.filter(r=>r.by===pid&&r.prog===pg&&liveR(r)).length}
function computeReward(r){
  const n=countAdm(r.by,r.prog)+1,i=slabIdx(n),rate=S.pol.rates[r.prog][i],hold=r.attribution==='review';
  r.feeOn=today();
  r.reward={n,slab:i,rate,v:S.pol.v,t:[{amt:rate/2,status:hold?'on_hold':'eligible',batch:null,paidOn:null},{amt:rate/2,status:'not_due',batch:null,paidOn:null}]};
}
const earned=list=>list.filter(liveR).reduce((s,r)=>s+r.reward.rate,0);
function projected(pid){let e=0;PROGS.forEach(pg=>{let n=countAdm(pid,pg);S.refs.filter(r=>r.by===pid&&r.prog===pg&&r.stage===3&&!r.cancelled&&live(r)).forEach(()=>{n++;e+=S.pol.rates[pg][slabIdx(n)]})});return e}
function breakdown(n,rates){const parts=[];let left=n;[5,5,5,Infinity].forEach((size,i)=>{const k=Math.min(left,size);if(k>0){parts.push([k,rates[i],i]);left-=k}});return {parts,total:parts.reduce((s,[k,r])=>s+k*r,0)}}
function tranches(sts){const out=[];S.refs.forEach(r=>r.reward&&r.reward.t.forEach((t,i)=>{if(sts.includes(t.status))out.push({r,i,t})}));return out}

let toastT;
function toast(m){const t=$('toast');t.textContent=m;t.classList.add('show');clearTimeout(toastT);toastT=setTimeout(()=>t.classList.remove('show'),3400)}
