/* ---------- components ---------- */
const chip=([t,c])=>`<span class="chip ${c||''}">${t}</span>`;
const tchip=t=>chip(TSTAT[t.status]);
function trend(cur,prev){if(!prev&&!cur)return '<span class="trend flat">No change</span>';if(!prev)return '<span class="trend up">↑ New</span>';
  const p=Math.round((cur-prev)/prev*100);return p===0?'<span class="trend flat">0%</span>':`<span class="trend ${p>0?'up':'down'}">${p>0?'↑ +':'↓ '}${p}%</span>`}
const kpi=(k,ic,val,label,tr='')=>`<div class="kpi ${k}"><div class="ico">${icon(ic)}</div><b>${val}</b><div class="row"><span class="l">${label}</span>${tr}</div></div>`;
const tile=(ic,label,val)=>`<div class="tile"><div class="ti">${icon(ic)}</div><div><span>${label}</span><b>${val}</b></div></div>`;
const conv=(a,b,x,y)=>{const p=x?Math.round(y/x*1000)/10:0;return `<div class="conv"><div class="row"><span>${a} → ${b}</span><b>${p}%</b></div><div class="cbar"><i style="width:${Math.min(100,p)}%"></i></div></div>`};
const pagehead=(t,p,right='')=>`<div class="pagehead"><div><h1>${t}</h1>${p?`<p>${p}</p>`:''}</div>${right}</div>`;
function hero(title,text,btns,chipTxt,slim){return `<section class="hero${slim?' slim':''}"><div class="hero-copy">${chipTxt?`<span class="hero-chip">${chipTxt}</span>`:''}<h1>${title}</h1><p>${text}</p><div class="row">${btns}</div></div><div class="hero-swoosh" aria-hidden="true"></div><div class="hero-img" role="img" aria-label="AIMER Business School campus" style="background-image:url(${IMG.campus})"></div></section>`}
function filters(key,opts){const cur=S.ui[key]||opts[0][0];
  return `<div class="filters" role="group">${opts.map(([k,l,n])=>`<button data-act="filter" data-key="${key}" data-k="${k}" class="${k===cur?'on':''}" aria-pressed="${k===cur}">${l}${n!=null?` (${n})`:''}</button>`).join('')}</div>`}
const statusChip=r=>r.attribution==='rejected'?chip(['Not eligible for credit','bad']):r.cancelled?chip(['Cancelled','bad']):r.sync==='failed'?chip(['Sync pending','grey']):r.attribution==='review'?chip(['Under review','grey']):chip([STAGES[r.stage],r.stage>=3?'ok':'']);
function trail(r){
  const stop=r.cancelled||r.attribution==='rejected';
  let h=`<div class="trail${stop?' stopped':''}" role="img" aria-label="Stage reached: ${STAGES[r.stage]}">`;
  STAGES.forEach((s,i)=>{const fin=i===5&&r.stage===5,cls=i<r.stage||fin?'done':i===r.stage?'current':'';h+=`<div class="step ${cls}${i<r.stage||fin?' lit':''}"><span class="dot"><span class="lbl">${s}</span></span></div>`});
  let coin='';if(r.reward){const st=r.reward.t.map(t=>t.status);coin=st.every(s=>s==='paid')?'paid':r.cancelled?'void':st[0]==='paid'?'half':'due'}
  return h+`<span class="coin ${coin}">₹<span class="lbl">${r.reward?money(r.reward.rate):'Incentive'}</span></span></div>`;
}
function refItem(r,team){const p=person(r.by);
  return `<li class="ref"><div class="ref-head"><div><strong>${esc(r.name)}</strong><div class="ref-sub"><span>${r.prog}</span><span>${SRC[r.src]}</span><span>Referred ${fmtDate(r.date)}</span>${team?`<span>by ${esc(p.name)}</span><span>${r.id}</span>`:''}</div></div>${statusChip(r)}</div>${trail(r)}</li>`}
function gauge(parts){
  const total=parts.reduce((s,p)=>s+p.v,0),cx=160,cy=150,R=118,W=30;
  const pt=a=>[cx+R*Math.cos(a),cy-R*Math.sin(a)];
  let svg=`<svg class="gauge" viewBox="0 0 320 175" role="img" aria-label="Earnings by programme"><path d="M${cx-R} ${cy} A${R} ${R} 0 0 1 ${cx+R} ${cy}" fill="none" stroke="var(--line)" stroke-width="${W}" stroke-linecap="butt"/>`;
  if(total){let a=Math.PI;const gap=.025;parts.filter(p=>p.v).forEach(p=>{const span=Math.PI*p.v/total;const a1=a-(a<Math.PI?gap/2:0),a2=a-span+gap/2;if(a1>a2){const [x1,y1]=pt(a1),[x2,y2]=pt(Math.max(0,a2));svg+=`<path d="M${x1.toFixed(1)} ${y1.toFixed(1)} A${R} ${R} 0 0 1 ${x2.toFixed(1)} ${y2.toFixed(1)}" fill="none" stroke="${p.c}" stroke-width="${W}"/>`}a-=span})}
  return svg+`<text x="${cx}" y="${cy-30}" text-anchor="middle" font-size="14" fill="var(--muted)" font-family="Outfit,sans-serif">Total earned</text><text x="${cx}" y="${cy-2}" text-anchor="middle" font-size="27" font-weight="700" fill="var(--ink)" font-family="Outfit,sans-serif">${money(total)}</text></svg>`;
}
function earningsBreakdown(list,title='Earnings Breakdown'){
  const parts=PROGS.map(pg=>({k:pg,c:PCOL[pg],v:earned(list.filter(r=>r.prog===pg))})),tot=parts.reduce((s,p)=>s+p.v,0);
  return `<div class="card"><div class="card-head"><h2>${icon('coins')}${title}</h2></div>${gauge(parts)}
  <div class="legend">${parts.map(p=>`<div><i style="background:${p.c}"></i>${p.k}<b>${tot?(p.v/tot*100).toFixed(1):'0.0'}%</b></div>`).join('')}</div></div>`;
}
function perfCard(list,clicks,title='Referral Performance'){
  const ok=list.filter(live),lk=ok.filter(r=>r.src==='link').length,cd=ok.filter(r=>r.src==='code').length,ev=ok.filter(r=>r.src==='event').length;
  const enq=ok.length,app=ok.filter(r=>r.stage>=2&&!r.cancelled).length,adm=ok.filter(admitted).length,fee=ok.filter(r=>r.stage>=4&&!r.cancelled).length;
  return `<div class="card"><div class="card-head"><h2>${icon('chart')}${title}</h2></div>
  <div class="grid g3">${tile('link','Tracked link signups',num(lk))}${tile('qr','Manual code signups',num(cd))}${tile('users',ev?'Event list signups':'Total signups',num(ev||enq))}</div>
  <div class="grid g4 mt">${tile('eye','Visitors',num(clicks))}${tile('userplus','Enquiries',num(enq))}${tile('inbox','Applications',num(app))}${tile('cap','Admissions',num(adm))}</div>
  <div class="grid g4 mt">${conv('Visitor','Enquiry',clicks,enq)}${conv('Enquiry','Application',enq,app)}${conv('Application','Admission',app,adm)}${conv('Admission','Fee paid',adm,fee)}</div></div>`;
}
function slabCard(pid,pg){
  const n=countAdm(pid,pg),rates=S.pol.rates[pg],ni=slabIdx(n+1);
  const segs=[0,1,2,3].map(i=>{const f=i<3?Math.min(1,Math.max(0,(n-i*5)/5)):(n>=16?1:0);return `<div class="seg ${i===ni?'cur':''}"><i style="width:${f*100}%"></i></div>`}).join('');
  return `<div class="slab"><div class="slab-top"><div><h3><i style="background:${PCOL[pg]}"></i>${pg}</h3><span class="small muted">${n} admission${n===1?'':'s'} counted</span></div><div class="slab-rate"><b>${money(rates[ni])}</b><span>next admission</span></div></div>
  <div class="segs" aria-hidden="true">${segs}</div><div class="seglbl">${[0,1,2,3].map(i=>`<span><b>${SLAB_LBL[i]}</b>${kfmt(rates[i])}</span>`).join('')}</div>
  <p>${ni<3?`From admission ${(ni+1)*5+1}, each earns ${money(rates[ni+1])}.`:'You’re in the top slab.'}</p></div>`;
}
function linkCard(me){const url=linkFor(me),msg=inviteText(me);
  return `<div class="card"><div class="card-head"><div><h2>Your Referral Link</h2><p>One link for every programme. Students pick their programme when they register. Your code is <strong>${me.code}</strong>, for anyone who enquires without the link.</p></div></div>
  <div class="linkbox"><div class="linkfield">${icon('link')}<span>${esc(url)}</span></div><button class="btn primary" data-act="copy" data-text="${esc(url)}">${icon('copy')}Copy</button></div>
  <div class="share"><span>Share via</span><a class="pill" href="https://t.me/share/url?url=${encodeURIComponent(url)}&text=${encodeURIComponent('Have a look at AIMER Business School')}" target="_blank" rel="noopener">${icon('send')}Telegram</a>
  <a class="pill" href="https://wa.me/?text=${encodeURIComponent(msg)}" target="_blank" rel="noopener">${icon('chat')}WhatsApp</a>
  <button class="pill" data-act="qr">${icon('qr')}QR code</button><button class="pill" data-act="tryform">${icon('eye')}Preview page</button></div></div>`}
const progNames=()=>{const l=S.courses.filter(c=>c.status==='Active').map(c=>c.name);return l.length>1?l.slice(0,-1).join(', ')+' and '+l[l.length-1]:l[0]||'business programmes'};
const inviteText=me=>`Hi! I’d like to share AIMER Business School with you. Their programmes include ${progNames()}. Register here and the admissions team will guide you:\n${linkFor(me)}`;
function mkQR(el,url){if(el&&window.qrcode){try{const c=qrcode(0,'M');c.addData(url);c.make();el.innerHTML=c.createSvgTag({cellSize:4,margin:0,scalable:true})}catch(e){}}}

/* ---------- partner views ---------- */
function vLocked(me){
  const m={EMAIL_VERIFIED:['Verify your mobile number','Your email is confirmed. Enter the 6-digit code we text to your mobile number and your referral link unlocks straight away.'],
    UNDER_REVIEW:['Your verification is under review',`We’re checking your ${(me.affs[0]||'').toLowerCase()} details. Your dashboard and referral link unlock as soon as you’re verified, usually within one working day.`],
    PENDING:['Verify your contact details','Verify your mobile and email to continue.'],
    REJECTED:['We couldn’t verify your account','Raise a support ticket if you think this is a mistake.'],
    SUSPENDED:['Your account is suspended','Your referral link is switched off. Your history and earned incentives stay on record.']}[me.status];
  const si={PENDING:1,EMAIL_VERIFIED:2,UNDER_REVIEW:3,REJECTED:3,SUSPENDED:4}[me.status];
  return `${hero('AIMER Ambassador Program','Refer future business leaders and earn rewards on successful admissions.','','Account '+VSTAT[me.status][0].toLowerCase(),true)}
  <div class="card mt" style="max-width:620px"><div class="row" style="justify-content:space-between"><h2>${m[0]}</h2>${chip(VSTAT[me.status])}</div><p class="muted" style="margin:8px 0 0">${m[1]}</p>
  <ul class="checklist">${['Account created','Email confirmed','Mobile number verified','Referral link unlocked'].map((s,i)=>`<li class="${i<si?'ok':i===si?'now':''}"><span class="ck">${i<si?'✓':i+1}</span>${s}</li>`).join('')}</ul>
  <div class="row mt">${me.status==='EMAIL_VERIFIED'?'<button class="btn primary" data-act="jphonestep">Verify my mobile number</button>':''}<button class="btn" data-act="nav" data-k="help">Contact support</button></div></div>`;
}
function vHome(){
  const me=person(meId());if(me.status!=='VERIFIED')return vLocked(me);
  const mine=S.refs.filter(r=>r.by===me.id),ok=mine.filter(live);
  const last=(list,a,b)=>list.filter(r=>{const d=dayDiff(r.date);return d>=a&&d<b}).length;
  const act=ok.filter(r=>!r.cancelled&&r.stage<4).length;
  const ern=earned(mine),m30=mine.filter(r=>liveR(r)&&dayDiff(r.feeOn)<30).reduce((s,r)=>s+r.reward.rate,0),m60=mine.filter(r=>liveR(r)&&dayDiff(r.feeOn)>=30&&dayDiff(r.feeOn)<60).reduce((s,r)=>s+r.reward.rate,0);
  const ann=S.announcements[0];
  return `${hero(me.event?esc(camp(me.event).name):'AIMER Ambassador Program',me.event?'Every registration through your event link is credited to you as the organizer.':'Refer future business leaders and earn rewards on successful admissions.',
    `<button class="btn primary" data-act="invite">Invite now ${icon('userplus')}</button><button class="btn" data-act="copy" data-text="${esc(linkFor(me))}">Copy link ${icon('copy')}</button>`,'Welcome back, '+esc(firstName(me)))}
  ${ann?`<div class="notice info mt" style="margin-bottom:0"><strong>${esc(ann.title)}:</strong> ${esc(ann.body)}</div>`:''}
  <div class="grid g4 mt">${kpi('k1','share',num(ok.length),'Total referrals',trend(last(ok,0,30),last(ok,30,60)))}${kpi('k2','user',num(act),'Active referrals','<span class="trend flat">In progress</span>')}
  ${kpi('k3','coins',money(ern),'Total earnings',`<span class="trend flat">${money(tsum(mine,['paid']))} paid</span>`)}${kpi('k4','chart',money(m30),'Earned, last 30 days',trend(m30,m60))}</div>
  <div class="mt">${linkCard(me)}</div>
  <div class="grid g-7-5 mt">${perfCard(mine,me.clicks)}${earningsBreakdown(mine)}</div>
  <div class="card mt"><div class="card-head"><div><h2>${icon('book')}Explore Courses</h2><p>Share a course-specific link so the student lands on the right programme.</p></div><button class="btn sm" data-act="nav" data-k="courses">View all courses${unread('course')?` <span class="count">${unread('course')}</span>`:''}</button></div>
  <div class="cgrid">${S.courses.filter(c=>c.status==='Active').sort((a,b)=>(b.launchedOn||'').localeCompare(a.launchedOn||'')).slice(0,4).map(c=>courseCard(c,me)).join('')}</div></div>
  <div class="card mt"><div class="card-head"><div><h2>${icon('image')}Marketing Resource Centre</h2><p>New creatives, videos, brochures and ready messages, all carrying your tracked link.</p></div><button class="btn sm" data-act="nav" data-k="resources">Open Resource Centre${unread('resource')?` <span class="count">${unread('resource')}</span>`:''}</button></div>
  <div class="rgrid">${resFor(me).sort((a,b)=>b.date.localeCompare(a.date)).slice(0,4).map(r=>resCard(r,me)).join('')}</div></div>
  <div class="card mt"><div class="card-head"><div><h2>${icon('trend')}Your incentive slabs</h2><p>Each slab’s rate applies only to the admissions inside it. An admission counts once its fee is verified.</p></div><button class="btn sm" data-act="nav" data-k="earnings">See earnings</button></div>
  <div class="grid g3">${PROGS.filter(pg=>countAdm(me.id,pg)||['UGBP','PGBP','HSBC'].includes(pg)).map(pg=>slabCard(me.id,pg)).join('')}</div></div>
  <div class="card mt"><div class="card-head"><h2>${icon('list')}Latest referrals</h2><button class="btn sm" data-act="nav" data-k="referrals">View all</button></div>
  ${mine.length?`<ul class="refs">${mine.sort((a,b)=>b.date.localeCompare(a.date)).slice(0,3).map(r=>refItem(r)).join('')}</ul>`:'<p class="empty">No referrals yet. Share your link to get started.</p>'}</div>`;
}
function vReferrals(){
  const me=person(meId()),f=S.ui.rf||'all',mine=S.refs.filter(r=>r.by===me.id).sort((a,b)=>b.date.localeCompare(a.date));
  const g={all:()=>true,progress:r=>!r.cancelled&&live(r)&&r.stage<3,admitted:r=>admitted(r),closed:r=>r.cancelled||!live(r)};
  const list=mine.filter(g[f]);
  return pagehead('My Referrals','You see each student’s programme and current stage. Contact details and counselling notes stay with the Admissions team.')+
  filters('rf',[['all','All',mine.length],['progress','In progress',mine.filter(g.progress).length],['admitted','Admitted',mine.filter(g.admitted).length],['closed','Closed',mine.filter(g.closed).length]])+
  (list.length?`<ul class="refs">${list.map(r=>refItem(r)).join('')}</ul>`:'<div class="card empty">No referrals in this view.</div>');
}
function vEarnings(){
  const me=person(meId()),mine=S.refs.filter(r=>r.by===me.id),rw=mine.filter(r=>r.reward).sort((a,b)=>a.prog.localeCompare(b.prog)||a.reward.n-b.reward.n),adj=S.adj.filter(a=>a.by===me.id);
  const calc=PROGS.map(pg=>{const rs=mine.filter(r=>r.prog===pg&&liveR(r));if(!rs.length)return '';const by=[0,0,0,0];rs.forEach(r=>by[r.reward.slab]++);
    return `<p style="margin:6px 0"><strong>${pg}:</strong> ${by.map((k,i)=>k?`${k} × ${money(S.pol.rates[pg][i])}`:'').filter(Boolean).join(' + ')} = <strong>${money(earned(rs))}</strong></p>`}).join('');
  const hist=S.batches.filter(b=>b.status==='paid').map(b=>{const its=b.items.filter(x=>ref(x.ref).by===me.id);return its.length?{b,amt:its.reduce((s,x)=>s+ref(x.ref).reward.t[x.t].amt,0)}:null}).filter(Boolean);
  return pagehead('Earnings & Payouts','Each admission’s incentive is paid in two parts: 50% once the admission fee is verified, and 50% once the first instalment clears. Every payout is approved by AIMER management before transfer.')+
  `<div class="grid g4">${kpi('k3','coins',money(earned(mine)+projected(me.id)),'Estimated total')}${kpi('k1','check',money(tsum(mine,['eligible'])),'Eligible')}${kpi('k2','pulse',money(tsum(mine,['in_batch','approved'])),'Awaiting approval')}${kpi('k4','wallet',money(tsum(mine,['paid'])),'Paid to you')}</div>
  ${calc?`<div class="card mt"><h2>How your incentive is calculated</h2><div class="mt">${calc}</div><p class="small muted" style="margin:10px 0 0">Policy v${S.pol.v}. Rates are progressive: each slab’s rate applies only to the admissions inside that slab.</p></div>`:''}
  <div class="card mt"><div class="card-head"><h2>Incentive statement</h2></div>${rw.length?`<div class="tbl"><table><thead><tr><th>Admission</th><th>Student</th><th class="num">Incentive</th><th>First 50%</th><th>Second 50%</th></tr></thead><tbody>
  ${rw.map(r=>`<tr><td>${r.prog} #${r.reward.n}<span class="sub">Slab ${SLAB_LBL[r.reward.slab]}${r.cancelled?', cancelled':''}</span></td><td>${esc(r.name)}</td><td class="num">${money(r.reward.rate)}</td>${r.reward.t.map(t=>`<td>${tchip(t)}<span class="sub">${money(t.amt)}${t.paidOn?', '+fmtDate(t.paidOn):''}</span></td>`).join('')}</tr>`).join('')}</tbody></table></div>`:'<p class="empty">Your statement fills in once a referred student’s admission fee is verified.</p>'}</div>
  ${adj.length?`<div class="card mt"><h2>Adjustments</h2><div class="tbl mt"><table><thead><tr><th>Date</th><th>Reason</th><th class="num">Amount</th><th>Status</th></tr></thead><tbody>${adj.map(a=>`<tr><td>${fmtDate(a.date)}</td><td>${esc(a.note)}</td><td class="num">${money(a.amount)}</td><td>${chip([a.status,a.status==='Open'?'warn':'ok'])}</td></tr>`).join('')}</tbody></table></div></div>`:''}
  <div class="grid g2 mt"><div class="card"><h2>Payout history</h2>${hist.length?`<ul class="list mt">${hist.map(h=>`<li><span>${fmtDate(h.b.paidOn)}<span class="small muted" style="display:block">Ref ${esc(h.b.transferRef)}</span></span><strong>${money(h.amt)}</strong></li>`).join('')}</ul>`:'<p class="empty">No payouts yet.</p>'}</div>
  <div class="card"><h2>Bank details</h2>${me.bank&&!S.ui.bankedit?`<p>Payouts go to <strong>${esc(me.bank.holder)}</strong>, account ending ${esc(me.bank.last4)} (${esc(me.bank.ifsc)}).</p><button class="btn sm" data-act="bankedit">Change bank details</button>`
  :`<p class="small muted">Add your bank details before your first payout. Only the Finance team can see them.</p><label class="field">Account holder name<input id="b-holder" autocomplete="name"></label><div class="formrow" style="margin-top:10px"><label class="field">Account number<input id="b-acct" inputmode="numeric" autocomplete="off"></label><label class="field">IFSC code<input id="b-ifsc" autocomplete="off"></label></div><button class="btn primary mt" data-act="banksave">Save bank details</button>`}</div></div>`;
}
function genMessage(me){
  const prog=S.ui.gprog||'All programmes',aud=S.ui.gaud||'Parent',ch=S.ui.gch||'WhatsApp',f=(S.ui.gtone||'Friendly')==='Friendly',url=linkFor(me);
  const you={Parent:'your child',Student:'you',Friend:'you or someone you know'}[aud];
  const greet=ch==='Instagram caption'?'':f?{Parent:'Hi! ',Student:'Hey! ',Friend:'Hi! '}[aud]:{Parent:'Dear Parent,\n\n',Student:'Hello,\n\n',Friend:'Hello,\n\n'}[aud];
  const about=prog==='All programmes'?`AIMER Business School offers ${progNames()}, and one of them could be a great fit for ${you}.`:`AIMER Business School’s ${prog} programme could be a great fit for ${you}.`;
  const cta=f?'Have a look and register here. Their admissions team will guide you through everything:':'You can register your interest here, and the admissions team will be in touch:';
  let t=greet+about+' '+cta+'\n'+url;
  if(ch==='WhatsApp'&&f)t+=`\n\n${firstName(me)}`;
  if(ch==='Email')t=`Subject: ${prog==='All programmes'?'AIMER Business School programmes':prog+' at AIMER Business School'}\n\n${f?greet.trim()+'\n\n':greet}${about} ${cta}\n${url}\n\n${f?'Thanks':'Best regards'},\n${me.name}`;
  if(ch==='Instagram caption')t+=`\n\n#AIMERBusinessSchool #${prog==='All programmes'?'BusinessEducation':prog.replace(/\s/g,'')}`;
  return t;
}
function vLeaders(){
  const me=meId(),rows=S.people.filter(p=>p.status==='VERIFIED').map(p=>{const rs=S.refs.filter(r=>r.by===p.id&&live(r));return {p,a:rs.filter(admitted).length,l:rs.length}}).filter(x=>x.l).sort((x,y)=>y.a-x.a||y.l-x.l);
  return pagehead('Leaderboard','Confirmed admissions across current campaigns. Only first names and categories are shown.')+
  `<div class="card" style="max-width:680px"><ul class="list">${rows.map((x,i)=>`<li class="${x.p.id===me?'me':''}"><span class="row" style="gap:12px"><span class="rank">${i+1}</span><span>${esc(shortName(x.p))}${x.p.id===me?' (you)':''}<span class="small muted" style="display:block">${cats(x.p)}</span></span></span><span style="text-align:right"><strong>${x.a}</strong> admitted<span class="small muted" style="display:block">${x.l} referrals</span></span></li>`).join('')}</ul></div>`;
}
function vHelp(){
  const me=person(meId()),mine=S.tickets.filter(t=>t.by===me.id).sort((a,b)=>b.created.localeCompare(a.created)),open=S.ui.tk&&mine.find(t=>t.id===S.ui.tk);
  if(open)return pagehead(esc(open.subject),`${open.id} · ${open.cat}`.replace(' · ',', '),`<button class="btn" data-act="tkclose">Back to tickets</button>`)+ticketThread(open,'partner');
  return pagehead('Help & Support','Questions about registration, your link, verification or payouts. Attribution disputes go to the Marketing team.')+
  `<div class="grid g-7-5"><div class="card"><h2>Your tickets</h2>${mine.length?`<ul class="list mt">${mine.map(t=>`<li><span><strong>${esc(t.subject)}</strong><span class="small muted" style="display:block">${t.id}, ${t.cat}, ${fmtDate(t.created)}</span></span><span class="row">${tkChip(t)}<button class="btn sm" data-act="tkopen" data-id="${t.id}">Open</button></span></li>`).join('')}</ul>`:'<p class="empty">No tickets yet.</p>'}</div>
  <div class="card"><h2>Raise a ticket</h2><label class="field mt">Topic<select id="tk-cat">${opt(['Registration','Verification','Referral link','Attribution dispute','Payout','Other'],'Payout')}</select></label>
  <label class="field" style="margin-top:12px">Subject<input id="tk-sub" autocomplete="off"></label><label class="field" style="margin-top:12px">Details<textarea id="tk-msg"></textarea></label><button class="btn primary mt" data-act="tknew">Send to support</button></div></div>`;
}
const tkChip=t=>chip([t.status==='Escalated'?'Escalated to '+t.team:t.status,{Open:'warn','In progress':'',Escalated:'warn',Resolved:'ok'}[t.status]]);
function ticketThread(t,mode){const p=person(t.by);
  const canReply=mode==='partner'?t.status!=='Resolved':true;
  return `<div class="card"><div class="row" style="justify-content:space-between"><span class="muted small">Raised by ${esc(p.name)} (${cats(p)}) on ${fmtDate(t.created)}</span>${tkChip(t)}</div>
  <div class="thread">${t.msgs.map(m=>`<div class="bubble ${m.from==='staff'?'staff':''}"><small>${m.from==='staff'?esc(m.who):esc(p.name)}, ${fmtTime(m.t)}</small>${esc(m.text)}</div>`).join('')}</div>
  ${canReply?`<label class="field">Reply<textarea id="tk-reply"></textarea></label><div class="row mt"><button class="btn primary" data-act="tkreply" data-id="${t.id}" data-mode="${mode}">Send reply</button>
  ${mode!=='partner'?`${t.status!=='Resolved'?`<button class="btn" data-act="tkresolve" data-id="${t.id}">Mark resolved</button>`:''}${mode==='support'&&t.status!=='Resolved'?`<button class="btn" data-act="tkesc" data-id="${t.id}" data-team="Marketing">Escalate to Marketing</button><button class="btn" data-act="tkesc" data-id="${t.id}" data-team="Finance">Escalate to Finance</button>`:''}`:''}</div>`:''}</div>`;
}
function vProfile(){
  const me=person(meId()),free=CATS.filter(c=>!me.affs.includes(c));
  return pagehead('Profile & Settings','Your login details and partner categories. One account can hold several categories, for example alumni and employee.')+
  `<div class="grid g3"><div class="card"><h2>Account</h2><div class="kv"><span>Name</span><b>${esc(me.name)}</b><span>Mobile</span><b>${esc(me.phone)}</b><span>Email</span><b>${esc(me.email||'–')}</b><span>Joined</span><b>${fmtDate(me.joined)}</b><span>Status</span><b>${chip(VSTAT[me.status])}</b><span>Referral code</span><b>${me.code||'Issued once verified'}</b></div></div>
  <div class="card"><h2>Partner categories</h2><div class="kv"><span>Categories</span><b>${cats(me)}</b><span>Verification</span><b>${esc(me.detail)}</b></div>${free.length&&!me.affs.includes('Event organizer')?'<button class="btn sm" data-act="jresume">Add another category</button>':''}</div>
  <div class="card"><h2>Change password</h2><label class="field mt">Current password<input id="pw-cur" type="password" autocomplete="current-password"></label><label class="field" style="margin-top:10px">New password<input id="pw-new" type="password" autocomplete="new-password"></label><label class="field" style="margin-top:10px">Confirm new password<input id="pw-new2" type="password" autocomplete="new-password"></label><button class="btn primary sm mt" data-act="pwchange">Update password</button></div></div>`;
}
const opt=(list,cur)=>list.map(x=>`<option ${x===cur?'selected':''}>${esc(x)}</option>`).join('');
