/* ---------- shell, routing and render ---------- */
const PUBLIC=['landing','join','login','adminlogin','forgot','register','enquire','setpw'];
const PATHS={landing:'/',join:'/join',login:'/login',adminlogin:'/admin',forgot:'/forgot',enquire:'/enquire',setpw:'/set-password'};
const AV={dashboard:vDash,partners:vPartners,campaigns:vCampaigns,links:vLinks,leads:vLeads,admissions:vAdmissionsA,incentives:vIncentives,payouts:vPayouts,approvals:vApprovals,events:vEvents,courses:vCoursesA,resources:vResourcesA,reports:vReports,support:vSupport,roles:vRoles,settings:vSettings,audit:vAudit};
const PV={home:vHome,referrals:vReferrals,earnings:vEarnings,courses:vCoursesP,resources:vResourcesP,leaders:vLeaders,help:vHelp,profile:vProfile};
const GV={landing:vLanding,join:vJoin,login:vLogin,adminlogin:vAdminLogin,forgot:vForgot,register:vRegister,enquire:vEnquire,setpw:vSetPw};
function badge(k){const r=role(),n={partners:S.people.filter(p=>p.status==='UNDER_REVIEW').length,leads:['superadmin','admissions'].includes(r)?S.refs.filter(x=>live(x)&&!x.cancelled&&x.stage===0&&x.sync==='ok').length:S.refs.filter(x=>x.attribution==='review').length,
  admissions:S.refs.filter(x=>live(x)&&!x.cancelled&&x.stage===2).length,incentives:S.refs.filter(x=>live(x)&&!x.cancelled&&(x.stage===3||x.stage===4)).length,payouts:r==='ceo'?0:tranches(['eligible']).length,
  approvals:S.approvals.filter(a=>a.status==='Pending').length+S.batches.filter(b=>b.status==='pending').length,support:S.tickets.filter(t=>can('tickets')?t.status==='Open':t.status==='Escalated'&&t.team===(r==='marketing'?'Marketing':'Finance')).length,
  courses:meId()?unread('course'):S.courses.filter(c=>c.status==='Draft').length,resources:meId()?unread('resource'):0,
  settings:S.refs.filter(x=>x.sync==='failed').length,help:meId()?S.tickets.filter(t=>t.by===meId()&&t.msgs.length&&t.msgs[t.msgs.length-1].from==='staff'&&t.status!=='Resolved').length:0}[k];return n?`<span class="count">${n}</span>`:''}
function appShell(menu,content,u,bottom){
  const nb=([k,l,ic])=>`<button data-act="nav" data-k="${k}" class="${k===S.view?'on':''}" ${k===S.view?'aria-current="page"':''}>${icon(ic)}${l}${badge(k)}</button>`;
  return `<div class="mtop"><button data-act="sbopen" aria-label="Open menu">${icon('menu')}</button><img src="${IMG.logoW}" alt="AIMER Business School"></div>
  <div class="backdrop ${S.ui.sb?'show':''}" data-act="sbclose"></div>
  <div class="app"><aside class="sb ${S.ui.sb?'open':''}"><button class="sb-logo" data-act="brand" aria-label="Go to dashboard"><img src="${IMG.logoW}" alt="AIMER Business School"></button>
  <div class="sb-sec">Main</div><nav class="sb-nav" aria-label="Main">${menu.map(nb).join('')}</nav>
  <div class="sb-foot"><div class="who"><b>${esc(u.name)}</b>${esc(u.sub)}</div>${bottom.map(nb).join('')}<button data-act="logout" data-lock="no">${icon('logout')}Log out</button></div></aside>
  <main class="main"><div class="wrap">${content}</div></main></div>`;
}
function pubShell(content){const m=meId();
  return `<header class="pubtop"><button class="sb-logo" data-act="brand" style="padding:0;margin:0;border:0" aria-label="AIMER Ambassador Program home"><img class="logo-l" src="${IMG.logoC}" alt="AIMER Business School"><img class="logo-d" src="${IMG.logoW}" alt="AIMER Business School"></button>
  <div class="row">${S.session?'<button class="btn sm primary" data-act="goto" data-v="home">Back to my dashboard</button>':`<button class="btn sm" data-act="goto" data-v="login">Log in</button><button class="btn sm primary" data-act="goto" data-v="join">Register</button>`}</div></header>
  <main class="pub">${content}</main>`;
}
const loadingScreen=()=>`<div class="pub"><div class="card empty" style="max-width:420px;margin:60px auto">${icon('pulse')}<p style="margin:10px 0 0">Loading your account…</p></div></div>`;
function viewFromUrl(){
  const p=(location.pathname.replace(/\/+$/,'')||'/'),m=p.match(/^\/r\/([A-Za-z0-9]{4,12})$/i);
  if(m){const q=new URLSearchParams(location.search);return{view:'register',code:m[1].toUpperCase(),course:q.get('course'),res:q.get('res')}}
  const f=Object.entries(PATHS).find(([,v])=>v===p);return{view:f?f[0]:p==='/app'?'home':'landing'}}
function syncUrl(){
  let t=S.session?'/app':(S.view==='register'&&S.pub&&S.pub.code&&!S.pub.preview?null:PATHS[S.view]);
  if(t&&location.pathname!==t){try{history.pushState(null,'',t)}catch(e){}}
}
function render(top){
  if(S.booting){$('root').innerHTML=loadingScreen();return}
  const m=meId(),a=adminUser();let html;
  if(S.session&&m&&!person(m)){S.session=null}
  if(m){const p=person(m),menu=p.status==='VERIFIED'?PMENU:[['home','Dashboard','home'],['help','Help & Support','help']];
    const ok=[...menu.map(x=>x[0]),'profile','register','join'];
    if(!ok.includes(S.view))S.view='home';
    html=S.view==='register'?pubShell(vRegister()):S.view==='join'?pubShell(vJoin()):appShell(menu,partnerTop()+PV[S.view](),{name:p.name,sub:cats(p)},[['profile','Profile & Settings','settings']]);
  }else if(a){const menu=MENU.filter(([k])=>ACCESS[k][a.role]);if(!menu.some(x=>x[0]===S.view))S.view='dashboard';html=appShell(menu,AV[S.view](),{name:a.name,sub:ROLES[a.role]},[])}
  else{if(!PUBLIC.includes(S.view))S.view='landing';html=pubShell(GV[S.view]())}
  $('root').innerHTML=html;
  const q=$('qr');if(q)mkQR(q,q.dataset.url);
  syncUrl();if(top)window.scrollTo(0,0);
}
