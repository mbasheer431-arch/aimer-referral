/* ---------- sign-in, actions and events ---------- */
const v=id=>(document.getElementById(id)||{}).value||'';
const toE164=p=>{let s=String(p||'').replace(/[^\d+]/g,'');if(s.startsWith('00'))s='+'+s.slice(2);return /^\+\d{8,15}$/.test(s)?s:null};
const slugOf=c=>String(c).toLowerCase().replace(/\s+/g,'-');
const fileExt=f=>((f.name||'').split('.').pop()||'bin').toLowerCase().replace(/[^a-z0-9]/g,'').slice(0,5);
const safeName=f=>(f.name||'file').replace(/[^A-Za-z0-9._-]+/g,'-').slice(-60);
function openDlg(html){const d=$('dlg');d.innerHTML=`<div class="dlg">${html}<div class="row mt" style="justify-content:flex-end"><button class="btn" data-act="dclose" data-lock="no">Close</button></div></div>`;if(!d.open)d.showModal()}
async function refresh(top){await hydrate();render(top)}
const deny=p=>{if(can(p))return false;toast('Your role doesn’t have permission for this');return true};
const refUid=id=>(S.refs.find(r=>r.id===id)||{}).uid;
const copyText=t=>(navigator.clipboard?navigator.clipboard.writeText(t):Promise.reject()).then(()=>toast('Copied')).catch(()=>toast('Copying was blocked. Select the text and copy it.'));

async function boot(){
  const u=await DB.auth.sessionUser();if(!u){S.session=null;return false}
  const b=await DB.rpc('session_bootstrap');   // one request tells us who this is and, for partners, carries everything they need
  if(b.kind==='admin'){S.session={kind:'admin',id:u.id,role:b.role,name:b.name};DB.rpc('touch_admin_login').catch(()=>{})}
  else if(b.kind==='admin_inactive'){await DB.auth.signOut();S.session=null;throw new Error('This admin account is deactivated.')}
  else if(b.kind==='partner'){S.session={kind:'partner',id:u.id};S._pre=b}
  else{await DB.auth.signOut();S.session=null;throw new Error('We couldn’t find a partner account for this login.')}
  await hydrate();
  if(S.session.kind==='admin')loadLsqStatus();
  return true;
}
const withTimeout=(p,ms,msg)=>{let t;return Promise.race([p,new Promise((_,rej)=>{t=setTimeout(()=>rej(new Error(msg)),ms)})]).finally(()=>clearTimeout(t))};
async function loadLsqStatus(){try{S.lsq=await DB.invoke('lsq-admin',{action:'status'})}catch(e){S.lsq=null}}
function routeAfterLogin(){
  if(S.session.kind==='admin'){S.view='dashboard';return}
  const p=person(S.session.id),v=S.verify||{};
  if(p&&['PENDING','EMAIL_VERIFIED'].includes(p.status)&&v.email_ok&&v.phone_required&&!v.phone_ok){J=newJ();J.step='phone';S.view='join'}else S.view='home';
}
async function openRefPage(code,courseParam,res){
  S.view='register';S.pub={loading:true,code};L=newL();render();
  try{
    const rows=await DB.rpc('resolve_referral_code',{p_code:code}),r=(rows||[])[0];
    if(!r){S.pub={invalid:true,code};render(true);return}
    const courses=r.courses||[],pre=courseParam?(courses.find(c=>slugOf(c.code)===String(courseParam).toLowerCase())||{}).code:null;
    S.pub={code,first:r.first_name,active:r.active,event:r.event_name,courses,course:pre||null,res:/^[0-9a-f-]{36}$/i.test(res||'')?res:null};
    const key='aimer-click-'+code+(pre||'');
    try{if(!sessionStorage.getItem(key)){sessionStorage.setItem(key,'1');DB.rpc('record_click',{p_code:code,p_course_code:pre||null,p_resource:S.pub.res}).catch(()=>{})}}catch(e){}
  }catch(e){S.pub={invalid:true,code}}
  render(true);
}
const A={
  nav:async e=>{S.view=e.dataset.k;S.ui.sb=false;S.ui.tk=null;S.ui.cv=null;S.ui.ced=null;if(S.session)await hydrate();render(true)},
  filter:e=>{S.ui[e.dataset.key]=e.dataset.k;render()},
  sbopen:()=>{S.ui.sb=true;render()},sbclose:()=>{S.ui.sb=false;render()},
  brand:()=>{S.view=meId()?'home':adminUser()?'dashboard':'landing';S.ui.sb=false;if(!S.session)S.pub=null;render(true)},
  goto:e=>{const t=e.dataset.v;if(t==='join'&&!S.session)J=newJ();if(t==='forgot')F={step:'id',err:'',email:''};if((t==='register'||t==='enquire')&&!S.session)L=newL();if(t==='enquire')S.pub=null;S.ui.lerr=S.ui.aerr=S.ui.notice='';S.view=t;render(true)},
  copy:e=>copyText(e.dataset.text),
  dclose:()=>{$('dlg').close()},
  qr:()=>{const p=person(meId());openDlg(`<h2>Your QR code</h2><p class="small muted">Scanning it opens your referral page.</p><div class="qrbig" id="qrd"></div><p class="small" style="word-break:break-all;text-align:center">${esc(linkFor(p))}</p>`);mkQR($('qrd'),linkFor(p))},
  invite:()=>{const p=person(meId()),m=inviteText(p);openDlg(`<h2>Invite someone</h2><div class="msg">${esc(m)}</div><div class="row"><a class="btn primary" href="https://wa.me/?text=${encodeURIComponent(m)}" target="_blank" rel="noopener">${icon('chat')}WhatsApp</a><a class="btn" href="https://t.me/share/url?url=${encodeURIComponent(linkFor(p))}&text=${encodeURIComponent('Have a look at AIMER Business School')}" target="_blank" rel="noopener">${icon('send')}Telegram</a><button class="btn" data-act="copy" data-text="${esc(m)}">${icon('copy')}Copy</button></div><p class="small muted mt">More messages, captions and creatives are in the Resource Centre.</p>`)},
  tryform:()=>{const p=person(meId()),ev=p.event?camp(p.event):null;L=newL();
    S.pub={code:p.code,first:firstName(p),active:true,event:ev?ev.name:null,courses:S.courses.filter(c=>eligibleFor(p,c.code)).map(c=>({code:c.code,name:c.name,short:c.short})),course:null,preview:true};S.view='register';render(true)},
  /* ----- sign in and out ----- */
  plogin:async()=>{const email=v('li-id').trim().toLowerCase(),pw=v('li-pw');S.ui.lemail=email;
    if(!email||!pw){S.ui.lerr='Enter your email and password.';return render()}
    try{await DB.auth.signIn(email,pw);S.booting=true;render();await boot();S.booting=false;S.ui.lerr='';routeAfterLogin();render(true);toast(`Welcome back, ${S.session.kind==='admin'?S.session.name.split(' ')[0]:firstName(person(S.session.id))}`)}
    catch(e){S.booting=false;S.ui.lerr=e.message;S.view='login';render()}},
  alogin:async()=>{const email=v('ad-id').trim().toLowerCase(),pw=v('ad-pw');
    if(!email||!pw){S.ui.aerr='Enter your work email and password.';return render()}
    try{await DB.auth.signIn(email,pw);S.booting=true;render();await boot();S.booting=false;
      if(S.session.kind!=='admin'){await DB.auth.signOut();S.session=null;S.ui.aerr='This account isn’t an admin account. Partners log in from the partner login page.';S.view='adminlogin';return render()}
      S.ui.aerr='';routeAfterLogin();render(true)}
    catch(e){S.booting=false;S.ui.aerr=e.message;S.view='adminlogin';render()}},
  logout:async()=>{try{await DB.auth.signOut()}catch(_){}const cat=S.catalog;S=newState();S.catalog=cat;J=newJ();L=newL();S.view='landing';render(true);toast('You’ve been logged out')},
  fsend:async()=>{const email=v('fg-id').trim().toLowerCase();if(!isEmail(email)){F.err='Enter the email you registered with.';return render()}
    try{await DB.auth.resetPassword(email);F={step:'sent',err:'',email};render()}
    catch(e){F.err=/rate|too many|limit/i.test(e.message)?'Too many reset emails were sent recently. Please wait an hour and try again.':/smtp|sending email|not authorized|mail/i.test(e.message)?'We couldn’t send the email right now. Please contact the AIMER team.':e.message;render()}},
  setpw:async()=>{const a=v('sp-pw'),b=v('sp-pw2');if(a.length<8){S.ui.perr='Use at least 8 characters.';return render()}if(a!==b){S.ui.perr='The passwords don’t match.';return render()}
    await DB.auth.updatePassword(a);S.ui.perr='';if(!S.session){await boot()}routeAfterLogin();render(true);toast('Password saved. You’re signed in.')},
  pwchange:async()=>{const p=person(meId());if(!v('pw-cur'))return toast('Enter your current password');if(v('pw-new').length<8)return toast('Use at least 8 characters for the new password');if(v('pw-new')!==v('pw-new2'))return toast('The new passwords don’t match');
    try{await DB.auth.signIn(p.email,v('pw-cur'))}catch(_){return toast('Your current password isn’t right')}
    await DB.auth.updatePassword(v('pw-new'));render();toast('Password updated')},
  /* ----- partner sign-up ----- */
  jsend:async()=>{const d=J.d;J.err='';const e164=toE164(composePhone(d.cc||CC_OF[d.country||'India']||'+91',d.phone));
    if(!(d.name||'').trim())J.err='Enter your full name.';else if(!(d.phone||'').trim())J.err='Enter your mobile number.';else if(!e164)J.err='Check your mobile number. Pick the country code and type the number.';else if(!isEmail((d.email||'').trim()))J.err='Enter a valid email address.';
    else if((d.pw||'').length<8)J.err='Use at least 8 characters for your password.';else if(d.pw!==d.pw2)J.err='The passwords don’t match.';else if(!d.terms)J.err='Please accept the programme terms to continue.';
    else if(d.cat==='Employee'&&empDomains().length&&!empDomains().some(x=>x==='name@'+(d.email||'').split('@')[1].toLowerCase()))J.err='Employees sign up with their official AIMER email ('+empDomains().join(' or ')+'). Choose another category if you’re not AIMER staff.';
    if(J.err)return render();
    J.busy=true;J.busyMsg='';render();
    const instant=!(S.catalog&&S.catalog.email_confirmation_required),email=d.email.trim().toLowerCase();
    const slow=setTimeout(()=>{if(J.busy){J.busyMsg=instant?'Still working… please keep this page open.':'Still working… sending your confirmation email can take a few seconds.';render()}},5000);
    const enter=async()=>{J.busy=false;J.d.pw=J.d.pw2='';S.booting=true;render();await boot();S.booting=false;routeAfterLogin();render(true)};
    try{
      if(instant){
        const r=await withTimeout(DB.register({name:d.name.trim(),phone:e164,email,password:d.pw,country:d.country||'',category:d.cat||'Student',note:(d.note||'').trim()}),30000,'timeout').catch(()=>({fallback:true}));
        if(!r.ok&&!r.fallback)throw new Error(r.error);
        let signed=false;   // after a timeout the account may already exist, so try signing in before using the email route
        try{J.busyMsg='Signing you in…';render();await withTimeout(DB.auth.signIn(email,d.pw),25000,'timeout');signed=true}catch(_){}
        if(signed){clearTimeout(slow);await enter();return}
        if(r.ok){clearTimeout(slow);J.busy=false;J.d.pw=J.d.pw2='';S.ui.lemail=email;S.view='login';render(true);toast('Your account is ready. Log in with your email and password.');return}
      }
      const chk=await withTimeout(DB.rpc('check_signup',{p_phone:e164,p_email:d.email,p_category:d.cat}),20000,'We couldn’t reach the server. Check your connection and try again.');
      if(chk==='employee_email_required')throw new Error('Employees sign up with their official AIMER email'+(empDomains().length?' ('+empDomains().join(' or ')+')':'')+'. Choose another category if you’re not AIMER staff.');
      if(chk==='phone_taken')throw new Error('This mobile number is already registered. Log in instead.');
      if(chk==='email_taken')throw new Error('An account with this email already exists. Log in instead.');
      const res=await withTimeout(DB.auth.signUp(email,d.pw,{account_type:'partner',full_name:d.name.trim(),phone:e164,country:d.country||'',category:d.cat||'Student',category_note:(d.note||'').trim()}),45000,'This is taking longer than usual. Your account may already be created, so check your email, or try logging in.');
      clearTimeout(slow);J.busy=false;J.d.pw=J.d.pw2='';
      if(res.session){S.booting=true;render();await boot();S.booting=false;routeAfterLogin();render(true)}else{J.step='confirm';render(true)}
    }catch(e){clearTimeout(slow);J.busy=false;J.err=e.message;render()}},
  jresend:async()=>{try{await DB.auth.resend((J.d.email||'').trim().toLowerCase());toast('Sent again. Check your inbox.')}catch(e){J.err=e.message;render()}},
  jphonestep:()=>{J=newJ();J.step='phone';S.view='join';render(true)},
  jphonesend:async()=>{const p=person(meId()),e164=toE164(p.phone);J.err='';if(!e164){J.err='Your saved number needs a country code. Contact support to correct it.';return render()}
    try{await DB.auth.updatePhone(e164);J.codeSent=true;render();toast('Code sent. It can take a minute to arrive.')}catch(e){J.err=/sms|provider|phone/i.test(e.message)?'We couldn’t send the code right now. Please try again in a few minutes.':e.message;render()}},
  jphoneverify:async()=>{const p=person(meId()),code=v('j-code').trim();J.err='';if(!/^\d{6}$/.test(code)){J.err='Enter the 6-digit code.';return render()}
    try{await DB.auth.verifyPhone(toE164(p.phone),code);await hydrate();J.err='';
      if(person(meId()).status==='VERIFIED'){J.step='done';render(true)}else{J.err='Your number is confirmed, but your account isn’t verified yet. Please refresh in a moment.';render()}}
    catch(e){J.err=/expired|invalid|token/i.test(e.message)?'That code isn’t right or has expired. Send a new one.':e.message;render()}},
  jresume:()=>{const p=person(meId());J=newJ();J.step='category';J.adding=true;J.d.cat=CATS.find(c=>!p.affs.includes(c))||'Student';S.view='join';render(true)},
  jcatgo:async()=>{const d=J.d;J.err='';J.busy=true;render();
    try{await DB.rpc('submit_affiliation',{p_category:d.cat,p_details:{note:(d.note||'').trim()}});await hydrate();J.busy=false;S.view='profile';render(true);toast('Category added')}catch(e){J.busy=false;J.err=e.message;render()}},
  jdash:()=>{J=newJ();S.view='home';render(true)},
  /* ----- public referral and enquiry forms ----- */
  lsubmit:async e=>{const mode=e.dataset.mode,f={course:v('l-prog'),name:v('l-name').trim(),phone:composePhone(v('l-cc'),v('l-phone')),email:v('l-email').trim(),country:v('l-country'),level:v('l-level'),code:mode==='code'?v('l-code').trim().toUpperCase():''};
    L.d={...L.d,prog:f.course,name:f.name,phone:v('l-phone').trim(),email:f.email,country:f.country,level:f.level,code:f.code,consent:$('l-consent').checked};L.err='';
    if(!f.name)L.err='Enter the student’s full name.';else if(!f.phone||f.phone.replace(/\D/g,'').length<8||f.phone.replace(/\D/g,'').length>15)L.err='Check the WhatsApp number. Pick the country code and type the number.';else if(f.email&&!isEmail(f.email))L.err='Check the email address.';else if(!L.d.consent)L.err='Please agree to be contacted so our team can reach you.';
    if(L.err)return render();
    L.busy=true;render();
    try{const pub=S.pub||{};
      await DB.invoke('submit-referral',{name:f.name,phone:f.phone,email:f.email,course:f.course,country:f.country,level:f.level,source:mode==='code'?'code':'link',code:mode==='code'?f.code:(pub.code||''),
        courseLink:mode!=='code'&&!!pub.course&&pub.course===f.course,resource:mode!=='code'?(pub.res||''):'',website:v('l-website')});
      L.busy=false;L.step='done';L.d={};render(true)}catch(err){L.busy=false;L.err=err.message;render()}},
  lnew:()=>{L=newL();render(true)},
  /* ----- partner: bank, notifications, courses, resources ----- */
  banksave:async()=>{await DB.rpc('set_bank_details',{p_holder:v('b-holder'),p_account:v('b-acct'),p_ifsc:v('b-ifsc')});S.ui.bankedit=false;await refresh();toast('Bank details saved. Only the Finance team can use them.')},
  bankedit:()=>{S.ui.bankedit=true;render()},
  notifs:()=>{const m=meId(),ns=myNotifs();openDlg(`<div class="row" style="justify-content:space-between"><h2>Notifications</h2>${unread()?'<button class="linkbtn" data-act="nreadall">Mark all as read</button>':''}</div><ul class="nlist">${ns.map(n=>`<li><span class="ud ${n.read.includes(m)?'r':''}"></span><div style="flex:1"><strong>${esc(n.title)}</strong><div class="small muted">${esc(n.body)}</div><div class="small muted">${fmtTime(n.date)}</div></div>${n.target&&n.target.view?`<button class="btn sm" data-act="nopen" data-id="${n.id}">Open</button>`:''}</li>`).join('')||'<li class="muted">No notifications yet.</li>'}</ul>`)},
  nopen:async e=>{const n=S.notifs.find(x=>x.id===e.dataset.id),m=meId();await DB.rpc('mark_notifications_read',{p_ids:[n.id]});if(!n.read.includes(m))n.read.push(m);$('dlg').close();
    S.view=n.target.view;if(n.target.view==='courses')S.ui.cv=n.target.id;if(n.target.view==='resources'){S.ui.rtab='library';['rft','rfc','rfl','rfm'].forEach(k=>S.ui[k]=null)}
    render(true);if(n.target.view==='resources'&&n.target.id)A.rprev({dataset:{id:n.target.id}})},
  nreadall:async()=>{await DB.rpc('mark_notifications_read',{});const m=meId();myNotifs().forEach(n=>{if(!n.read.includes(m))n.read.push(m)});$('dlg').close();render()},
  cview:e=>{const c=course(e.dataset.id);S.view='courses';S.ui.cv=c.code;DB.rpc('track_course',{p_course:c.uid,p_action:'view'}).catch(()=>{});
    const m=meId(),ids=S.notifs.filter(n=>n.kind==='course'&&n.target.id===c.code&&n.aud.includes(m)&&!n.read.includes(m)).map(n=>n.id);if(ids.length){ids.forEach(i=>S.notifs.find(n=>n.id===i).read.push(m));DB.rpc('mark_notifications_read',{p_ids:ids}).catch(()=>{})}render(true)},
  cback:()=>{S.ui.cv=null;render(true)},
  cbro:e=>{const c=course(e.dataset.id);DB.rpc('track_course',{p_course:c.uid,p_action:'brochure'}).catch(()=>{});if(c.brochureUrl)window.open(c.brochureUrl,'_blank','noopener');else toast('The brochure isn’t uploaded yet')},
  cqr:e=>{const p=person(meId()),c=course(e.dataset.id),u=linkFor(p,{course:c.code});DB.rpc('track_course',{p_course:c.uid,p_action:'qr'}).catch(()=>{});openDlg(`<h2>${esc(c.name)} QR code</h2><p class="small muted">Opens the registration page with ${esc(c.name)} selected and your referral attached.</p><div class="qrbig" id="qrd"></div><p class="small" style="word-break:break-all;text-align:center">${esc(u)}</p>`);mkQR($('qrd'),u)},
  rprev:e=>{const p=person(meId()),r=S.resources.find(x=>x.id===e.dataset.id);if(!r)return;track(p.id,r.id,'preview');const link=resLink(p,r),d=$('dlg');d.classList.add('wide');
    openDlg(`<h2>${esc(r.title)}</h2><div class="tags row mt" style="gap:6px">${chip([r.type,''])}${chip([r.course==='All'?'All programmes':r.course,'grey'])}${chip([r.lang,'grey'])}</div><div class="prevbox">${rthumb(r,true)}</div>
    ${r.text?`<div class="msg">${esc(resText(p,r))}</div>`:`<p class="small muted">${esc(r.file||'')}</p>`}<p class="small"><strong>Your tracked link:</strong> <span style="word-break:break-all">${esc(link)}</span></p>
    <div class="row">${r.filePath?`<button class="btn primary" data-act="rdown" data-id="${r.id}">${icon('download')}Download</button>`:`<button class="btn primary" data-act="rcopy" data-id="${r.id}">${icon('copy')}Copy with my link</button>`}<a class="btn" href="https://wa.me/?text=${encodeURIComponent(resText(p,r))}" target="_blank" rel="noopener" data-track="${r.id}">${icon('chat')}WhatsApp</a><button class="btn" data-act="copy" data-text="${esc(link)}">${icon('link')}Copy link</button></div>`);
    d.addEventListener('close',()=>d.classList.remove('wide'),{once:true});
    const m=p.id,ids=S.notifs.filter(n=>n.kind==='resource'&&n.target.id===r.id&&n.aud.includes(m)&&!n.read.includes(m)).map(n=>n.id);if(ids.length){ids.forEach(i=>S.notifs.find(n=>n.id===i).read.push(m));DB.rpc('mark_notifications_read',{p_ids:ids}).catch(()=>{})}},
  rdown:async e=>{const r=S.resources.find(x=>x.id===e.dataset.id);track(meId(),r.id,'download');const u=await DB.signedOne('resources',r.filePath,true);window.open(u,'_blank','noopener')},
  rcopy:e=>{const p=person(meId()),r=S.resources.find(x=>x.id===e.dataset.id);track(p.id,r.id,'copy');return copyText(resText(p,r))},
  rqr:e=>{const p=person(meId()),r=S.resources.find(x=>x.id===e.dataset.id),u=resLink(p,r);track(p.id,r.id,'qr');openDlg(`<h2>QR code: ${esc(r.title)}</h2><p class="small muted">Put this on the printed material. Scans are credited to you and tracked to this material and campaign.</p><div class="qrbig" id="qrd"></div><p class="small" style="word-break:break-all;text-align:center">${esc(u)}</p>`);mkQR($('qrd'),u)},
  /* ----- support tickets ----- */
  tkopen:e=>{S.ui.tk=e.dataset.id;render(true)},tkclose:()=>{S.ui.tk=null;render(true)},
  tknew:async()=>{const sub=v('tk-sub').trim(),msg=v('tk-msg').trim();if(!sub||!msg)return toast('Add a subject and some details');
    const [t]=await DB.insert('support_tickets',{partner_id:meId(),category:v('tk-cat'),subject:sub,status:'Open',team:'Support'});
    await DB.insert('ticket_messages',{ticket_id:t.id,author:meId(),is_staff:false,body:msg});await refresh();toast('Ticket sent. Support usually replies within one working day.')},
  tkreply:async e=>{const t=S.tickets.find(x=>x.id===e.dataset.id),txt=v('tk-reply').trim();if(!txt)return;const staff=e.dataset.mode!=='partner';
    await DB.insert('ticket_messages',{ticket_id:t.uid,author:S.session.id,is_staff:staff,body:txt});if(staff&&t.status==='Open')await DB.update('support_tickets',{status:'In progress'},{id:t.uid});await refresh();toast('Reply sent')},
  tkresolve:async e=>{const t=S.tickets.find(x=>x.id===e.dataset.id);await DB.update('support_tickets',{status:'Resolved'},{id:t.uid});await refresh();toast('Ticket resolved')},
  tkesc:async e=>{if(deny('tickets'))return;const t=S.tickets.find(x=>x.id===e.dataset.id);await DB.update('support_tickets',{status:'Escalated',team:e.dataset.team},{id:t.uid});
    await DB.insert('ticket_messages',{ticket_id:t.uid,author:S.session.id,is_staff:true,body:`Escalated to the ${e.dataset.team} team.`});await refresh();toast('Escalated')},
  /* ----- partners ----- */
  pverify:async e=>{if(deny('partner.manage'))return;await DB.rpc('review_partner',{p_partner:e.dataset.id,p_decision:'verify'});await refresh();toast('Partner verified; their link is now live')},
  preject:async e=>{if(deny('partner.manage'))return;if(!confirm('Reject this partner?'))return;await DB.rpc('review_partner',{p_partner:e.dataset.id,p_decision:'reject'});await refresh()},
  psuspend:async e=>{if(deny('partner.manage'))return;if(!confirm('Suspend this partner? Their link stops crediting new enquiries.'))return;await DB.rpc('review_partner',{p_partner:e.dataset.id,p_decision:'suspend'});await refresh()},
  preinstate:async e=>{if(deny('partner.manage'))return;await DB.rpc('review_partner',{p_partner:e.dataset.id,p_decision:'reinstate'});await refresh()},
  pimport:async()=>{if(deny('partner.manage'))return;const rows=v('imp').split('\n').map(l=>l.split(',').map(x=>x.trim())).filter(x=>x[0]).map(([name,phone,email,category])=>({name,phone,email,category}));
    if(!rows.length)return toast('Paste at least one line');const r=await DB.invoke('admin-partners',{action:'import',rows});await refresh();toast(`Invited ${r.imported}${r.skipped.length?`, skipped ${r.skipped.length}: ${r.skipped[0]}`:''}`)},
  regen:async e=>{if(deny('links.manage'))return;if(!confirm('Issue a new code? The old link and code stop working.'))return;await DB.rpc('regenerate_referral_code',{p_partner:e.dataset.id});await refresh();toast('New code issued')},
  addorg:async()=>{if(deny('events'))return;const r=await DB.invoke('admin-partners',{action:'organizer',name:v('eo-name').trim(),phone:v('eo-phone').trim(),email:v('eo-email').trim(),campaign_code:v('eo-ev')});await refresh();toast('Organizer invited. They set a password from the email we sent.')},
  /* ----- campaigns, events, policy ----- */
  cset:async e=>{const c=camp(e.dataset.id);if(deny(c.kind==='event'?'events':'campaign.status'))return;await DB.rpc('set_campaign_status',{p_campaign:c.uid,p_status:e.dataset.v});await refresh();toast(`${c.name}: ${e.dataset.v.toLowerCase()}`)},
  addcamp:async()=>{if(deny('campaign.create'))return;const progs=PROGS.filter((p,i)=>$('nc-p'+i)&&$('nc-p'+i).checked);
    await DB.rpc('create_campaign',{p_name:v('nc-name'),p_description:v('nc-desc'),p_terms:v('nc-terms'),p_start:v('nc-start'),p_end:v('nc-end'),p_course_codes:progs});await refresh();toast('Sent to Management for approval')},
  propose:async()=>{if(deny('policy.propose'))return;const rates={};PROGS.forEach((p,pi)=>{const el=document.getElementById(`rt-${pi}-0`);if(!el)return;const r=[0,1,2,3].map(i=>parseInt(v(`rt-${pi}-${i}`),10));if(r.some(x=>!(x>=0)))return;if(r.some((x,i)=>x!==S.pol.rates[p][i]))rates[course(p).uid]=r});
    const codes=Object.keys(rates).map(id=>S.courses.find(c=>c.uid===id).code);if(!codes.length)return toast('Change at least one rate first');
    await DB.rpc('request_approval',{p_type:'policy',p_summary:'Rate change for '+codes.join(', '),p_payload:{rates,note:v('rt-note')}});await refresh();toast('Sent to Management for approval')},
  addevent:async()=>{if(deny('events'))return;const name=v('ev-name').trim();if(!name)return toast('Enter the event name');
    const code='EVT-'+name.toUpperCase().replace(/[^A-Z0-9]+/g,'-').replace(/^-|-$/g,'').slice(0,16)+'-'+Math.random().toString(36).slice(2,5).toUpperCase();
    await DB.insert('campaigns',{code,name,kind:'event',description:'',terms:'Leads attributed to the event organizer.',location:v('ev-loc').trim(),start_date:v('ev-start'),end_date:v('ev-end'),status:'Draft',created_by:S.session.id});
    await refresh();toast('Event created. Register an organizer to activate it.')},
  evupload:async()=>{if(deny('events'))return;const c=camp(v('el-ev'));if(!c)return toast('Choose an event with an organizer');
    const rows=v('el-list').split('\n').map(l=>l.split(',').map(x=>x.trim())).filter(x=>x[0]).map(([name,phone,prog])=>({name,phone,course:(S.courses.find(x=>x.code.toLowerCase()===(prog||'').toLowerCase())||{}).code||prog}));
    if(!rows.length)return toast('Paste at least one lead');const r=await DB.rpc('staff_upload_event_leads',{p_campaign_code:c.id,p_rows:rows});
    DB.invoke('lsq-admin',{action:'sync'}).catch(()=>{});await refresh();toast(`Uploaded ${r.ok} leads${r.skipped?`, skipped ${r.skipped}`:''}`)},
  /* ----- leads, admissions, attribution ----- */
  advance:async e=>{if(deny('lead.update'))return;const rf=S.refs.find(r=>r.id===e.dataset.id);await DB.rpc('advance_referral',{p_referral:refUid(e.dataset.id),p_from_stage:rf?rf.stage:null});await refresh();toast('Stage updated')},
  admit:async e=>{if(deny('lead.update'))return;const n=v('an-'+e.dataset.id).trim();if(!n){document.getElementById('an-'+e.dataset.id).focus();return toast('Enter the admission number')}
    const rf=S.refs.find(r=>r.id===e.dataset.id);await DB.rpc('advance_referral',{p_referral:refUid(e.dataset.id),p_admission_no:n,p_from_stage:rf?rf.stage:null});await refresh();toast('Admission confirmed; Finance can now verify the fee')},
  cancel:async e=>{if(!can('lead.update')&&deny('payment.verify'))return;if(!confirm('Record cancellation or refund? Unpaid incentive is reversed and paid amounts become a recovery.'))return;
    const r=await DB.rpc('record_cancellation',{p_referral:refUid(e.dataset.id)});await refresh();toast(r>0?`Cancellation recorded; ${money(r)} recovery opened`:'Cancellation recorded')},
  aconfirm:async e=>{if(deny('attr.review'))return;await DB.rpc('review_attribution',{p_referral:refUid(e.dataset.id),p_decision:'confirm'});await refresh();toast('Attribution confirmed')},
  areject:async e=>{if(deny('attr.review'))return;if(!confirm('Reject this referral claim?'))return;await DB.rpc('review_attribution',{p_referral:refUid(e.dataset.id),p_decision:'reject'});await refresh();toast('Claim rejected')},
  areassign:async e=>{if(deny('attr.review'))return;const r=S.refs.find(x=>x.id===e.dataset.id),to=v('ra-'+r.id);
    await DB.rpc('request_approval',{p_type:'attribution',p_summary:`Reassign ${r.id} to ${person(to).name}`,p_payload:{referral_id:r.uid,to_partner:to}});await refresh();toast('Sent to Management for approval')},
  /* ----- finance ----- */
  vfee:async e=>{if(deny('payment.verify'))return;const rc=v('rc-'+e.dataset.id).trim();if(!rc){document.getElementById('rc-'+e.dataset.id).focus();return toast('Enter the payment reference')}
    await DB.rpc('verify_payment',{p_referral:refUid(e.dataset.id),p_milestone:'admission_fee',p_reference:rc});await refresh();toast('Admission fee verified; the first 50% is calculated')},
  vinst:async e=>{if(deny('payment.verify'))return;const rc=v('rc-'+e.dataset.id).trim();if(!rc){document.getElementById('rc-'+e.dataset.id).focus();return toast('Enter the payment reference')}
    await DB.rpc('verify_payment',{p_referral:refUid(e.dataset.id),p_milestone:'first_instalment',p_reference:rc});await refresh();toast('First instalment verified; the second 50% is eligible')},
  mkbatch:async()=>{if(deny('payout.process'))return;await DB.rpc('prepare_payout_batch');await refresh();toast('Batch sent to Management for approval')},
  transfer:async e=>{if(deny('payout.process'))return;const b=S.batches.find(x=>x.id===e.dataset.id),ref=v('tr-'+b.id).trim(),el=document.getElementById('pf-'+b.id),f=el&&el.files[0];if(!ref)return toast('Enter the bank transfer reference');
    let path=null;if(f)path=await DB.upload('payment-proofs',`${b.id}/${Date.now()}-${safeName(f)}`,f);
    await DB.rpc('record_payout_transfer',{p_batch:b.uid,p_transfer_ref:ref,p_proof_path:path});await refresh();toast('Transfer recorded; partners can see it now')},
  reconcile:async e=>{if(deny('payout.process'))return;await DB.rpc('reconcile_payout_batch',{p_batch:S.batches.find(x=>x.id===e.dataset.id).uid});await refresh()},
  sheet:async e=>{if(deny('payout.process'))return;const b=S.batches.find(x=>x.id===e.dataset.id),rows=await DB.rpc('get_payout_bank_details',{p_batch:b.uid});
    const csv=[['Partner','Account holder','Account number','IFSC','Amount'],...rows.map(r=>[r.partner_name,r.account_holder||'',r.account_number||'MISSING',r.ifsc||'',r.amount])].map(r=>r.map(csvCell).join(',')).join('\n');
    downloadText(`${b.id}-payout-sheet.csv`,csv);toast('Payout sheet downloaded. Keep it secure and delete it after the transfers.')},
  settle:async e=>{if(deny('payout.process'))return;await DB.rpc('settle_adjustment',{p_adjustment:e.dataset.id});await refresh()},
  adjprop:async()=>{if(deny('adjust.propose'))return;const amt=parseInt(v('ad-amt'),10),note=v('ad-note').trim(),pid=v('ad-p');if(!amt||!note)return toast('Enter an amount and a reason');
    await DB.rpc('request_approval',{p_type:'adjustment',p_summary:`Adjustment of ${money(amt)} for ${person(pid).name}`,p_payload:{partner_id:pid,amount:amt,reason:note}});await refresh();toast('Sent to Management for approval')},
  /* ----- management ----- */
  apok:async e=>{if(deny('approve'))return;await DB.rpc('decide_approval',{p_approval:e.dataset.id,p_approve:true});await refresh();toast('Approved')},
  apno:async e=>{if(deny('approve'))return;await DB.rpc('decide_approval',{p_approval:e.dataset.id,p_approve:false});await refresh();toast('Rejected')},
  bapprove:async e=>{if(deny('approve'))return;await DB.rpc('decide_payout_batch',{p_batch:S.batches.find(x=>x.id===e.dataset.id).uid,p_approve:true});await refresh();toast('Batch approved for transfer')},
  breturn:async e=>{if(deny('approve'))return;await DB.rpc('decide_payout_batch',{p_batch:S.batches.find(x=>x.id===e.dataset.id).uid,p_approve:false});await refresh();toast('Batch sent back')},
  /* ----- course catalogue ----- */
  cedit:e=>{S.ui.ced=e.dataset.id;S.ui.pendingImg=null;render(true)},
  cedclose:()=>{S.ui.ced=null;render(true)},
  csave:async e=>{if(deny('courses'))return;const isN=S.ui.ced==='new',name=v('ce-name').trim(),code=isN?v('ce-code').trim():e.dataset.id;
    if(!code||!name)return toast('Add a course code and name');if(isN&&course(code))return toast('That course code already exists');if(isN&&!/^[A-Za-z0-9][A-Za-z0-9 \-]{1,19}$/.test(code))return toast('Use 2 to 20 letters, numbers, spaces or hyphens for the code');
    const cats=[...CATS,'Event organizer'].filter((x,i)=>document.getElementById('ce-cat'+i).checked),broF=document.getElementById('ce-bro').files[0],imgF=document.getElementById('ce-img').files[0],old=isN?null:course(code);
    const row={name,short_description:v('ce-short').trim()||name,description:v('ce-desc').trim(),eligibility:v('ce-elig').trim(),duration:v('ce-dur').trim(),fee:parseInt(v('ce-fee'),10)||0,mode:v('ce-mode').trim(),
      benefits:v('ce-ben').split('\n').map(x=>x.trim()).filter(Boolean),landing_url:v('ce-land').trim(),color:v('ce-col'),referral_eligible:document.getElementById('ce-ref').checked,eligible_categories:cats};
    const folder=slugOf(code);if(imgF)row.image_path=await DB.upload('course-media',`courses/${folder}/cover-${Date.now()}.${fileExt(imgF)}`,imgF);if(broF)row.brochure_path=await DB.upload('course-media',`courses/${folder}/brochure-${Date.now()}.pdf`,broF);
    let id;
    if(isN){const [c]=await DB.insert('courses',{...row,code,status:'Draft',created_by:S.session.id});id=c.id;
      const rates=[0,1,2,3].map(i=>parseInt(v('ce-r'+i),10)||0);
      if(rates.some(x=>x>0))await DB.rpc('request_approval',{p_type:'policy',p_summary:'Incentive rates for new course '+name,p_payload:{rates:{[id]:rates},note:'New course added to the catalogue'}})}
    else{id=old.uid;await DB.update('courses',row,{id});const rn=document.getElementById('ce-rcode');if(rn&&rn.value.trim()&&rn.value.trim()!==old.code)await DB.rpc('rename_course_code',{p_course:id,p_code:rn.value.trim()})}
    const finalCode=(!isN&&document.getElementById('ce-rcode')&&document.getElementById('ce-rcode').value.trim())||code;
    for(const [i,x] of S.camps.filter(x=>x.kind==='programme'&&!['Closed','Rejected'].includes(x.status)).entries()){const el=document.getElementById('ce-cmp'+i);if(!el)continue;const has=x.progs.includes(code);
      if(el.checked&&!has)await DB.insert('campaign_courses',{campaign_id:x.uid,course_id:id});if(!el.checked&&has)await DB.del('campaign_courses',{campaign_id:x.uid,course_id:id})}
    let n=0;if(e.dataset.launch){n=await DB.rpc('set_course_status',{p_course:id,p_status:'Active'})}else if(!isN&&old.status==='Active'){n=await DB.rpc('announce_course',{p_course:id})}
    S.ui.ced=null;await refresh(true);toast(e.dataset.launch?(n?`${name} launched. ${n} eligible partners notified.`:`${name} is active. Partners are notified once it’s in an active campaign.`):n?`${name} is now open for referrals. ${n} eligible partners notified.`:isN?'Course saved as a draft':'Course updated')},
  cstat:async e=>{if(deny('courses'))return;const c=course(e.dataset.id),to=e.dataset.v;if(to==='Archived'&&!confirm(`Archive ${c.name}? It disappears from partner pages and new referral forms. Existing leads and incentives stay.`))return;
    const n=await DB.rpc('set_course_status',{p_course:c.uid,p_status:to});await refresh();toast(n?`${c.name} launched. ${n} eligible partners notified.`:`${c.name}: ${to.toLowerCase()}`)},
  /* ----- resource centre ----- */
  radd:async()=>{if(deny('materials'))return;const type=v('ru-type'),title=v('ru-title').trim(),f=document.getElementById('ru-file').files[0],text=v('ru-text').trim(),isTxt=['WhatsApp message','Social caption'].includes(type);
    if(!title)return toast('Add a title');if(isTxt&&!text)return toast('Add the message or caption text');if(!isTxt&&!f)return toast('Choose a file to upload');
    let path=null,thumb=null;if(!isTxt){path=await DB.upload('resources',`${slugOf(type)}/${Date.now()}-${safeName(f)}`,f);if(/^image\//.test(f.type))thumb=path}
    const cc=course(v('ru-course')),cm=camp(v('ru-camp'));
    const [r]=await DB.insert('resources',{type,title,course_id:cc?cc.uid:null,campaign_id:cm?cm.uid:null,language:v('ru-lang'),file_path:path,thumb_path:thumb,body_text:isTxt?text:null,status:'Draft',created_by:S.session.id});
    const n=await DB.rpc('publish_resource',{p_resource:r.id,p_notify:document.getElementById('ru-notify').checked});await refresh();toast(n?`Published. ${n} partners notified.`:'Published')},
  rtoggle:async e=>{if(deny('materials'))return;const r=S.resources.find(x=>x.id===e.dataset.id);await DB.update('resources',{status:r.status==='Published'?'Unpublished':'Published'},{id:r.id});await refresh()},
  rdel:async e=>{if(deny('materials'))return;const r=S.resources.find(x=>x.id===e.dataset.id);if(!confirm(`Delete “${r.title}”? Usage history for it is removed too.`))return;await DB.del('resources',{id:r.id});if(r.filePath)DB.remove('resources',[r.filePath]);await refresh()},
  nadd:async()=>{if(deny('materials'))return;const t=v('an-title').trim(),b=v('an-body').trim();if(!t||!b)return toast('Add a title and message');const n=await DB.rpc('post_announcement',{p_title:t,p_body:b});await refresh();toast(`Announcement sent to ${n} partners`)},
  ndel:async e=>{if(deny('materials'))return;await DB.rpc('delete_notification',{p_id:e.dataset.id});await refresh()},
  csv:e=>{const rows=CSV[e.dataset.k]();return copyText(rows.map(r=>r.join('\t')).join('\n')).then(()=>toast(`Copied ${rows.length-1} rows. Paste into Excel.`))},
  /* ----- roles, settings, integrations ----- */
  atoggle:async e=>{if(deny('admins'))return;const a=S.admins.find(x=>x.id===e.dataset.id);await DB.update('admin_users',{status:a.status==='Active'?'Deactivated':'Active'},{user_id:a.id});await refresh()},
  addadmin:async()=>{if(deny('admins'))return;await DB.invoke('admin-partners',{action:'invite_admin',full_name:v('na-name').trim(),email:v('na-email').trim(),role:v('na-role')});await refresh();toast('Invitation sent. They set their own password from the email.')},
  lsqtest:async()=>{if(deny('settings'))return;const r=await DB.invoke('lsq-admin',{action:'test'});await loadLsqStatus();await refresh();toast(r.message)},
  savesettings:async()=>{if(deny('settings'))return;const days=parseInt(v('st-days'),10);if(!(days>0))return toast('Enter a valid attribution window');
    const counsellors=v('st-couns').split('\n').map(x=>x.trim()).filter(Boolean),now=new Date().toISOString();
    await DB.upsert('app_settings',[{key:'require_phone_otp',value:document.getElementById('st-otp').checked,updated_at:now},{key:'email_confirmation_required',value:document.getElementById('st-emailconf').checked,updated_at:now},{key:'attribution_window_days',value:days,updated_at:now},{key:'public_show_rates',value:document.getElementById('st-rates').checked,updated_at:now},{key:'counsellors',value:counsellors,updated_at:now}],'key');await refresh();toast('Settings saved')},
  savemap:async()=>{if(deny('settings'))return;const map={};
    for(const [k,l,d,ex,req,defOn,kind] of LSQ_FIELDS){const f=v('lm-'+k).trim();if(!/^[A-Za-z][A-Za-z0-9_]{0,60}$/.test(f))return toast(`“${l}”: use the LeadSquared schema name, letters, numbers and underscores only`);
      const e={field:f,on:!!req||document.getElementById('lc-'+k).checked};if(kind==='fixed')e.value=v('lv-'+k).trim();if(kind==='source'){e.value=v('lv-'+k).trim();e.web=v('lw-'+k).trim()}
      if(kind==='fixed'&&e.on&&!e.value)return toast(`“${l}” is switched on but has no value`);map[k]=e}
    const used=Object.entries(map).filter(([k,e])=>e.on).map(([k,e])=>e.field.toLowerCase()),dup=used.find((f,i)=>used.indexOf(f)!==i);if(dup)return toast(`Two fields go to “${dup}”. Each LeadSquared field can be used once.`);
    await DB.upsert('app_settings',{key:'lsq_field_map',value:map,updated_at:new Date().toISOString()},'key');await refresh();toast('Field mapping saved. It applies to the next lead.')},
  resetmap:async()=>{if(deny('settings'))return;if(!confirm('Reset every field to the default names?'))return;await DB.upsert('app_settings',{key:'lsq_field_map',value:{},updated_at:new Date().toISOString()},'key');await refresh();toast('Field mapping reset')},
  retry:async e=>{const r=await DB.invoke('lsq-admin',{action:'sync',referral_id:e.dataset.id});await refresh();toast(r.failed?r.message:'Synced to LeadSquared')},
  retryall:async()=>{const r=await DB.invoke('lsq-admin',{action:'sync'});await refresh();toast(r.failed?`${r.synced} sent, ${r.failed} still waiting. ${r.message}`:`${r.synced} leads sent to LeadSquared`)}
};
/* ----- events ----- */
document.addEventListener('click',e=>{const a=e.target.closest('a[data-track]');if(a&&meId())track(meId(),a.dataset.track,'share');
  const t=e.target.closest('[data-act]');if(!t||t.tagName==='A'||t.disabled)return;const fn=A[t.dataset.act];if(!fn)return;
  const lock=t.dataset.lock!=='no';if(lock)t.disabled=true;
  Promise.resolve().then(()=>fn(t)).catch(err=>{toast((err&&err.message)||'Something went wrong. Please try again.');if(S.session)render()}).finally(()=>{if(lock&&document.body.contains(t))t.disabled=false})});
document.addEventListener('input',capture);
document.addEventListener('change',e=>{capture(e);const k=e.target.dataset.change;if(!k)return;
  if(k==='jcat'){J.d.cat=e.target.value;J.err='';render()}
  else if(k==='assign'){if(deny('lead.update'))return render();const r=S.refs.find(x=>x.id===e.target.dataset.id);DB.rpc('assign_counsellor',{p_referral:r.uid,p_counsellor:e.target.value}).then(()=>refresh()).then(()=>toast('Counsellor updated')).catch(er=>{toast(er.message);render()})}
  else if(k==='arole'){if(deny('admins'))return render();const a=S.admins.find(x=>x.id===e.target.dataset.id);DB.update('admin_users',{role:e.target.value},{user_id:a.id}).then(()=>refresh()).then(()=>toast('Role updated')).catch(er=>{toast(er.message);render()})}
  else if(k==='ceimg'){const f=e.target.files&&e.target.files[0];const pv=document.getElementById('ce-prev');if(f&&pv)pv.style.backgroundImage=`url(${URL.createObjectURL(f)})`}
  else if(k==='ruimg'){}
  else{S.ui[k]=e.target.value;render()}});
document.addEventListener('keydown',e=>{if(e.key==='Enter'&&e.target.tagName==='INPUT'&&!['checkbox','radio','file'].includes(e.target.type)){if(e.target.dataset.change){e.target.blur();return}const box=e.target.closest('.card,.authbox,.narrow');const b=box&&box.querySelector('.btn.primary[data-act]');if(b&&!b.disabled){e.preventDefault();b.click()}}
  if(e.key==='Escape'&&S.ui.sb){S.ui.sb=false;render()}});
window.addEventListener('popstate',()=>{if(S.session)return;const r=viewFromUrl();if(r.view==='register')openRefPage(r.code,r.course,r.res);else{S.view=r.view;render()}});

/* ----- start ----- */
async function appInit(){
  if(!sb&&!window.__NO_AUTO_INIT){$('root').innerHTML=`<div class="pub"><div class="card" style="max-width:520px;margin:60px auto"><h1 style="font-size:24px">This copy isn’t connected</h1><p class="muted">The app can’t reach AIMER’s servers. Open it from the hosted address (for example https://aimer-portal.netlify.app) rather than from a file or preview, and make sure <code>config.js</code> sits next to <code>index.html</code> in the hosted folder.</p></div></div>`;return}
  const hashType=new URLSearchParams((location.hash||'').replace(/^#/,'')).get('type');
  S.booting=true;render();
  const r=viewFromUrl();await loadCatalog();
  if(S.connErr&&/api key|jwt|apikey|fetch|network|failed to/i.test(S.connErr)){$('root').innerHTML=`<div class="pub"><div class="card" style="max-width:540px;margin:60px auto"><h1 style="font-size:24px">We can’t reach AIMER’s servers</h1><p class="muted">${/api key|jwt|apikey/i.test(S.connErr)?'The app’s connection key is wrong or has been changed. Please tell the AIMER team: check the key in <code>config.js</code>.':'Check your internet connection and try again.'}</p><p class="small muted">Detail: ${esc(S.connErr)}</p><button class="btn primary" onclick="location.reload()">Try again</button></div></div>`;return}
  if(sb){DB.auth.onChange((ev)=>{if(ev==='PASSWORD_RECOVERY'&&!S.ui.pwKind){S.ui.pwKind='recovery'}if(ev==='SIGNED_OUT'&&S.session){S.session=null;S.view='landing';render(true)}})}
  try{if(await DB.auth.hasSession()){await boot()}}catch(e){S.ui.lerr=e.message}
  S.booting=false;
  if(S.session){if(hashType==='invite'||hashType==='recovery'){S.ui.pwKind=hashType;S.view='setpw'}else if(r.view==='home'||r.view==='landing'||r.view==='login'||r.view==='join'||r.view==='adminlogin')routeAfterLogin();else if(r.view!=='register')routeAfterLogin();else S.view='register'}
  else if(hashType==='invite'||hashType==='recovery'){S.ui.pwKind=hashType;S.view='setpw'}
  else S.view=r.view;
  if(!S.session&&S.view==='register'){await openRefPage(r.code,r.course,r.res);return}
  if(S.session&&r.view==='register'){await openRefPage(r.code,r.course,r.res);return}
  if(r.view==='login'&&!S.session&&/type=signup/.test(location.hash||''))S.ui.notice='Email confirmed. Log in to choose your partner category.';
  render(true);
}
