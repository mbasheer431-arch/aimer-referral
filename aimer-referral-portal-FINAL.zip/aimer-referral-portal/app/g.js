/* ---------- course & resource shared pieces ---------- */
const RTYPES=['Creative','Poster','Video','Brochure','Testimonial','WhatsApp message','Social caption'];
const RICON={Creative:'image',Poster:'image',Video:'play',Brochure:'book',Testimonial:'star','WhatsApp message':'chat','Social caption':'globe'};
const LANGS=['English','Malayalam','Arabic','Hindi'];
const coverStyle=c=>`--cc:${c.color};background-image:url(${c.image||IMG.campus})`;
const topRate=code=>Math.max(...(S.pol.rates[code]||[0]));
const resColor=r=>r.course!=='All'&&course(r.course)?course(r.course).color:'#008BA5';
const resLink=(p,r)=>linkFor(p,{course:r.course!=='All'?r.course:null,c:r.camp&&r.camp!=='REF-26'?r.camp:null,res:r.id});
const resText=(p,r)=>r.text?r.text+'\n'+resLink(p,r):`Have a look: ${r.title}, from AIMER Business School.\n${resLink(p,r)}`;
const resFor=p=>S.resources.filter(r=>r.status==='Published'&&(r.course==='All'||eligibleFor(p,r.course))&&(!r.camp||(camp(r.camp)&&(camp(r.camp).kind!=='event'||p.event===r.camp||!p.event))));
const myNotifs=()=>{const m=meId();return S.notifs.filter(n=>n.aud.includes(m))};
const unread=kind=>myNotifs().filter(n=>!n.read.includes(meId())&&(!kind||n.kind===kind)).length;
function rthumb(r,big){const st=`--cc:${resColor(r)}${r.thumb?`;background-image:url(${r.thumb})`:''}`;
  return `<div class="rthumb ${r.thumb?'img':''}" style="${st}${big?';height:240px':''}">${isNew(r.date)?'<span class="newb">New</span>':''}${r.thumb?'':r.text?`<div class="rtext">${esc(r.text.slice(0,big?400:130))}${r.text.length>(big?400:130)?'…':''}</div>`:icon(RICON[r.type])}</div>`}
function partnerTop(){const n=unread();return `<div class="ptop"><button class="bellbtn" data-act="notifs" aria-label="Notifications${n?', '+n+' unread':''}">${icon('bell')}Notifications${n?` <span class="count">${n}</span>`:''}</button></div>`}
function courseCard(c,me){const el=me?eligibleFor(me,c.code):true,top=topRate(c.code),low=(S.pol.rates[c.code]||[0])[0];
  return `<div class="ccard"><div class="cover" style="${coverStyle(c)}">${isNew(c.launchedOn)?'<span class="newb">New</span>':''}<b>${esc(c.name)}</b></div><div class="cb"><h3>${esc(c.short)}</h3>
  <div class="meta"><span>${esc(c.duration)}</span><span>${c.fee?money(c.fee):'Fee varies'}</span><span>${esc(c.mode)}</span></div>
  ${me?(el?`<span class="earn">Earn ${low===top?money(top):money(low)+' to '+money(top)} per admission</span>`:'<span class="small muted">Not open for referrals in your category</span>'):''}
  <div class="row end"><button class="btn sm primary" data-act="cview" data-id="${esc(c.code)}">View course</button>${me&&el?`<button class="iconbtn" data-act="copy" data-text="${esc(linkFor(me,{course:c.code}))}" title="Copy course link" aria-label="Copy course link">${icon('copy')}</button>`:''}</div></div></div>`}
function resCard(r,me){const link=resLink(me,r);
  return `<div class="rcard">${rthumb(r)}<div class="rb"><h3>${esc(r.title)}</h3><div class="tags">${chip([r.type,''])}${r.course!=='All'?chip([r.course,'grey']):''}${r.lang!=='English'?chip([r.lang,'grey']):''}</div>
  <div class="row end"><button class="btn sm" data-act="rprev" data-id="${r.id}">${icon('eye')}Preview</button>
  ${r.file?`<button class="iconbtn" data-act="rdown" data-id="${r.id}" title="Download" aria-label="Download ${esc(r.title)}">${icon('download')}</button>`:`<button class="iconbtn" data-act="rcopy" data-id="${r.id}" title="Copy text with my link" aria-label="Copy text">${icon('copy')}</button>`}
  <a class="iconbtn" href="https://wa.me/?text=${encodeURIComponent(resText(me,r))}" target="_blank" rel="noopener" data-track="${r.id}" title="Share on WhatsApp" aria-label="Share on WhatsApp">${icon('chat')}</a>
  <button class="iconbtn" data-act="rqr" data-id="${r.id}" title="QR code for this material" aria-label="QR code">${icon('qr')}</button></div></div></div>`}

/* ---------- partner: Explore Courses ---------- */
function vCoursesP(){
  const me=person(meId()),list=S.courses.filter(c=>c.status==='Active');
  if(S.ui.cv){const c=course(S.ui.cv);if(c&&c.status==='Active')return courseDetail(c,me)}
  const f=S.ui.cf||'all',shown=list.filter(c=>f==='all'||(f==='new'&&isNew(c.launchedOn))||(f==='open'&&eligibleFor(me,c.code)));
  return pagehead('Explore Courses','Browse AIMER programmes, download brochures and share a course-specific link. Students who register through a course link land on that course with your referral attached.')+
  filters('cf',[['all','All courses',list.length],['open','Open to you',list.filter(c=>eligibleFor(me,c.code)).length],['new','New',list.filter(c=>isNew(c.launchedOn)).length]])+
  `<div class="cgrid">${shown.map(c=>courseCard(c,me)).join('')||'<div class="card empty">No courses in this view.</div>'}</div>`;
}
function courseDetail(c,me){
  const el=eligibleFor(me,c.code),link=linkFor(me,{course:c.code}),msg=`Hi! AIMER Business School’s ${c.name} could be a great fit for you. ${c.short}, ${c.duration}. Register here and the admissions team will guide you:\n${link}`;
  const rel=resFor(me).filter(r=>r.course===c.code).slice(0,4);
  return `<div class="row" style="margin-bottom:14px"><button class="btn sm" data-act="cback">← All courses</button></div>
  <div class="cover big" style="${coverStyle(c)}">${isNew(c.launchedOn)?'<span class="newb">New</span>':''}<b>${esc(c.name)}</b></div>
  <div class="grid g-7-5 mt"><div class="card"><h2>${esc(c.short)}</h2><p class="muted">${esc(c.desc)}</p>
  <div class="kv"><span>Eligibility</span><b>${esc(c.eligibility)}</b><span>Duration</span><b>${esc(c.duration)}</b><span>Fees</span><b>${c.fee?money(c.fee)+' (total programme fee)':'Varies'}</b><span>Mode</span><b>${esc(c.mode)}</b></div>
  <h3 style="font-size:16px;margin-top:16px">Benefits</h3><ul style="margin:8px 0 0;padding-left:20px">${c.benefits.map(b=>`<li>${esc(b)}</li>`).join('')}</ul>
  <div class="row mt">${c.brochure?`<button class="btn" data-act="cbro" data-id="${esc(c.code)}">${icon('download')}Brochure</button>`:''}${c.landing?`<a class="btn" href="${esc(c.landing)}" target="_blank" rel="noopener">${icon('globe')}Course page</a>`:''}</div></div>
  <div>${el?`<div class="card"><h2>${icon('link')}Your course link</h2><div class="linkfield mt">${icon('link')}<span>${esc(link)}</span></div>
  <div class="row mt"><button class="btn primary" data-act="copy" data-text="${esc(link)}">${icon('copy')}Copy link</button><a class="btn" href="https://wa.me/?text=${encodeURIComponent(msg)}" target="_blank" rel="noopener">${icon('chat')}WhatsApp</a><button class="btn" data-act="cqr" data-id="${esc(c.code)}">${icon('qr')}QR</button></div>
  <div class="msg">${esc(msg)}</div></div><div class="mt">${slabCard(me.id,c.code)}</div>`
  :`<div class="card"><h2>Not open for referrals</h2><p class="muted">${c.refEligible?'Referral incentives for this course aren’t available to your partner category.':'This course isn’t part of the referral programme right now.'} You can still share the course page.</p></div>`}</div></div>
  ${rel.length?`<div class="card mt"><div class="card-head"><h2>${icon('image')}Materials for ${esc(c.name)}</h2></div><div class="rgrid">${rel.map(r=>resCard(r,me)).join('')}</div></div>`:''}`;
}

/* ---------- partner: Resource Centre ---------- */
function vResourcesP(){
  const me=person(meId()),tab=S.ui.rtab||'library';
  const head=pagehead('Marketing Resource Centre','Approved creatives, videos, brochures, testimonials, WhatsApp messages and captions. Every share uses your own tracked link, so registrations are credited to you.')+
    `<div class="tabs" role="tablist"><button class="${tab==='library'?'on':''}" data-act="filter" data-key="rtab" data-k="library">Library</button><button class="${tab==='messages'?'on':''}" data-act="filter" data-key="rtab" data-k="messages">Messages and captions</button><button class="${tab==='gen'?'on':''}" data-act="filter" data-key="rtab" data-k="gen">Message generator</button></div>`;
  if(tab==='gen'){const msg=genMessage(me),sel=(k,list,d)=>`<select data-change="${k}">${opt(list,S.ui[k]||d)}</select>`;
    return head+`<div class="grid g-7-5"><div class="card"><h2>${icon('chat')}Message generator</h2><div class="formrow"><label class="field">Programme${sel('gprog',['All programmes',...openCourses().map(c=>c.code)],'All programmes')}</label><label class="field">Sending to${sel('gaud',['Parent','Student','Friend'],'Parent')}</label></div>
    <div class="formrow"><label class="field">Channel${sel('gch',['WhatsApp','Instagram caption','Email'],'WhatsApp')}</label><label class="field">Tone${sel('gtone',['Friendly','Formal'],'Friendly')}</label></div><div class="msg">${esc(msg)}</div>
    <div class="row"><button class="btn primary" data-act="copy" data-text="${esc(msg)}">${icon('copy')}Copy message</button><a class="btn" href="https://wa.me/?text=${encodeURIComponent(msg)}" target="_blank" rel="noopener">${icon('chat')}Open WhatsApp</a></div></div>
    <div class="card"><h2>${icon('qr')}Your QR code</h2><p class="small muted">Print it on posters or show it at events.</p><div class="qrbig" id="qr" data-url="${esc(linkFor(me))}" role="img" aria-label="QR code for your referral link" style="margin:12px 0"></div><p class="small" style="word-break:break-all;margin:0">${esc(linkFor(me))}</p></div></div>`}
  const all=resFor(me).filter(r=>tab==='messages'?!!r.text:!r.text);
  const fs=[['rft','Type',['All types',...RTYPES.filter(t=>all.some(r=>r.type===t))]],['rfc','Programme',['All programmes',...new Set(all.map(r=>r.course).filter(x=>x!=='All'))]],['rfl','Language',['All languages',...new Set(all.map(r=>r.lang))]],['rfm','Campaign',['All campaigns',...new Set(all.map(r=>(camp(r.camp)||{}).name).filter(Boolean))]]];
  const val=k=>{const o=fs.find(x=>x[0]===k)[2];return o.includes(S.ui[k])&&S.ui[k]!==o[0]?S.ui[k]:null};const [ft,fc,fl,fm]=['rft','rfc','rfl','rfm'].map(val);
  const list=all.filter(r=>(!ft||r.type===ft)&&(!fc||r.course===fc)&&(!fl||r.lang===fl)&&(!fm||(camp(r.camp)||{}).name===fm)).sort((a,b)=>b.date.localeCompare(a.date));
  return head+`<div class="selrow">${fs.map(([k,l,o])=>`<select data-change="${k}" aria-label="${l}">${opt(o,val(k)||o[0])}</select>`).join('')}</div>
  ${list.length?`<div class="rgrid">${list.map(r=>resCard(r,me)).join('')}</div>`:'<div class="card empty">No materials match these filters.</div>'}`;
}

/* ---------- admin: Course Catalogue ---------- */
function vCoursesA(){
  const ed=can('courses');
  if(S.ui.ced&&ed)return courseEditor(S.ui.ced==='new'?null:course(S.ui.ced));
  const f=S.ui.caf||'Active',n=k=>S.courses.filter(c=>k==='All'||c.status===k).length;
  const rows=S.courses.filter(c=>f==='All'||c.status===f).map(c=>{const rs=S.refs.filter(r=>r.prog===c.code&&live(r)),cps=S.camps.filter(x=>x.progs.includes(c.code)&&!['Closed','Rejected'].includes(x.status));
    return `<tr><td><div class="row" style="flex-wrap:nowrap"><span class="thumbsm" style="${coverStyle(c)}"></span><span><strong>${esc(c.name)}</strong><span class="sub">${esc(c.code)}, ${esc(c.duration)}, ${c.fee?money(c.fee):'fee varies'}</span></span></div></td>
    <td>${c.refEligible?chip(['Referral eligible','ok']):chip(['Not in referrals','grey'])}<span class="sub">${c.cats.length===CATS.length+1?'All categories':c.cats.join(', ')}</span></td><td>${cps.map(x=>esc(x.name)).join('<br>')||'<span class="muted">None</span>'}</td>
    <td class="num">${rs.length}<span class="sub">${rs.filter(admitted).length} admitted</span></td><td class="num">${c.downloads}</td><td>${chip([c.status,{Active:'ok',Draft:'grey',Inactive:'warn',Archived:'bad'}[c.status]])}${S.pol.approved.includes(c.code)?'':'<span class="sub">Rates awaiting approval</span>'}</td>
    <td>${ed?`<div class="row">${c.status!=='Archived'?`<button class="btn sm" data-act="cedit" data-id="${esc(c.code)}">${icon('edit')}Edit</button>`:''}${c.status==='Active'?`<button class="btn sm" data-act="cstat" data-id="${esc(c.code)}" data-v="Inactive">Deactivate</button>`:c.status!=='Archived'?`<button class="btn sm primary" data-act="cstat" data-id="${esc(c.code)}" data-v="Active">${c.launchedOn?'Activate':'Launch'}</button>`:''}${c.status!=='Archived'?`<button class="btn sm danger" data-act="cstat" data-id="${esc(c.code)}" data-v="Archived">Archive</button>`:`<button class="btn sm" data-act="cstat" data-id="${esc(c.code)}" data-v="Inactive">Restore</button>`}</div>`:''}</td></tr>`}).join('');
  const sent=S.notifs.filter(x=>x.kind==='course');
  return pagehead('Course Catalogue','Add, edit, activate, deactivate and archive courses without developer support. Active courses appear in partners’ Explore Courses, the referral forms and LeadSquared’s programme list.',ed?`<button class="btn primary" data-act="cedit" data-id="new">${icon('book')}Add course</button>`:'')+
  `<div class="notice">Course details here are sample data. Replace descriptions, fees, durations and eligibility with AIMER’s official information before launch.</div>`+
  filters('caf',[['Active','Active',n('Active')],['Draft','Draft',n('Draft')],['Inactive','Inactive',n('Inactive')],['Archived','Archived',n('Archived')],['All','All',n('All')]])+
  `<div class="tbl"><table><thead><tr><th>Course</th><th>Referral eligibility</th><th>Campaigns</th><th class="num">Leads</th><th class="num">Brochure downloads</th><th>Status</th><th></th></tr></thead><tbody>${rows||'<tr><td colspan="7" class="empty">No courses here.</td></tr>'}</tbody></table></div>
  <div class="card mt"><h2>${icon('bell')}Launch notifications sent</h2>${sent.length?`<ul class="list mt">${sent.map(x=>`<li><span><strong>${esc(x.title)}</strong><span class="small muted" style="display:block">${fmtTime(x.date)}</span></span><span class="small muted">${x.aud.length} partners notified, ${x.read.length} opened</span></li>`).join('')}</ul>`:'<p class="empty">None yet.</p>'}</div>`;
}
function courseEditor(c){
  const isNewC=!c,d=c||{code:'',name:'',short:'',desc:'',duration:'',eligibility:'',fee:0,mode:'',benefits:[],brochure:null,landing:'',color:'#008BA5',refEligible:true,cats:[...CATS,'Event organizer'],image:null};
  const pc=S.camps.filter(x=>x.kind==='programme'&&!['Closed','Rejected'].includes(x.status)),rates=S.pol.rates[d.code]||[0,0,0,0];
  return pagehead(isNewC?'Add a course':'Edit '+esc(d.name),isNewC?'New courses start as drafts. Launching a course notifies every eligible partner.':`Code ${esc(d.code)}. The code is the programme value sent to LeadSquared${role()==='superadmin'?'; as Super Admin you can change it':', so only a Super Admin can change it'}.`,`<button class="btn" data-act="cedclose">Cancel</button>`)+
  `<div class="grid g-7-5"><div class="card"><h2>Course details</h2>
  <div class="formrow">${isNewC?'<label class="field">Course code<input id="ce-code" placeholder="For example DMAI" autocomplete="off"></label>':role()==='superadmin'?`<label class="field">Course code<input id="ce-rcode" value="${esc(d.code)}" autocomplete="off"></label>`:''}<label class="field" style="flex:2">Course name<input id="ce-name" value="${esc(d.name)}" autocomplete="off"></label></div>
  <label class="field mt">Short description<input id="ce-short" value="${esc(d.short)}" autocomplete="off"></label><label class="field mt">Full description<textarea id="ce-desc">${esc(d.desc)}</textarea></label>
  <div class="formrow"><label class="field">Eligibility<input id="ce-elig" value="${esc(d.eligibility)}" autocomplete="off"></label><label class="field">Duration<input id="ce-dur" value="${esc(d.duration)}" autocomplete="off"></label></div>
  <div class="formrow"><label class="field">Programme fee (₹)<input id="ce-fee" type="number" min="0" value="${d.fee}"></label><label class="field">Mode<input id="ce-mode" value="${esc(d.mode)}" placeholder="Residential, online, hybrid" autocomplete="off"></label></div>
  <label class="field mt">Benefits (one per line)<textarea id="ce-ben">${esc(d.benefits.join('\n'))}</textarea></label>
  <div class="formrow"><label class="field" style="flex:2">Landing page link<input id="ce-land" value="${esc(d.landing)}" placeholder="https://" autocomplete="off"></label><label class="field">Brochure (PDF)<input type="file" id="ce-bro" accept=".pdf"></label></div>${d.brochure?`<p class="small muted">Current brochure: ${esc(d.brochure)}</p>`:''}</div>
  <div><div class="card"><h2>Cover image</h2><div class="cover mt" id="ce-prev" style="${coverStyle(d)};border-radius:14px"><b>${esc(d.name||'Course name')}</b></div>
  <div class="formrow"><label class="field">Upload image<input type="file" id="ce-img" accept="image/*" data-change="ceimg"></label><label class="field" style="max-width:110px">Colour<input type="color" id="ce-col" value="${d.color}"></label></div>
  <p class="small muted" style="margin:8px 0 0">Without an image, the campus photo is used with the course colour.</p></div>
  <div class="card mt"><h2>Referral eligibility</h2><label class="check"><input type="checkbox" id="ce-ref" ${d.refEligible?'checked':''}><span>Part of the referral programme</span></label>
  <p class="small muted" style="margin:12px 0 4px">Partner categories that earn incentives for this course</p><div class="row" style="gap:14px">${[...CATS,'Event organizer'].map((x,i)=>`<label class="row" style="gap:6px"><input type="checkbox" id="ce-cat${i}" ${d.cats.includes(x)?'checked':''}>${x}</label>`).join('')}</div>
  <p class="small muted" style="margin:14px 0 4px">Campaigns</p><div class="row" style="gap:14px">${pc.map((x,i)=>`<label class="row" style="gap:6px"><input type="checkbox" id="ce-cmp${i}" data-id="${x.id}" ${x.progs.includes(d.code)||(isNewC&&x.id==='REF-26')?'checked':''}>${esc(x.name)}</label>`).join('')}</div></div>
  <div class="card mt"><h2>Incentive per admission</h2>${isNewC?`<div class="formrow">${SLAB_LBL.map((l,i)=>`<label class="field" style="min-width:90px">${l} (₹)<input id="ce-r${i}" type="number" min="0" step="500" value="${rates[i]}"></label>`).join('')}</div><p class="small muted" style="margin:8px 0 0">Rates for a new course are sent to Management for approval.</p>`
  :`<table class="mini"><tr>${SLAB_LBL.map(l=>`<th>${l}</th>`).join('')}</tr><tr>${rates.map(v=>`<td>${money(v)}</td>`).join('')}</tr></table><p class="small muted" style="margin:8px 0 0">${S.pol.approved.includes(d.code)?'Approved.':'Awaiting Management approval.'} Propose changes under Campaign Management.</p>`}</div></div></div>
  <div class="row mt"><button class="btn primary" data-act="csave" data-id="${esc(d.code)}">${isNewC?'Save as draft':'Save changes'}</button>${isNewC?'<button class="btn" data-act="csave" data-launch="1">Save and launch</button>':''}<button class="btn" data-act="cedclose">Cancel</button></div>`;
}

/* ---------- admin: Resource Centre ---------- */
function vResourcesA(){
  const ed=can('materials'),f=S.ui.raf||'All types';
  const list=S.resources.filter(r=>f==='All types'||r.type===f).filter(r=>(!S.ui.rac||S.ui.rac==='All programmes'||r.course===S.ui.rac)&&(!S.ui.ral||S.ui.ral==='All languages'||r.lang===S.ui.ral));
  const leads=id=>S.refs.filter(x=>x.via&&x.via.res===id&&live(x));
  const tot=k=>S.resources.reduce((s,r)=>s+(r.stats[k]||0),0);
  const users=id=>new Set(S.usage.filter(u=>u.res===id).map(u=>u.pid)).size;
  return pagehead('Marketing Resource Centre','Upload and organise creatives by programme, campaign and language. Partners preview, download and share them with their own tracked links, and every action is counted here.')+
  `<div class="grid g4">${kpi('k1','image',S.resources.filter(r=>r.status==='Published').length,'Published materials')}${kpi('k2','download',num(tot('download')),'Downloads')}${kpi('k3','share',num(tot('share')+tot('copy')),'Shares and copies')}${kpi('k4','userplus',S.refs.filter(x=>x.via&&x.via.res&&live(x)).length,'Leads from materials')}</div>
  ${ed?`<div class="card mt"><h2>${icon('download')}Upload material</h2>
  <div class="formrow"><label class="field">Type<select id="ru-type">${opt(RTYPES,'Poster')}</select></label><label class="field" style="flex:2">Title<input id="ru-title" autocomplete="off"></label></div>
  <div class="formrow"><label class="field">Programme<select id="ru-course"><option>All</option>${S.courses.filter(c=>c.status!=='Archived').map(c=>`<option value="${esc(c.code)}">${esc(c.name)}</option>`).join('')}</select></label><label class="field">Campaign<select id="ru-camp">${S.camps.filter(c=>!['Closed','Rejected'].includes(c.status)).map(c=>`<option value="${c.id}">${esc(c.name)}</option>`).join('')}</select></label><label class="field">Language<select id="ru-lang">${opt(LANGS,'English')}</select></label></div>
  <div class="formrow"><label class="field">File (image, video or PDF)<input type="file" id="ru-file" data-change="ruimg"></label><label class="field" style="flex:2">Message or caption text (WhatsApp messages and captions; the partner’s link is added automatically)<input id="ru-text" autocomplete="off"></label></div>
  <label class="check"><input type="checkbox" id="ru-notify" checked><span>Notify eligible partners when published</span></label><button class="btn primary mt" data-act="radd">Publish material</button></div>`:''}
  <div class="card mt"><div class="card-head"><h2>Library and usage</h2>${csvBtn('resources')}</div>
  <div class="selrow"><select data-change="raf" aria-label="Type">${opt(['All types',...RTYPES],f)}</select><select data-change="rac" aria-label="Programme">${opt(['All programmes',...new Set(S.resources.map(r=>r.course))],S.ui.rac||'All programmes')}</select><select data-change="ral" aria-label="Language">${opt(['All languages',...LANGS],S.ui.ral||'All languages')}</select></div>
  <div class="tbl"><table><thead><tr><th>Material</th><th>Programme and campaign</th><th>Language</th><th class="num">Previews</th><th class="num">Downloads</th><th class="num">Shares</th><th class="num">Partners</th><th class="num">Leads</th><th>Status</th>${ed?'<th></th>':''}</tr></thead><tbody>
  ${list.map(r=>`<tr><td><div class="row" style="flex-wrap:nowrap"><span class="thumbsm" style="--cc:${resColor(r)}${r.thumb?`;background-image:url(${r.thumb})`:''}"></span><span><strong>${esc(r.title)}</strong><span class="sub">${r.type}, ${fmtDate(r.date)}</span></span></div></td><td>${esc(r.course)}<span class="sub">${esc((camp(r.camp)||{}).name||'')}</span></td><td>${r.lang}</td>
  <td class="num">${r.stats.preview||0}</td><td class="num">${r.file?(r.stats.download||0):'–'}</td><td class="num">${(r.stats.share||0)+(r.stats.copy||0)}</td><td class="num">${users(r.id)}</td><td class="num">${leads(r.id).length}</td><td>${chip([r.status,r.status==='Published'?'ok':'grey'])}</td>
  ${ed?`<td><div class="row"><button class="btn sm" data-act="rtoggle" data-id="${r.id}">${r.status==='Published'?'Unpublish':'Publish'}</button><button class="btn sm danger" data-act="rdel" data-id="${r.id}">Delete</button></div></td>`:''}</tr>`).join('')}</tbody></table></div></div>
  <div class="grid g2 mt"><div class="card"><h2>${icon('pulse')}Recent partner activity</h2><ul class="list mt">${S.usage.slice(0,8).map(u=>{const r=S.resources.find(x=>x.id===u.res),p=person(u.pid);return r&&p?`<li><span><strong>${esc(p.name)}</strong> ${{preview:'previewed',download:'downloaded',share:'shared',copy:'copied',qr:'opened the QR for'}[u.action]} “${esc(r.title)}”</span><span class="small muted">${fmtTime(u.t)}</span></li>`:''}).join('')}</ul></div>
  <div class="card"><h2>${icon('bell')}Partner announcements</h2><ul class="list mt">${S.announcements.map(n=>`<li><span><strong>${esc(n.title)}</strong><span class="small muted" style="display:block">${esc(n.body)}</span></span>${ed?`<button class="btn sm danger" data-act="ndel" data-id="${n.id}">Remove</button>`:''}</li>`).join('')}</ul>
  ${ed?`<div class="formrow"><label class="field">Title<input id="an-title" autocomplete="off"></label><label class="field" style="flex:2">Message<input id="an-body" autocomplete="off"></label><button class="btn primary" data-act="nadd">Post</button></div>`:''}</div></div>`;
}

CSV.courses=()=>[['Course','Code','Status','Referral eligible','Leads','Admissions','Brochure downloads','Course views'],...S.courses.map(c=>{const rs=S.refs.filter(r=>r.prog===c.code&&live(r));return [c.name,c.code,c.status,c.refEligible?'Yes':'No',rs.length,rs.filter(admitted).length,c.downloads,c.views]})];
CSV.resources=()=>[['Material','Type','Programme','Language','Previews','Downloads','Shares','Leads'],...S.resources.map(r=>[r.title,r.type,r.course,r.lang,r.stats.preview||0,r.stats.download||0,(r.stats.share||0)+(r.stats.copy||0),S.refs.filter(x=>x.via&&x.via.res===r.id&&live(x)).length])];
