if(!window.__NO_AUTO_INIT)appInit();
