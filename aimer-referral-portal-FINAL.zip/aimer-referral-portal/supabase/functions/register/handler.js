// Instant registration: checks the details, then creates an already-confirmed partner account.
// No email is sent, so signing up does not wait for (or depend on) an email service.
// The same checks run in the database (check_signup and the sign-up trigger), so this file is not the only guard.
const CATEGORIES = ["Student", "Employee", "Alumni", "MKC Network", "Ambassador"];
const EMAIL = /^[^@\s]+@[^@\s]+\.[^@\s]+$/;
const bad = (error) => ({ status: 400, body: { error } });

// d = { ip, rpc(fn, args) -> {data, error}, createUser(user) -> {error} }
export async function register(body, d) {
  if (body.website) return { status: 200, body: { ok: true } };                       // hidden field: bots fill it in
  const s = (k, max) => (typeof body[k] === "string" ? body[k].trim().slice(0, max) : "");
  const name = s("name", 120), email = s("email", 200).toLowerCase(), phone = s("phone", 30), country = s("country", 60), category = s("category", 20), note = s("note", 120);
  const password = typeof body.password === "string" ? body.password : "";
  const digits = phone.replace(/\D/g, "");
  if (!name) return bad("Enter your full name.");
  if (!phone.startsWith("+") || digits.length < 8 || digits.length > 15) return bad("Check your mobile number. Pick the country code and type the number.");
  if (!EMAIL.test(email)) return bad("Enter a valid email address.");
  if (password.length < 8) return bad("Use at least 8 characters for your password.");
  if (password.length > 72) return bad("Use 72 characters or fewer for your password.");
  if (!CATEGORIES.includes(category)) return bad("Choose one of the listed categories.");

  // Limits are generous per network address, because a whole office can share one; tighter per email and per number.
  for (const [key, limit, seconds] of [[`reg-ip:${d.ip}`, 600, 600], [`reg-email:${email}`, 5, 3600], [`reg-phone:${digits}`, 5, 3600]]) {
    const r = await d.rpc("hit_rate_limit", { p_key: key, p_limit: limit, p_seconds: seconds });
    if (r.data === false) return { status: 429, body: { error: "Too many attempts. Please wait a few minutes and try again." } };
  }
  const chk = await d.rpc("check_signup", { p_phone: phone, p_email: email, p_category: category });
  if (chk.error) return { status: 500, body: { error: "We could not create your account. Please try again." } };
  const refusal = {
    phone_taken: "This mobile number is already registered. Log in instead.",
    email_taken: "An account with this email already exists. Log in instead.",
    employee_email_required: "Employees sign up with their official AIMER email. Choose another category if you are not AIMER staff.",
  }[chk.data];
  if (refusal) return { status: 409, body: { error: refusal } };

  const r = await d.createUser({ email, password, email_confirm: true,
    user_metadata: { account_type: "partner", full_name: name, phone, country, category, category_note: note } });
  if (r.error) {
    if (/already|registered|exists/i.test(r.error.message || "")) return { status: 409, body: { error: "An account with this email already exists. Log in instead." } };
    return { status: 500, body: { error: "We could not create your account. Please try again." } };
  }
  return { status: 200, body: { ok: true } };
}
