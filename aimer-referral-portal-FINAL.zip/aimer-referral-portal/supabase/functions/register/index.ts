// Public endpoint for instant registration. See handler.js for the rules.
import "jsr:@supabase/functions-js/edge-runtime.d.ts";
import { createClient } from "jsr:@supabase/supabase-js@2";
import { register } from "./handler.js";

const origins = (Deno.env.get("ALLOWED_ORIGIN") ?? "*").split(",").map((s) => s.trim());
const corsFor = (req: Request) => {
  const o = req.headers.get("origin") ?? "";
  const allow = origins.includes("*") ? "*" : origins.includes(o) ? o : origins[0];
  return { "Access-Control-Allow-Origin": allow, "Vary": "Origin", "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type", "Access-Control-Allow-Methods": "POST, OPTIONS" };
};
const reply = (req: Request, body: unknown, status = 200) => new Response(JSON.stringify(body), { status, headers: { ...corsFor(req), "Content-Type": "application/json" } });

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: corsFor(req) });
  if (req.method !== "POST") return reply(req, { error: "Method not allowed" }, 405);
  let body: Record<string, unknown>;
  try { body = await req.json(); } catch { return reply(req, { error: "Invalid request" }, 400); }
  const db = createClient(Deno.env.get("SUPABASE_URL")!, Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!, { auth: { persistSession: false } });
  const ip = (req.headers.get("x-forwarded-for") ?? "").split(",")[0].trim() || "unknown";
  try {
    const out = await register(body, { ip, rpc: (fn: string, args: Record<string, unknown>) => db.rpc(fn, args), createUser: (u: unknown) => db.auth.admin.createUser(u as never) });
    return reply(req, out.body, out.status);
  } catch (_e) {
    return reply(req, { error: "We could not create your account. Please try again." }, 500);
  }
});
