// Admin tools that need the service key: invite admins, register event organizers, bulk-import partners.
// Every call checks the caller's admin role first.
import "jsr:@supabase/functions-js/edge-runtime.d.ts";
import { createClient } from "jsr:@supabase/supabase-js@2";

const origins = (Deno.env.get("ALLOWED_ORIGIN") ?? "*").split(",").map((s) => s.trim());
const corsFor = (req: Request) => {
  const o = req.headers.get("origin") ?? "";
  const allow = origins.includes("*") ? "*" : origins.includes(o) ? o : origins[0];
  return { "Access-Control-Allow-Origin": allow, "Vary": "Origin", "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type", "Access-Control-Allow-Methods": "POST, OPTIONS" };
};
const reply = (req: Request, b: unknown, s = 200) => new Response(JSON.stringify(b), { status: s, headers: { ...corsFor(req), "Content-Type": "application/json" } });
const ROLES = ["superadmin", "marketing", "admissions", "finance", "ceo", "support", "event"];
const CATEGORIES = ["Student", "Employee", "Alumni", "MKC Network", "Ambassador"];
const TRUSTED = ["Employee", "MKC Network"];       // imported from an HR or MKC list: verified on import
const isEmail = (e: string) => /^\S+@\S+\.\S+$/.test(e);

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: corsFor(req) });
  if (req.method !== "POST") return reply(req, { error: "Method not allowed" }, 405);
  const url = Deno.env.get("SUPABASE_URL")!;
  const caller = createClient(url, Deno.env.get("SUPABASE_ANON_KEY")!, { global: { headers: { Authorization: req.headers.get("Authorization") ?? "" } } });
  const { data: role } = await caller.rpc("admin_role");
  const { data: u } = await caller.auth.getUser();
  if (!role || !u?.user) return reply(req, { error: "Sign in as an admin" }, 403);
  const body = await req.json().catch(() => ({}));
  const admin = createClient(url, Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!, { auth: { persistSession: false } });
  const site = Deno.env.get("SITE_URL") ?? undefined;
  const audit = (action: string, entity?: string, id?: string) => admin.from("audit_logs").insert({ actor: u.user!.id, actor_role: role, action, entity, entity_id: id });

  if (body.action === "invite_admin") {
    if (role !== "superadmin") return reply(req, { error: "Only a Super Admin can create admin accounts" }, 403);
    const { full_name, email, role: newRole } = body;
    if (!full_name || !isEmail(email ?? "") || !ROLES.includes(newRole)) return reply(req, { error: "Enter a name, a work email and a valid role" }, 400);
    const { data, error } = await admin.auth.admin.inviteUserByEmail(email.toLowerCase(), { data: { account_type: "admin", full_name }, redirectTo: site });
    if (error) return reply(req, { error: error.message }, 400);
    const { error: e2 } = await admin.from("admin_users").insert({ user_id: data.user.id, full_name, email: email.toLowerCase(), role: newRole });
    if (e2) return reply(req, { error: e2.message }, 400);
    await audit(`Invited admin ${full_name} as ${newRole}`, "admin_user", data.user.id);
    return reply(req, { ok: true });
  }

  if (!["superadmin", "marketing", "event"].includes(role)) return reply(req, { error: "Your role can’t do this" }, 403);

  if (body.action === "organizer") {
    const { name, phone, email, campaign_code } = body;
    if (!name || (phone ?? "").replace(/\D/g, "").length < 8 || !isEmail(email ?? "")) return reply(req, { error: "Enter the organizer’s name, mobile and email" }, 400);
    const { data: camp } = await admin.from("campaigns").select("id,name,kind,organizer_id").eq("code", campaign_code).maybeSingle();
    if (!camp || camp.kind !== "event") return reply(req, { error: "Choose an event" }, 400);
    if (camp.organizer_id) return reply(req, { error: "This event already has an organizer" }, 400);
    const { data: dup } = await admin.rpc("check_signup", { p_phone: phone, p_email: email });
    if (dup !== "ok") return reply(req, { error: "A partner with this mobile or email already exists" }, 400);
    const { data, error } = await admin.auth.admin.inviteUserByEmail(email.toLowerCase(), { data: { account_type: "partner", full_name: name, phone }, redirectTo: site });
    if (error) return reply(req, { error: error.message }, 400);
    const id = data.user.id;
    await admin.from("partner_affiliations").insert({ partner_id: id, category: "Event organizer", status: "VERIFIED", reviewed_by: u.user.id, reviewed_at: new Date().toISOString(), details: { event: camp.name } });
    await admin.from("partners").update({ status: "VERIFIED", event_campaign_id: camp.id, verified_by: u.user.id }).eq("id", id);
    await admin.from("campaigns").update({ organizer_id: id }).eq("id", camp.id);
    await audit(`Registered event organizer ${name} for ${camp.name}`, "campaign", campaign_code);
    return reply(req, { ok: true });
  }

  if (body.action === "import") {
    if (role === "event") return reply(req, { error: "Your role can’t import partners" }, 403);
    const rows = Array.isArray(body.rows) ? body.rows.slice(0, 200) : [];
    let ok = 0; const skipped: string[] = [];
    for (const r of rows) {
      const name = String(r.name ?? "").trim(), phone = String(r.phone ?? "").trim(), email = String(r.email ?? "").trim().toLowerCase();
      const cat = CATEGORIES.find((c) => c.toLowerCase() === String(r.category ?? "").trim().toLowerCase());
      if (!name || phone.replace(/\D/g, "").length < 8 || !isEmail(email) || !cat) { skipped.push(`${name || "(no name)"}: missing or invalid details`); continue; }
      const { data: dup } = await admin.rpc("check_signup", { p_phone: phone, p_email: email });
      if (dup !== "ok") { skipped.push(`${name}: already registered`); continue; }
      const { data, error } = await admin.auth.admin.inviteUserByEmail(email, { data: { account_type: "partner", full_name: name, phone }, redirectTo: site });
      if (error) { skipped.push(`${name}: ${error.message}`); continue; }
      const trusted = TRUSTED.includes(cat);
      await admin.from("partner_affiliations").insert({ partner_id: data.user.id, category: cat, status: trusted ? "VERIFIED" : "UNDER_REVIEW", details: { imported: true } });
      await admin.from("partners").update({ status: trusted ? "VERIFIED" : "UNDER_REVIEW", verified_by: trusted ? u.user.id : null }).eq("id", data.user.id);
      ok++;
    }
    await audit(`Bulk imported ${ok} partners (${skipped.length} skipped)`, "partner");
    return reply(req, { ok: true, imported: ok, skipped });
  }
  return reply(req, { error: "Unknown action" }, 400);
});
