// LeadSquared admin tools: connection status, connection test, and retrying leads that failed to sync.
// Uses the same 'lsq_field_map' setting as the public form.
import "jsr:@supabase/functions-js/edge-runtime.d.ts";
import { createClient } from "jsr:@supabase/supabase-js@2";

const origins = (Deno.env.get("ALLOWED_ORIGIN") ?? "*").split(",").map((s) => s.trim());
const corsFor = (req: Request) => {
  const o = req.headers.get("origin") ?? "";
  const allow = origins.includes("*") ? "*" : origins.includes(o) ? o : origins[0];
  return { "Access-Control-Allow-Origin": allow, "Vary": "Origin", "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type", "Access-Control-Allow-Methods": "POST, OPTIONS" };
};
const reply = (req: Request, b: unknown, s = 200) => new Response(JSON.stringify(b), { status: s, headers: { ...corsFor(req), "Content-Type": "application/json" } });

// Accept the host however it was pasted (with or without https:// and the trailing /v2/) and ignore stray spaces in the keys
const LSQ_HOST = (Deno.env.get("LSQ_API_HOST") ?? "").trim().replace(/^https?:\/\//i, "").split("/")[0] || undefined;
const LSQ_KEY = (Deno.env.get("LSQ_ACCESS_KEY") ?? "").trim() || undefined, LSQ_SECRET = (Deno.env.get("LSQ_SECRET_KEY") ?? "").trim() || undefined;
const lsqReady = !!(LSQ_HOST && LSQ_KEY && LSQ_SECRET);
const lsqHeaders = { "Content-Type": "application/json", "x-LSQ-AccessKey": LSQ_KEY ?? "", "x-LSQ-SecretKey": LSQ_SECRET ?? "" };

type Entry = { field: string; on: boolean; value?: string; web?: string };
// Defaults follow AIMER's LeadSquared "Add lead" form. Field names are LeadSquared schema names and are editable in Integrations & Settings.
const DEFAULTS: Record<string, Entry & { req?: boolean }> = {
  name_first: { field: "FirstName", on: true, req: true },
  name_last: { field: "LastName", on: true },
  phone: { field: "Phone", on: true, req: true },
  email: { field: "EmailAddress", on: true },
  programme: { field: "mx_Course_Interested_in", on: true, req: true },
  stage: { field: "ProspectStage", on: true, value: "New Lead (L0.5)" },
  source: { field: "Source", on: false, value: "Referral", web: "Website" },
  campaign: { field: "SourceCampaign", on: true },
  medium: { field: "SourceMedium", on: true },
  content: { field: "SourceContent", on: true },
  notes: { field: "Notes", on: true },
  country: { field: "Country", on: false },
  level: { field: "mx_Qualification", on: false },
  owner: { field: "OwnerId", on: false, value: "" },
  origin: { field: "mx_Lead_Origin", on: false, value: "" },
  acquisition: { field: "mx_Lead_Acquisition_method", on: false, value: "" },
  referral_id: { field: "mx_Referral_ID", on: false },
  partner_code: { field: "mx_Partner_Code", on: false },
};
const FIXED = ["stage", "owner", "origin", "acquisition"];

// The owner is set with OwnerId, which takes the LeadSquared user's ID. If an email address is configured, the ID is looked up (and remembered for 10 minutes).
const ownerCache = new Map<string, { id: string | null; at: number }>();
async function resolveOwner(value: string): Promise<string | null> {
  const v = value.trim();
  if (/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(v)) return v;
  const key = v.toLowerCase(), hit = ownerCache.get(key);
  if (hit && Date.now() - hit.at < 600000) return hit.id;
  let id: string | null = null;
  try {
    const r = await fetch(`https://${LSQ_HOST}/v2/UserManagement.svc/Users.Get`, { headers: lsqHeaders, signal: AbortSignal.timeout(8000) });
    if (r.ok) { const users = await r.json(); const u = Array.isArray(users) ? users.find((x: any) => String(x?.EmailAddress ?? "").toLowerCase() === key) : null; id = u?.ID ?? u?.UserId ?? null; }
  } catch { /* leave the owner unset */ }
  ownerCache.set(key, { id, at: Date.now() });
  return id;
}
async function applyOwner(map: Record<string, Entry>): Promise<string> {
  const o = map.owner;
  if (!o.on || o.field.toLowerCase() !== "ownerid" || !o.value) return "";
  const id = await resolveOwner(o.value);
  if (id) { o.value = id; return ""; }
  o.value = "";
  return "owner not set: user not found in LeadSquared";
}
// LeadSquared stores numbers as +CC-number, so a lookup tries that form as well as +CCnumber
const CCS = ["971", "974", "966", "968", "965", "973", "91", "44", "65", "60", "1"];
function phoneVariants(p: string): string[] {
  const e = fmtPhone(p);
  if (!e.startsWith("+")) return [e];
  const d = e.slice(1), cc = CCS.find((c) => d.startsWith(c) && d.length - c.length >= 6);
  return cc ? [e, `+${cc}-${d.slice(cc.length)}`] : [e];
}
// true = already in LeadSquared, false = not found, null = a lookup failed, so the answer is unknown
async function lsqLookup(phone: string): Promise<boolean | null> {
  let unknown = false;
  for (const v of phoneVariants(phone)) {
    try {
      const r = await fetch(`https://${LSQ_HOST}/v2/LeadManagement.svc/RetrieveLeadByPhoneNumber?phone=${encodeURIComponent(v)}`, { headers: lsqHeaders, signal: AbortSignal.timeout(8000) });
      if (!r.ok) { unknown = true; continue; }
      const d = await r.json();
      if (Array.isArray(d) && d.length > 0) return true;
    } catch { unknown = true; }
  }
  return unknown ? null : false;
}

async function loadMap(db: any) {
  const { data } = await db.from("app_settings").select("value").eq("key", "lsq_field_map").maybeSingle();
  const saved = (data?.value ?? {}) as Record<string, any>;
  const out: Record<string, Entry> = {};
  for (const [k, d] of Object.entries(DEFAULTS)) {
    const u = saved[k] ?? {};
    out[k] = {
      field: typeof u.field === "string" && /^[A-Za-z][A-Za-z0-9_]{0,60}$/.test(u.field) ? u.field : d.field,
      on: d.req ? true : typeof u.on === "boolean" ? u.on : d.on,
      value: typeof u.value === "string" ? u.value.slice(0, 200) : d.value,
      web: typeof u.web === "string" ? u.web.slice(0, 200) : d.web,
    };
  }
  return out;
}
function buildAttrs(map: Record<string, Entry>, v: Record<string, unknown> & { credited: boolean }) {
  const a: { Attribute: string; Value: string }[] = [];
  const push = (k: string, val: unknown) => { const e = map[k]; if (e?.on && val !== undefined && val !== null && String(val).trim() !== "") a.push({ Attribute: e.field, Value: String(val).trim() }); };
  for (const k of Object.keys(map)) {
    if (FIXED.includes(k)) push(k, map[k].value);
    else if (k === "source") push(k, v.credited ? map.source.value : map.source.web);
    else push(k, v[k]);
  }
  a.push({ Attribute: "SearchBy", Value: map.phone.field });
  return a;
}
const splitName = (n: string) => { const p = n.trim().split(/\s+/); return { first: p[0] ?? "", last: p.slice(1).join(" ") }; };
const fmtPhone = (p: string) => { const t = p.trim(), d = t.replace(/\D/g, ""); return t.startsWith("+") ? "+" + d : t.startsWith("00") ? "+" + d.slice(2) : d; };
const leadNotes = (x: { credited: boolean; ref_no?: string; partner_code?: string; partner_category?: string; campaign?: string; how?: string; course_link?: string; resource?: string; level?: string; country?: string }) =>
  [x.credited ? `Ambassador referral${x.ref_no ? " " + x.ref_no : ""}` : "Website enquiry", x.partner_code ? `Partner ${x.partner_code}${x.partner_category ? " (" + x.partner_category + ")" : ""}` : "",
   x.campaign ? `Campaign ${x.campaign}` : "", x.how ? `Arrived via ${x.how}` : "", x.course_link ? `Course link ${x.course_link}` : "", x.resource ? `Material ${x.resource}` : "",
   x.level ? `Level: ${x.level}` : "", x.country ? `Country: ${x.country}` : ""].filter(Boolean).join(". ").slice(0, 1900);

const lsqExists = lsqLookup;

async function lsqCapture(attrs: { Attribute: string; Value: string }[]): Promise<{ ok: boolean; id?: string; message: string; existing?: boolean }> {
  if (!lsqReady) return { ok: false, message: "LeadSquared keys are not configured yet" };
  let last = "LeadSquared did not respond";
  for (let attempt = 1; attempt <= 3; attempt++) {
    try {
      const r = await fetch(`https://${LSQ_HOST}/v2/LeadManagement.svc/Lead.Capture`, { method: "POST", headers: lsqHeaders, body: JSON.stringify(attrs), signal: AbortSignal.timeout(10000) });
      const d = await r.json().catch(() => ({}));
      if (r.ok && d?.Status === "Success") return { ok: true, id: d?.Message?.Id, message: "Lead captured" };
      last = d?.ExceptionMessage ?? `LeadSquared returned ${r.status}`;
      // "cannot be updated" means LeadSquared matched an existing lead and refuses to change that field
      if (/cannot be updated/i.test(last)) return { ok: false, message: last, existing: true };
      if (r.status < 500) return { ok: false, message: last };
    } catch (e) { last = String(e); }
    await new Promise((res) => setTimeout(res, attempt * 500));
  }
  return { ok: false, message: `${last} (after 3 attempts)` };
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: corsFor(req) });
  if (req.method !== "POST") return reply(req, { error: "Method not allowed" }, 405);
  const url = Deno.env.get("SUPABASE_URL")!;
  const caller = createClient(url, Deno.env.get("SUPABASE_ANON_KEY")!, { global: { headers: { Authorization: req.headers.get("Authorization") ?? "" } } });
  const { data: role } = await caller.rpc("admin_role");
  if (!role) return reply(req, { error: "Sign in as an admin" }, 403);
  const { action, referral_id } = await req.json().catch(() => ({}));
  const db = createClient(url, Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!, { auth: { persistSession: false } });

  if (action === "status") return reply(req, { configured: lsqReady, host: LSQ_HOST ?? null, keyLast4: LSQ_KEY ? LSQ_KEY.slice(-4) : null, webhookSecret: !!Deno.env.get("LSQ_WEBHOOK_SECRET") });

  if (action === "test") {
    if (role !== "superadmin") return reply(req, { error: "Only a Super Admin can test the connection" }, 403);
    if (!lsqReady) return reply(req, { ok: false, message: "LeadSquared keys are not configured yet. Add them as function secrets." });
    try {
      const r = await fetch(`https://${LSQ_HOST}/v2/LeadManagement.svc/RetrieveLeadByPhoneNumber?phone=0000000000`, { headers: lsqHeaders, signal: AbortSignal.timeout(8000) });
      const ok = r.ok;
      await db.from("app_settings").upsert({ key: "lsq_last_test", value: { at: new Date().toISOString(), ok }, updated_at: new Date().toISOString() });
      return reply(req, { ok, message: ok ? "LeadSquared accepted the keys" : `LeadSquared returned ${r.status}. Check the host and keys.` });
    } catch (e) { return reply(req, { ok: false, message: `Couldn’t reach LeadSquared: ${String(e)}` }); }
  }

  if (action === "sync") {
    if (!["superadmin", "marketing", "event"].includes(role)) return reply(req, { error: "Your role can’t retry syncs" }, 403);
    const { data: items } = await db.rpc("referrals_to_sync", { p_limit: 25, p_referral: referral_id ?? null });
    const map = await loadMap(db);
    const ownerWarn = await applyOwner(map);
    let synced = 0, failed = 0, held = 0;
    for (const r of items ?? []) {
      // a claim that has not been reviewed is checked against the CRM first; if the lead exists or the check fails, it goes to Marketing instead
      if (!r.flag && lsqReady) {
        const found = await lsqExists(fmtPhone(r.phone ?? ""));
        if (found !== false) { await db.rpc("hold_referral_for_review", { p_referral: r.referral_id, p_flag: found === null ? "crm_unchecked" : "existing_lead" }); held++; continue; }
      }
      const how = r.source === "code" ? "Manual code" : r.source === "event" ? "Event list" : "Tracked link", nm = splitName(r.name ?? "");
      const vals = {
        credited: true, name_first: nm.first, name_last: nm.last, phone: fmtPhone(r.phone ?? ""), email: r.email, programme: r.course, country: r.country, level: r.level,
        campaign: r.campaign_code ?? "", medium: how, content: r.partner_code, referral_id: r.ref_no, partner_code: r.partner_code,
        notes: leadNotes({ credited: true, ref_no: r.ref_no, partner_code: r.partner_code, partner_category: r.partner_category, campaign: r.campaign_code, how, course_link: r.course_link ? r.course : "", resource: r.resource ?? "", level: r.level, country: r.country }),
      };
      let attrs = buildAttrs(map, vals);
      let res = await lsqCapture(attrs);
      if (!res.ok && res.existing) {
        // the lead already exists in LeadSquared. An unreviewed claim goes to Marketing; a reviewed one updates it but leaves its owner and stage alone
        if (!r.flag) { await db.rpc("hold_referral_for_review", { p_referral: r.referral_id, p_flag: "existing_lead" }); held++; continue; }
        attrs = buildAttrs({ ...map, owner: { ...map.owner, on: false }, stage: { ...map.stage, on: false } }, vals);
        res = await lsqCapture(attrs);
      }
      if (res.ok && ownerWarn) res.message += ` (${ownerWarn})`;
      await db.rpc("set_sync_result", { p_referral: r.referral_id, p_ok: res.ok, p_lsq_id: res.id ?? null, p_message: res.message, p_payload: attrs });
      res.ok ? synced++ : failed++;
    }
    return reply(req, { ok: true, synced, failed, held, message: failed ? (lsqReady ? "Some leads still couldn’t be sent" : "LeadSquared keys are not configured yet") : held ? `${held} held for Marketing’s attribution review` : "Synced" });
  }
  return reply(req, { error: "Unknown action" }, 400);
});
