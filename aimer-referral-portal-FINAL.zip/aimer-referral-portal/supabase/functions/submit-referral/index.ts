// Public endpoint behind the referral landing page and the general enquiry form.
// 1) rate-limit, 2) save the referral in Supabase first, 3) send the lead to LeadSquared with retries.
// If LeadSquared fails, the referral stays saved with sync_status 'failed' and can be retried from the admin panel.
// LeadSquared field names and fixed values come from the 'lsq_field_map' setting (Integrations & Settings), so they can change without a deploy.
import "jsr:@supabase/functions-js/edge-runtime.d.ts";
import { createClient } from "jsr:@supabase/supabase-js@2";

const origins = (Deno.env.get("ALLOWED_ORIGIN") ?? "*").split(",").map((s) => s.trim());
const corsFor = (req: Request) => {
  const o = req.headers.get("origin") ?? "";
  const allow = origins.includes("*") ? "*" : origins.includes(o) ? o : origins[0];
  return { "Access-Control-Allow-Origin": allow, "Vary": "Origin", "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type", "Access-Control-Allow-Methods": "POST, OPTIONS" };
};
const reply = (req: Request, b: unknown, s = 200) => new Response(JSON.stringify(b), { status: s, headers: { ...corsFor(req), "Content-Type": "application/json" } });

// Accept the host however it was pasted (with or without https:// and the trailing /v2/) and ignore stray spaces in the keys
const LSQ_HOST = (Deno.env.get("LSQ_API_HOST") ?? "").trim().replace(/^https?:\/\//i, "").split("/")[0] || undefined;
const LSQ_KEY = (Deno.env.get("LSQ_ACCESS_KEY") ?? "").trim() || undefined, LSQ_SECRET = (Deno.env.get("LSQ_SECRET_KEY") ?? "").trim() || undefined;
const lsqReady = !!(LSQ_HOST && LSQ_KEY && LSQ_SECRET);
const lsqHeaders = { "Content-Type": "application/json", "x-LSQ-AccessKey": LSQ_KEY ?? "", "x-LSQ-SecretKey": LSQ_SECRET ?? "" };

type Entry = { field: string; on: boolean; value?: string; web?: string };
// Defaults follow AIMER's LeadSquared "Add lead" form. Field names are LeadSquared schema names and are editable in Integrations & Settings.
const DEFAULTS: Record<string, Entry & { req?: boolean }> = {
  name_first: { field: "FirstName", on: true, req: true },
  name_last: { field: "LastName", on: true },
  phone: { field: "Phone", on: true, req: true },
  email: { field: "EmailAddress", on: true },
  programme: { field: "mx_Course_Interested_in", on: true, req: true },
  stage: { field: "ProspectStage", on: true, value: "New Lead (L0.5)" },
  source: { field: "Source", on: false, value: "Referral", web: "Website" },
  campaign: { field: "SourceCampaign", on: true },
  medium: { field: "SourceMedium", on: true },
  content: { field: "SourceContent", on: true },
  notes: { field: "Notes", on: true },
  country: { field: "Country", on: false },
  level: { field: "mx_Qualification", on: false },
  owner: { field: "OwnerId", on: false, value: "" },
  origin: { field: "mx_Lead_Origin", on: false, value: "" },
  acquisition: { field: "mx_Lead_Acquisition_method", on: false, value: "" },
  referral_id: { field: "mx_Referral_ID", on: false },
  partner_code: { field: "mx_Partner_Code", on: false },
};
const FIXED = ["stage", "owner", "origin", "acquisition"];

// The owner is set with OwnerId, which takes the LeadSquared user's ID. If an email address is configured, the ID is looked up (and remembered for 10 minutes).
const ownerCache = new Map<string, { id: string | null; at: number }>();
async function resolveOwner(value: string): Promise<string | null> {
  const v = value.trim();
  if (/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(v)) return v;
  const key = v.toLowerCase(), hit = ownerCache.get(key);
  if (hit && Date.now() - hit.at < 600000) return hit.id;
  let id: string | null = null;
  try {
    const r = await fetch(`https://${LSQ_HOST}/v2/UserManagement.svc/Users.Get`, { headers: lsqHeaders, signal: AbortSignal.timeout(8000) });
    if (r.ok) { const users = await r.json(); const u = Array.isArray(users) ? users.find((x: any) => String(x?.EmailAddress ?? "").toLowerCase() === key) : null; id = u?.ID ?? u?.UserId ?? null; }
  } catch { /* leave the owner unset */ }
  ownerCache.set(key, { id, at: Date.now() });
  return id;
}
async function applyOwner(map: Record<string, Entry>): Promise<string> {
  const o = map.owner;
  if (!o.on || o.field.toLowerCase() !== "ownerid" || !o.value) return "";
  const id = await resolveOwner(o.value);
  if (id) { o.value = id; return ""; }
  o.value = "";
  return "owner not set: user not found in LeadSquared";
}
// LeadSquared stores numbers as +CC-number, so a lookup tries that form as well as +CCnumber
const CCS = ["971", "974", "966", "968", "965", "973", "91", "44", "65", "60", "1"];
function phoneVariants(p: string): string[] {
  const e = fmtPhone(p);
  if (!e.startsWith("+")) return [e];
  const d = e.slice(1), cc = CCS.find((c) => d.startsWith(c) && d.length - c.length >= 6);
  return cc ? [e, `+${cc}-${d.slice(cc.length)}`] : [e];
}
// true = already in LeadSquared, false = not found, null = a lookup failed, so the answer is unknown
async function lsqLookup(phone: string): Promise<boolean | null> {
  let unknown = false;
  for (const v of phoneVariants(phone)) {
    try {
      const r = await fetch(`https://${LSQ_HOST}/v2/LeadManagement.svc/RetrieveLeadByPhoneNumber?phone=${encodeURIComponent(v)}`, { headers: lsqHeaders, signal: AbortSignal.timeout(8000) });
      if (!r.ok) { unknown = true; continue; }
      const d = await r.json();
      if (Array.isArray(d) && d.length > 0) return true;
    } catch { unknown = true; }
  }
  return unknown ? null : false;
}

async function loadMap(db: any) {
  const { data } = await db.from("app_settings").select("value").eq("key", "lsq_field_map").maybeSingle();
  const saved = (data?.value ?? {}) as Record<string, any>;
  const out: Record<string, Entry> = {};
  for (const [k, d] of Object.entries(DEFAULTS)) {
    const u = saved[k] ?? {};
    out[k] = {
      field: typeof u.field === "string" && /^[A-Za-z][A-Za-z0-9_]{0,60}$/.test(u.field) ? u.field : d.field,
      on: d.req ? true : typeof u.on === "boolean" ? u.on : d.on,
      value: typeof u.value === "string" ? u.value.slice(0, 200) : d.value,
      web: typeof u.web === "string" ? u.web.slice(0, 200) : d.web,
    };
  }
  return out;
}
function buildAttrs(map: Record<string, Entry>, v: Record<string, unknown> & { credited: boolean }) {
  const a: { Attribute: string; Value: string }[] = [];
  const push = (k: string, val: unknown) => { const e = map[k]; if (e?.on && val !== undefined && val !== null && String(val).trim() !== "") a.push({ Attribute: e.field, Value: String(val).trim() }); };
  for (const k of Object.keys(map)) {
    if (FIXED.includes(k)) push(k, map[k].value);
    else if (k === "source") push(k, v.credited ? map.source.value : map.source.web);
    else push(k, v[k]);
  }
  a.push({ Attribute: "SearchBy", Value: map.phone.field });
  return a;
}
const splitName = (n: string) => { const p = n.trim().split(/\s+/); return { first: p[0] ?? "", last: p.slice(1).join(" ") }; };
const fmtPhone = (p: string) => { const t = p.trim(), d = t.replace(/\D/g, ""); return t.startsWith("+") ? "+" + d : t.startsWith("00") ? "+" + d.slice(2) : d; };
const leadNotes = (x: { credited: boolean; ref_no?: string; partner_code?: string; partner_category?: string; campaign?: string; how?: string; course_link?: string; resource?: string; level?: string; country?: string }) =>
  [x.credited ? `Ambassador referral${x.ref_no ? " " + x.ref_no : ""}` : "Website enquiry", x.partner_code ? `Partner ${x.partner_code}${x.partner_category ? " (" + x.partner_category + ")" : ""}` : "",
   x.campaign ? `Campaign ${x.campaign}` : "", x.how ? `Arrived via ${x.how}` : "", x.course_link ? `Course link ${x.course_link}` : "", x.resource ? `Material ${x.resource}` : "",
   x.level ? `Level: ${x.level}` : "", x.country ? `Country: ${x.country}` : ""].filter(Boolean).join(". ").slice(0, 1900);

async function lsqCapture(attrs: { Attribute: string; Value: string }[]): Promise<{ ok: boolean; id?: string; message: string; existing?: boolean }> {
  if (!lsqReady) return { ok: false, message: "LeadSquared keys are not configured yet" };
  let last = "LeadSquared did not respond";
  for (let attempt = 1; attempt <= 3; attempt++) {
    try {
      const r = await fetch(`https://${LSQ_HOST}/v2/LeadManagement.svc/Lead.Capture`, { method: "POST", headers: lsqHeaders, body: JSON.stringify(attrs), signal: AbortSignal.timeout(10000) });
      const d = await r.json().catch(() => ({}));
      if (r.ok && d?.Status === "Success") return { ok: true, id: d?.Message?.Id, message: "Lead captured" };
      last = d?.ExceptionMessage ?? `LeadSquared returned ${r.status}`;
      // "cannot be updated" means LeadSquared matched an existing lead and refuses to change that field
      if (/cannot be updated/i.test(last)) return { ok: false, message: last, existing: true };
      if (r.status < 500) return { ok: false, message: last };
    } catch (e) { last = String(e); }
    await new Promise((res) => setTimeout(res, attempt * 500));
  }
  return { ok: false, message: `${last} (after 3 attempts)` };
}

async function lsqExists(phone: string): Promise<boolean | null> {
  if (!lsqReady) return false;   // not configured yet: nothing to check
  return await lsqLookup(phone);
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: corsFor(req) });
  if (req.method !== "POST") return reply(req, { error: "Method not allowed" }, 405);
  let b: Record<string, unknown>;
  try { b = await req.json(); } catch { return reply(req, { error: "Invalid request" }, 400); }
  if (b.website) return reply(req, { ok: true });                         // honeypot: bots fill hidden fields

  const str = (k: string, max = 200) => (typeof b[k] === "string" ? (b[k] as string).trim().slice(0, max) : "");
  const name = str("name"), phone = str("phone", 30), email = str("email"), course = str("course", 60), code = str("code", 12).toUpperCase();
  const source = str("source") === "code" ? "code" : "link";
  const resource = /^[0-9a-f-]{36}$/i.test(str("resource", 40)) ? str("resource", 40) : null;
  const digits = phone.replace(/\D/g, "");
  if (!name || digits.length < 8 || digits.length > 15 || !course) return reply(req, { error: "Enter the student’s name, a WhatsApp number with country code, and a programme." }, 400);
  if (email && !/^\S+@\S+\.\S+$/.test(email)) return reply(req, { error: "Check the email address." }, 400);

  const db = createClient(Deno.env.get("SUPABASE_URL")!, Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!, { auth: { persistSession: false } });
  const ip = (req.headers.get("x-forwarded-for") ?? "").split(",")[0].trim() || "unknown";
  const [a, c] = await Promise.all([db.rpc("hit_rate_limit", { p_key: `ip:${ip}`, p_limit: 20, p_seconds: 600 }), db.rpc("hit_rate_limit", { p_key: `phone:${digits}`, p_limit: 3, p_seconds: 3600 })]);
  if (a.data === false || c.data === false) return reply(req, { error: "Too many requests. Please wait a few minutes and try again." }, 429);

  const found = await lsqExists(fmtPhone(phone));
  const { data: cap, error } = await db.rpc("capture_referral", {
    p_code: code || null, p_course_code: course, p_source: source, p_student_name: name, p_phone: phone, p_email: email || null,
    p_country: str("country") || null, p_level: str("level") || null, p_resource: resource, p_course_link: b.courseLink === true, p_in_crm: found === true, p_crm_unknown: found === null,
  });
  if (error) return reply(req, { error: "We couldn’t save your details. Please try again." }, 500);
  if (cap?.error) return reply(req, { error: cap.error }, 409);
  if (cap?.reason === "course_not_open") return reply(req, { error: "Enquiries for this programme are closed right now." }, 409);
  if (cap?.reason === "no_partner" && source === "code" && code) return reply(req, { error: "We couldn’t find that referral code. Check it, or leave it blank." }, 409);

  // A claim that needs review (conflict, already in the CRM, or the CRM check failed) is not sent to LeadSquared yet,
  // so it can never silently overwrite an existing lead's ownership. Marketing's decision releases it.
  if (cap?.credited && cap.held) {
    await db.from("integration_logs").insert({ referral_id: cap.referral_id, event: "Lead.Capture held", ok: true, message: `Held for attribution review (${cap.flag}). Not sent to LeadSquared until Marketing decides.` });
    return reply(req, { ok: true, credited: true, ref_no: cap.ref_no, flagged: true, held: true, synced: false });
  }
  const credited = !!cap?.credited, how = source === "code" ? "Manual code" : "Tracked link", nm = splitName(name);
  const map = await loadMap(db);
  const ownerWarn = await applyOwner(map);
  const attrs = buildAttrs(map, {
    credited, name_first: nm.first, name_last: nm.last, phone: fmtPhone(phone), email, programme: course, country: str("country"), level: str("level"),
    ...(credited ? { campaign: cap.campaign_code ?? "", medium: how, content: cap.partner_code, referral_id: cap.ref_no, partner_code: cap.partner_code } : {}),
    notes: leadNotes({ credited, ref_no: cap?.ref_no, partner_code: cap?.partner_code, partner_category: cap?.partner_category, campaign: cap?.campaign_code, how: credited ? how : "",
      course_link: credited && b.courseLink === true ? course : "", resource: credited ? resource ?? "" : "", level: str("level"), country: str("country") }),
  });
  const sync = await lsqCapture(attrs);
  // LeadSquared says it matched an existing lead and cannot update it: hold the claim for Marketing instead of retrying
  if (!sync.ok && sync.existing && credited) {
    await db.rpc("hold_referral_for_review", { p_referral: cap.referral_id, p_flag: "existing_lead" });
    return reply(req, { ok: true, credited: true, ref_no: cap.ref_no, flagged: true, held: true, synced: false });
  }
  if (sync.ok && ownerWarn) sync.message += ` (${ownerWarn})`;
  if (credited) await db.rpc("set_sync_result", { p_referral: cap.referral_id, p_ok: sync.ok, p_lsq_id: sync.id ?? null, p_message: sync.message, p_payload: attrs });
  else await db.from("integration_logs").insert({ event: "Lead.Capture (general enquiry)", ok: sync.ok, message: `${sync.message}; no referral credit (${cap?.reason ?? "no code"})`, payload: attrs });
  return reply(req, { ok: true, credited, ref_no: cap?.ref_no ?? null, flagged: !!cap?.flag, synced: sync.ok });
});
