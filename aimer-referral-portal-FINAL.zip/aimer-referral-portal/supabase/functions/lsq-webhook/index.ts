// Receives LeadSquared webhooks (lead stage changes). Secured with a shared secret header.
// Only early stages (Contacted, Application) are taken from the CRM; admissions and payments are confirmed by AIMER staff in the portal.
import "jsr:@supabase/functions-js/edge-runtime.d.ts";
import { createClient } from "jsr:@supabase/supabase-js@2";

const STAGE_MAP: Record<string, number> = JSON.parse(Deno.env.get("LSQ_STAGE_MAP") ?? '{"Contacted":1,"Counselling":1,"Application Started":2,"Application":2}');

// Compare secrets without leaking timing information
function safeEqual(a: string, b: string): boolean {
  const x = new TextEncoder().encode(a), y = new TextEncoder().encode(b);
  let diff = x.length ^ y.length;
  for (let i = 0; i < Math.max(x.length, y.length); i++) diff |= (x[i] ?? 0) ^ (y[i] ?? 0);
  return diff === 0;
}

Deno.serve(async (req) => {
  if (req.method !== "POST") return new Response("Method not allowed", { status: 405 });
  const secret = Deno.env.get("LSQ_WEBHOOK_SECRET");
  const given = req.headers.get("x-aimer-webhook-secret") ?? "";
  if (!secret || !safeEqual(given, secret)) return new Response("Unauthorized", { status: 401 });
  const body = await req.json().catch(() => null);
  if (!body) return new Response("Bad request", { status: 400 });
  const db = createClient(Deno.env.get("SUPABASE_URL")!, Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!, { auth: { persistSession: false } });
  const items = Array.isArray(body) ? body : [body];
  let applied = 0, ignored = 0;
  for (const it of items) {
    const cur = it?.Current ?? it?.After ?? it;
    const id = cur?.ProspectID ?? cur?.ProspectId ?? it?.ProspectID;
    const stageName = cur?.ProspectStage ?? it?.ProspectStage;
    const stage = STAGE_MAP[stageName];
    if (!id || stage === undefined) { ignored++; continue; }
    const { error } = await db.rpc("apply_crm_stage", { p_lsq_id: id, p_stage: stage, p_note: `LeadSquared stage: ${stageName}` });
    if (error) { await db.from("integration_logs").insert({ event: "Webhook.StageChange", ok: false, message: error.message }); ignored++; } else applied++;
  }
  return new Response(JSON.stringify({ ok: true, applied, ignored }), { headers: { "Content-Type": "application/json" } });
});
