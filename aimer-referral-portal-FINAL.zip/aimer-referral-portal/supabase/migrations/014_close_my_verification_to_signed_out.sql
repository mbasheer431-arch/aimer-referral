-- my_verification() is only for signed-in partners; signed-out visitors must not be able to call it.
revoke execute on function public.my_verification() from public, anon;
grant execute on function public.my_verification() to authenticated;

-- Functions created from now on are not callable by signed-out visitors unless granted on purpose.
do $$ begin
  alter default privileges for role postgres in schema public revoke execute on functions from anon, public;
exception when others then null;
end $$;
