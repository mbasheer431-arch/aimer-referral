-- AIMER Ambassador Program: starting catalogue, campaign and incentive policy
insert into public.courses (code, name, short_description, description, eligibility, duration, fee, mode, benefits, color, status, launched_at) values
 ('UGBP','UGBP','Undergraduate business programme','Replace with the official UGBP overview.','After Class 12','3 years',0,'Residential, on campus',array['Industry-linked curriculum','Mentoring','Placement support'],'#22B8D8','Active',now()),
 ('PGBP','PGBP','Postgraduate business programme','Replace with the official PGBP overview.','Bachelor’s degree','2 years',0,'Residential, on campus',array['Industry-linked curriculum','Mentoring','Placement support'],'#2F7DE1','Active',now()),
 ('HSBC','HSBC','Higher secondary business programme','Replace with the official HSBC overview.','After Class 10','2 years',0,'Residential, on campus',array['Business foundations','Mentoring','Leadership activities'],'#F2A531','Active',now());

select set_config('app.bypass','on',true);
insert into public.campaigns (code, name, kind, description, terms, start_date, end_date, status) values
 ('REF-26','AIMER Referral Campaign 2026','programme','Main referral campaign for the 2026 to 2027 intake.',
  'Incentives follow the approved progressive slab matrix. Paid 50% on admission fee and 50% on first instalment.', current_date, '2027-06-30', 'Active');

insert into public.campaign_courses (campaign_id, course_id)
select c.id, k.id from public.campaigns c, public.courses k where c.code = 'REF-26';

insert into public.policy_versions (version, note) values (1, 'Approved progressive incentive matrix for UGBP, PGBP and HSBC');
insert into public.incentive_rates (policy_version, course_id, slab, amount)
select 1, c.id, s.slab, s.amount from public.courses c
join (values ('UGBP',0,30000),('UGBP',1,40000),('UGBP',2,50000),('UGBP',3,60000),
             ('PGBP',0,20000),('PGBP',1,30000),('PGBP',2,40000),('PGBP',3,50000),
             ('HSBC',0,10000),('HSBC',1,15000),('HSBC',2,20000),('HSBC',3,25000)) as s(code,slab,amount) on s.code = c.code;

insert into public.app_settings (key, value) values
 ('attribution_window_days','90'), ('duplicate_rule','"mobile_or_email"'), ('minimum_payout','0'),
 ('lsq_api_host','"api-in21.leadsquared.com"'),
 ('counsellors','["Counsellor 1","Counsellor 2","Counsellor 3"]');
