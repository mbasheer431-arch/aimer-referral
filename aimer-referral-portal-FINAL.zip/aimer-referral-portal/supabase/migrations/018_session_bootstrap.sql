-- 018: one request instead of about 22 when someone logs in or the screen refreshes.
-- Runs as the signed-in person, so every security rule still applies exactly as before.
create or replace function public.session_bootstrap() returns jsonb
language plpgsql stable security invoker set search_path = public as $$
declare uid uuid := auth.uid(); adm record;
begin
  if uid is null then return jsonb_build_object('kind', 'none'); end if;
  select role, status, full_name into adm from public.admin_users where user_id = uid;
  if found then
    if adm.status = 'Active' then return jsonb_build_object('kind', 'admin', 'role', adm.role, 'name', adm.full_name); end if;
    return jsonb_build_object('kind', 'admin_inactive');
  end if;
  if not exists (select 1 from public.partners where id = uid) then return jsonb_build_object('kind', 'none'); end if;
  return jsonb_build_object('kind', 'partner',
    'courses',                 (select coalesce(jsonb_agg(to_jsonb(t)), '[]'::jsonb) from (select * from public.courses order by created_at limit 1000) t),
    'campaigns',               (select coalesce(jsonb_agg(to_jsonb(t)), '[]'::jsonb) from (select * from public.campaigns order by created_at limit 1000) t),
    'campaign_courses',        (select coalesce(jsonb_agg(to_jsonb(t)), '[]'::jsonb) from (select * from public.campaign_courses limit 1000) t),
    'policy_versions',         (select coalesce(jsonb_agg(to_jsonb(t)), '[]'::jsonb) from (select * from public.policy_versions order by version limit 1000) t),
    'incentive_rates',         (select coalesce(jsonb_agg(to_jsonb(t)), '[]'::jsonb) from (select * from public.incentive_rates limit 1000) t),
    'resources',               (select coalesce(jsonb_agg(to_jsonb(t)), '[]'::jsonb) from (select * from public.resources order by created_at desc limit 1000) t),
    'partners',                (select coalesce(jsonb_agg(to_jsonb(t)), '[]'::jsonb) from (select * from public.partners order by created_at limit 1000) t),
    'partner_affiliations',    (select coalesce(jsonb_agg(to_jsonb(t)), '[]'::jsonb) from (select * from public.partner_affiliations limit 1000) t),
    'notifications',           (select coalesce(jsonb_agg(to_jsonb(t)), '[]'::jsonb) from (select * from public.notifications order by created_at desc limit 1000) t),
    'notification_recipients', (select coalesce(jsonb_agg(to_jsonb(t)), '[]'::jsonb) from (select * from public.notification_recipients limit 1000) t),
    'support_tickets',         (select coalesce(jsonb_agg(to_jsonb(t)), '[]'::jsonb) from (select * from public.support_tickets order by created_at desc limit 1000) t),
    'ticket_messages',         (select coalesce(jsonb_agg(to_jsonb(t)), '[]'::jsonb) from (select * from public.ticket_messages order by created_at limit 1000) t),
    'referrals',               (select coalesce(jsonb_agg(to_jsonb(t)), '[]'::jsonb) from public.get_my_referrals() t),
    'reward_transactions',     (select coalesce(jsonb_agg(to_jsonb(t)), '[]'::jsonb) from (select * from public.reward_transactions limit 1000) t),
    'payout_batches',          (select coalesce(jsonb_agg(to_jsonb(t)), '[]'::jsonb) from (select * from public.payout_batches order by created_at limit 1000) t),
    'adjustments',             (select coalesce(jsonb_agg(to_jsonb(t)), '[]'::jsonb) from (select * from public.adjustments order by created_at limit 1000) t),
    'bank',                    (select coalesce(jsonb_agg(to_jsonb(t)), '[]'::jsonb) from public.get_my_bank() t),
    'leaderboard',             (select coalesce(jsonb_agg(to_jsonb(t)), '[]'::jsonb) from public.get_leaderboard() t),
    'verification',            (select coalesce(jsonb_agg(to_jsonb(t)), '[]'::jsonb) from public.my_verification() t));
end $$;
revoke execute on function public.session_bootstrap() from public, anon;
grant execute on function public.session_bootstrap() to authenticated;

-- The leaderboard shows the top 20 and the signed-in person's own position, not all 1,000 partners.
create or replace function public.get_leaderboard()
returns table(rank bigint, display_name text, categories text, admissions bigint, referrals bigint, is_me boolean)
language sql stable security definer set search_path = public as $$
  with ranked as (
    select row_number() over (order by count(*) filter (where r.stage >= 3 and not r.cancelled) desc, count(r.id) desc) as rank,
           split_part(p.full_name, ' ', 1) || coalesce(' ' || left(nullif(split_part(p.full_name, ' ', 2), ''), 1) || '.', '') as display_name,
           (select string_agg(category, ', ') from public.partner_affiliations a where a.partner_id = p.id and a.status = 'VERIFIED') as categories,
           count(*) filter (where r.stage >= 3 and not r.cancelled) as admissions,
           count(r.id) as referrals,
           p.id = auth.uid() as is_me
    from public.partners p join public.referrals r on r.partner_id = p.id and r.attribution <> 'rejected'
    where p.status = 'VERIFIED' and public.is_verified_partner()
    group by p.id)
  select rank, display_name, categories, admissions, referrals, is_me from ranked where rank <= 20 or is_me order by rank
$$;
