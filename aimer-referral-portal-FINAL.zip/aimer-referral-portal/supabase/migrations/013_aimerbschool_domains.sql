-- Official AIMER staff email formats: name@aimerbschool.com and name@aimerbschool.in
update public.app_settings set value = '["aimerbschool.com","aimerbschool.in"]', updated_at = now() where key = 'employee_email_domains';

create or replace function public.employee_email_message() returns text
language sql stable security definer set search_path = public as $$
  select 'Employees need their official AIMER email (' || coalesce((select string_agg('name@' || d, ' or ') from public.app_settings s, jsonb_array_elements_text(s.value) d where s.key = 'employee_email_domains'), 'name@aimerbschool.com') || '). Choose another category if you are not AIMER staff.'
$$;
revoke execute on function public.employee_email_message() from public, anon, authenticated;
