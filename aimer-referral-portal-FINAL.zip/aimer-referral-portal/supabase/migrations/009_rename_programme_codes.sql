-- Official programme codes confirmed by AIMER: UGBIP, PGBIP, HSBIP (applied to the live project after launch data was empty)
update public.courses set code = 'UGBIP', name = 'UGBIP' where code = 'UGBP';
update public.courses set code = 'PGBIP', name = 'PGBIP' where code = 'PGBP';
update public.courses set code = 'HSBIP', name = 'HSBIP' where code = 'HSBC';
