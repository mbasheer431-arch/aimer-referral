-- Clear messages instead of raw database errors for duplicate transfer references and admission numbers
create or replace function public.record_payout_transfer(p_batch uuid, p_transfer_ref text, p_proof_path text default null) returns void
language plpgsql security definer set search_path = public as $$
declare b public.payout_batches;
begin
  perform public.require_role('finance');
  select * into b from public.payout_batches where id = p_batch for update;
  if b.status <> 'approved' then raise exception 'Only approved batches can be paid'; end if;
  if coalesce(trim(p_transfer_ref), '') = '' then raise exception 'Enter the bank transfer reference'; end if;
  if exists (select 1 from public.payout_batches where transfer_ref = trim(p_transfer_ref) and id <> b.id) then raise exception 'That transfer reference is already used on another batch'; end if;
  update public.payout_batches set status = 'paid', transfer_ref = trim(p_transfer_ref), proof_path = p_proof_path, paid_at = now() where id = b.id;
  update public.reward_transactions set status = 'paid', paid_at = now() where batch_id = b.id and status = 'approved';
  perform public.audit('Recorded transfer ' || trim(p_transfer_ref) || ' for ' || b.batch_no, 'payout_batch', b.id::text, null);
end $$;

create or replace function public.advance_referral(p_referral uuid, p_admission_no text default null, p_note text default null) returns smallint
language plpgsql security definer set search_path = public as $$
declare r public.referrals; v_no text := nullif(trim(coalesce(p_admission_no, '')), '');
begin
  perform public.require_role('admissions');
  select * into r from public.referrals where id = p_referral for update;
  if r.cancelled or r.attribution = 'rejected' then raise exception 'This referral is closed'; end if;
  if r.stage >= 3 then raise exception 'Payment milestones are verified by Finance'; end if;
  if r.stage = 2 and v_no is null then raise exception 'Enter the admission number'; end if;
  if v_no is not null and exists (select 1 from public.referrals where admission_no = v_no and id <> p_referral) then raise exception 'That admission number is already recorded'; end if;
  update public.referrals set stage = stage + 1, admission_no = coalesce(v_no, admission_no) where id = p_referral;
  insert into public.referral_stage_events(referral_id, from_stage, to_stage, note, actor) values (p_referral, r.stage, r.stage + 1, p_note, auth.uid());
  perform public.audit('Moved referral to stage ' || (r.stage + 1), 'referral', r.ref_no, null);
  return r.stage + 1;
end $$;
