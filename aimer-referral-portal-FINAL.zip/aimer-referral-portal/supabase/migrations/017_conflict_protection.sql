-- 017: protection against two actions colliding or silently overwriting each other
-- 1) moving a referral to the next stage can state the stage the person saw, so a double click or two staff can't skip a stage
-- 2) a partner's bank details are locked while a payout to them is in a batch or approved, so they can't be redirected mid-payout
-- 3) two Finance users preparing a batch at the same moment can't create an empty or overlapping batch
-- 4) reissuing a referral code records the old and the new code in the audit log

drop function if exists public.advance_referral(uuid, text, text);
create or replace function public.advance_referral(p_referral uuid, p_admission_no text default null, p_note text default null, p_from_stage smallint default null) returns smallint
language plpgsql security definer set search_path = public as $$
declare r public.referrals; v_no text := nullif(trim(coalesce(p_admission_no, '')), '');
begin
  perform public.require_role('admissions');
  select * into r from public.referrals where id = p_referral for update;
  if r.id is null then raise exception 'Referral not found'; end if;
  if p_from_stage is not null and r.stage <> p_from_stage then
    raise exception 'This referral has already moved on (it is now at stage %). Refresh the page and check before moving it again.', r.stage;
  end if;
  if r.cancelled or r.attribution = 'rejected' then raise exception 'This referral is closed'; end if;
  if r.stage >= 3 then raise exception 'Payment milestones are verified by Finance'; end if;
  if r.stage = 2 and v_no is null then raise exception 'Enter the admission number'; end if;
  if v_no is not null and exists (select 1 from public.referrals where admission_no = v_no and id <> p_referral) then raise exception 'That admission number is already recorded'; end if;
  update public.referrals set stage = stage + 1, admission_no = coalesce(v_no, admission_no) where id = p_referral;
  insert into public.referral_stage_events(referral_id, from_stage, to_stage, note, actor) values (p_referral, r.stage, r.stage + 1, p_note, auth.uid());
  perform public.audit('Moved referral to stage ' || (r.stage + 1), 'referral', r.ref_no, null);
  return r.stage + 1;
end $$;
revoke execute on function public.advance_referral(uuid, text, text, smallint) from public, anon;
grant execute on function public.advance_referral(uuid, text, text, smallint) to authenticated;

create or replace function public.set_bank_details(p_holder text, p_account text, p_ifsc text) returns void
language plpgsql security definer set search_path = public as $$
declare acct text := regexp_replace(coalesce(p_account, ''), '\D', '', 'g'); ifsc text := upper(trim(coalesce(p_ifsc, '')));
begin
  if not exists (select 1 from public.partners where id = auth.uid()) then raise exception 'Not allowed' using errcode = '42501'; end if;
  if exists (select 1 from public.reward_transactions where partner_id = auth.uid() and status in ('in_batch', 'approved')) then
    raise exception 'Your bank details are locked while a payout to you is being processed. They unlock once the transfer is recorded. Raise a support ticket if they need correcting now.';
  end if;
  if length(trim(coalesce(p_holder, ''))) < 2 then raise exception 'Enter the account holder name'; end if;
  if length(acct) < 6 or length(acct) > 20 then raise exception 'Check the account number'; end if;
  if ifsc !~ '^[A-Z]{4}0[A-Z0-9]{6}$' then raise exception 'Check the IFSC code'; end if;
  insert into public.partner_bank_details(partner_id, account_holder, account_number_enc, last4, ifsc, updated_at)
  values (auth.uid(), trim(p_holder), extensions.pgp_sym_encrypt(acct, public._bank_key()), right(acct, 4), ifsc, now())
  on conflict (partner_id) do update set account_holder = excluded.account_holder, account_number_enc = excluded.account_number_enc,
    last4 = excluded.last4, ifsc = excluded.ifsc, updated_at = now();
  perform public.audit('Partner saved bank details (account ending ' || right(acct, 4) || ')', 'partner', auth.uid()::text, null);
end $$;

create or replace function public.prepare_payout_batch() returns uuid
language plpgsql security definer set search_path = public as $$
declare bid uuid; no text; k integer := 1; pr record; a record; avail numeric; need numeric; take numeric; moved integer;
begin
  perform public.require_role('finance');
  perform pg_advisory_xact_lock(hashtext('payout-prepare'));   -- one batch is prepared at a time
  if not exists (select 1 from public.reward_transactions rt join public.partner_bank_details b on b.partner_id = rt.partner_id
                 join public.partners pp on pp.id = rt.partner_id where rt.status = 'eligible' and pp.status = 'VERIFIED') then
    raise exception 'No eligible payments with bank details';
  end if;
  no := 'PB-' || to_char(now(), 'YYYY-MM');
  while exists (select 1 from public.payout_batches where batch_no = no) loop k := k + 1; no := 'PB-' || to_char(now(), 'YYYY-MM') || '-' || k; end loop;
  insert into public.payout_batches(batch_no, prepared_by) values (no, auth.uid()) returning id into bid;
  update public.reward_transactions rt set status = 'in_batch', batch_id = bid
   where rt.status = 'eligible' and exists (select 1 from public.partner_bank_details b where b.partner_id = rt.partner_id)
     and exists (select 1 from public.partners pp where pp.id = rt.partner_id and pp.status = 'VERIFIED');
  get diagnostics moved = row_count;
  if moved = 0 then raise exception 'No eligible payments with bank details'; end if;
  for pr in select partner_id, sum(amount) as gross from public.reward_transactions where batch_id = bid group by partner_id loop
    avail := pr.gross;
    for a in select * from public.adjustments where partner_id = pr.partner_id and kind = 'recovery' and status = 'Open' and batch_id is null and amount < 0
             order by created_at, id for update loop
      exit when avail <= 0;
      need := -a.amount; take := least(need, avail);
      if take = need then
        update public.adjustments set batch_id = bid where id = a.id;
      else
        update public.adjustments set amount = -(need - take) where id = a.id;
        insert into public.adjustments(partner_id, referral_id, amount, reason, kind, status, created_by, batch_id)
        values (a.partner_id, a.referral_id, -take, a.reason || ' (part applied in ' || no || ')', 'recovery', 'Open', a.created_by, bid);
      end if;
      avail := avail - take;
    end loop;
  end loop;
  perform public.recalc_batch(bid);
  perform public.audit('Prepared payout batch ' || no, 'payout_batch', bid::text, null);
  return bid;
end $$;

create or replace function public.regenerate_referral_code(p_partner uuid) returns text
language plpgsql security definer set search_path = public as $$
declare c text; old text;
begin
  perform public.require_role('marketing');
  select referral_code into old from public.partners where id = p_partner;
  c := public.gen_referral_code();
  update public.partners set referral_code = c where id = p_partner and status = 'VERIFIED';
  perform public.audit('Regenerated referral code from ' || coalesce(old, '(none)') || ' to ' || c, 'partner', p_partner::text, null);
  return c;
end $$;
