-- 015: fixes from the PRD and architecture review
-- 1) duplicate checks honour the duplicate_rule setting (mobile or email)
-- 2) a failed CRM lookup is "unchecked", never silently treated as a new lead
-- 3) flagged claims are held back from LeadSquared until Marketing decides
-- 4) the policy version is fixed when the referral is submitted
-- 5) slab positions are assigned under a per-partner, per-programme lock
-- 6) outstanding recoveries are netted from the next payout batch automatically
-- 7) a suspended partner's rewards stay on hold
-- 8) the audit log cannot be written directly by signed-in users

alter table public.referrals add column if not exists policy_version integer;
alter table public.adjustments add column if not exists batch_id uuid references public.payout_batches(id);
create index if not exists adjustments_batch_idx on public.adjustments (batch_id);
create index if not exists referrals_email_idx on public.referrals (lower(email)) where email is not null;
alter table public.referrals drop constraint if exists referrals_flag_check;
alter table public.referrals add constraint referrals_flag_check check (flag = any (array['existing_lead','related_party','conflict','risk','crm_unchecked']));
alter table public.referrals drop constraint if exists referrals_sync_status_check;
alter table public.referrals add constraint referrals_sync_status_check check (sync_status = any (array['pending','ok','failed','held']));

-- ---- capture_referral: validation, email-aware duplicates, uncertain CRM lookups, held CRM push, fixed policy version
drop function if exists public.capture_referral(text,text,text,text,text,text,text,text,uuid,boolean,boolean);
create or replace function public.capture_referral(p_code text, p_course_code text, p_source text, p_student_name text, p_phone text,
  p_email text default null, p_country text default null, p_level text default null, p_resource uuid default null,
  p_course_link boolean default false, p_in_crm boolean default false, p_crm_unknown boolean default false) returns jsonb
language plpgsql security definer set search_path = public as $$
declare p public.partners; c public.courses; v_phone text := regexp_replace(coalesce(p_phone, ''), '\D', '', 'g');
        v_email text := nullif(lower(trim(coalesce(p_email, ''))), ''); v_rule text; v_resource uuid := p_resource;
        dupe public.referrals; v_flag text; v_camp uuid; r public.referrals; v_days integer;
begin
  if length(trim(coalesce(p_student_name, ''))) < 1 or length(p_student_name) > 120 then
    return jsonb_build_object('credited', false, 'reason', 'invalid', 'error', 'Enter the student’s name.');
  end if;
  if length(v_phone) < 8 or length(v_phone) > 15 then
    return jsonb_build_object('credited', false, 'reason', 'invalid', 'error', 'Enter a valid phone number with the country code.');
  end if;
  if v_email is not null and (length(v_email) > 200 or v_email !~ '^[^@[:space:]]+@[^@[:space:]]+\.[^@[:space:]]+$') then
    return jsonb_build_object('credited', false, 'reason', 'invalid', 'error', 'Check the email address.');
  end if;
  p_country := left(p_country, 60); p_level := left(p_level, 60);
  if v_resource is not null and not exists (select 1 from public.resources where id = v_resource) then v_resource := null; end if;

  perform pg_advisory_xact_lock(hashtext('referral:' || v_phone));
  if v_email is not null then perform pg_advisory_xact_lock(hashtext('referral-email:' || v_email)); end if;

  select * into c from public.courses where code = p_course_code and status = 'Active';
  if c.id is null then return jsonb_build_object('credited', false, 'reason', 'course_not_open'); end if;
  if p_code is not null and p_code <> '' then select * into p from public.partners where referral_code = upper(p_code); end if;
  if p.id is null then return jsonb_build_object('credited', false, 'reason', 'no_partner'); end if;
  if p.phone_normalized = v_phone or (v_email is not null and v_email = p.email) then
    return jsonb_build_object('credited', false, 'reason', 'self_referral', 'error', 'Partners can’t refer themselves.');
  end if;
  if p.event_campaign_id is not null and not exists (select 1 from public.campaigns where id = p.event_campaign_id and status = 'Active') then
    return jsonb_build_object('credited', false, 'reason', 'event_not_active');
  end if;
  if not public.partner_eligible(p.id, c.id) then return jsonb_build_object('credited', false, 'reason', 'partner_not_eligible'); end if;

  select coalesce((select (value #>> '{}')::integer from public.app_settings where key = 'attribution_window_days'), 90) into v_days;
  select coalesce((select value #>> '{}' from public.app_settings where key = 'duplicate_rule'), 'mobile_or_email') into v_rule;

  -- the same partner can never hold the same student twice, however long ago the first referral was
  if exists (select 1 from public.referrals where partner_id = p.id and attribution <> 'rejected' and not cancelled
             and (phone_normalized = v_phone or (v_rule = 'mobile_or_email' and v_email is not null and lower(email) = v_email))) then
    return jsonb_build_object('credited', false, 'reason', 'duplicate_same_partner', 'error', 'This student is already registered through this partner.');
  end if;
  -- another partner's claim inside the attribution window (or after admission) makes this one a conflict
  select * into dupe from public.referrals
   where attribution <> 'rejected' and not cancelled
     and (phone_normalized = v_phone or (v_rule = 'mobile_or_email' and v_email is not null and lower(email) = v_email))
     and (created_at > now() - make_interval(days => v_days) or stage >= 3)
   order by created_at limit 1;
  v_flag := case when dupe.id is not null then 'conflict' when p_crm_unknown then 'crm_unchecked' when p_in_crm then 'existing_lead' end;
  v_camp := coalesce(p.event_campaign_id, public.active_campaign_for(c.id));
  insert into public.referrals(partner_id, course_id, campaign_id, source, via_course_link, via_resource_id, student_name, phone, email, country, current_level,
                               flag, attribution, lsq_lead_id, sync_status, policy_version)
  values (p.id, c.id, v_camp, p_source, p_course_link, v_resource, trim(p_student_name), p_phone, v_email, p_country, p_level,
          v_flag, case when v_flag is null then 'verified' else 'review' end, dupe.lsq_lead_id, case when v_flag is null then 'pending' else 'held' end, public.current_policy_version())
  returning * into r;
  insert into public.referral_stage_events(referral_id, from_stage, to_stage, note) values (r.id, null, 0, 'Captured via ' || p_source);
  return jsonb_build_object('credited', true, 'referral_id', r.id, 'ref_no', r.ref_no, 'flag', v_flag, 'held', v_flag is not null,
    'partner_code', p.referral_code, 'campaign_code', (select code from public.campaigns where id = v_camp),
    'partner_category', (select string_agg(category, ', ') from public.partner_affiliations where partner_id = p.id and status = 'VERIFIED'));
end $$;
revoke execute on function public.capture_referral(text,text,text,text,text,text,text,text,uuid,boolean,boolean,boolean) from public, anon, authenticated;
grant execute on function public.capture_referral(text,text,text,text,text,text,text,text,uuid,boolean,boolean,boolean) to service_role;

-- a CRM lookup that is run later (on retry) can also put a claim on hold
create or replace function public.hold_referral_for_review(p_referral uuid, p_flag text) returns void
language plpgsql security definer set search_path = public as $$
begin
  if p_flag not in ('existing_lead', 'crm_unchecked') then raise exception 'Unknown flag'; end if;
  update public.referrals set flag = coalesce(flag, p_flag), attribution = case when attribution = 'verified' then 'review' else attribution end, sync_status = 'held'
   where id = p_referral and attribution <> 'rejected' and not cancelled;
  insert into public.integration_logs(referral_id, event, ok, message) values (p_referral, 'Lead.Capture held', true, 'Held for attribution review (' || p_flag || '). Not sent to LeadSquared until Marketing decides.');
end $$;
revoke execute on function public.hold_referral_for_review(uuid, text) from public, anon, authenticated;
grant execute on function public.hold_referral_for_review(uuid, text) to service_role;

-- Marketing's decision releases or closes the held CRM push
create or replace function public.review_attribution(p_referral uuid, p_decision text) returns void
language plpgsql security definer set search_path = public as $$
declare r public.referrals;
begin
  perform public.require_role('marketing');
  select * into r from public.referrals where id = p_referral for update;
  if r.attribution <> 'review' then raise exception 'This referral is not under review'; end if;
  if p_decision = 'confirm' then
    update public.referrals set attribution = 'verified', sync_status = case when sync_status = 'held' then 'pending' else sync_status end where id = r.id;
    update public.reward_transactions set status = 'eligible' where referral_id = r.id and status = 'on_hold';
  elsif p_decision = 'reject' then
    update public.referrals set attribution = 'rejected' where id = r.id;
    update public.reward_transactions set status = 'reversed' where referral_id = r.id and status not in ('paid', 'reversed');
  else raise exception 'Unknown decision'; end if;
  perform public.audit('Attribution ' || p_decision, 'referral', r.ref_no, null);
end $$;

-- the retry list tells the server whether a claim has already been reviewed
create or replace function public.referrals_to_sync(p_limit integer default 20, p_referral uuid default null) returns jsonb
language sql stable security definer set search_path = public as $$
  select coalesce(jsonb_agg(jsonb_build_object('referral_id', r.id, 'ref_no', r.ref_no, 'name', r.student_name, 'phone', r.phone, 'email', r.email,
      'country', r.country, 'level', r.current_level, 'course', c.code, 'source', r.source, 'partner_code', p.referral_code, 'flag', r.flag,
      'partner_category', (select string_agg(category, ', ') from public.partner_affiliations a where a.partner_id = p.id and a.status = 'VERIFIED'),
      'campaign_code', camp.code, 'course_link', r.via_course_link, 'resource', r.via_resource_id)), '[]'::jsonb)
  from (select * from public.referrals where sync_status in ('pending', 'failed') and attribution <> 'review' and (p_referral is null or id = p_referral) order by created_at limit p_limit) r
  join public.courses c on c.id = r.course_id join public.partners p on p.id = r.partner_id left join public.campaigns camp on camp.id = r.campaign_id
$$;

-- ---- verify_payment: lock the partner and programme sequence, use the policy version fixed at submission
create or replace function public.verify_payment(p_referral uuid, p_milestone text, p_reference text) returns jsonb
language plpgsql security definer set search_path = public as $$
declare r public.referrals; n integer; s smallint; v integer; v_rate numeric; st text;
begin
  perform public.require_role('finance');
  if coalesce(trim(p_reference), '') = '' then raise exception 'Enter the payment reference'; end if;
  select * into r from public.referrals where id = p_referral for update;
  if r.id is null then raise exception 'Referral not found'; end if;
  perform pg_advisory_xact_lock(hashtext('slab:' || r.partner_id::text || ':' || r.course_id::text));
  if r.cancelled or r.attribution = 'rejected' then raise exception 'This referral is closed'; end if;
  st := case when r.attribution = 'review' then 'on_hold' else 'eligible' end;
  if p_milestone = 'admission_fee' then
    if r.stage <> 3 then raise exception 'The admission must be confirmed first'; end if;
    select count(distinct rt.referral_id) + 1 into n from public.reward_transactions rt join public.referrals x on x.id = rt.referral_id
      where rt.partner_id = r.partner_id and x.course_id = r.course_id and rt.tranche = 1 and not x.cancelled and x.attribution <> 'rejected';
    s := public.slab_for(n);
    v := coalesce(r.policy_version, public.current_policy_version());
    select amount into v_rate from public.incentive_rates where policy_version = v and course_id = r.course_id and slab = s;
    if v_rate is null and v <> public.current_policy_version() then
      v := public.current_policy_version();
      select amount into v_rate from public.incentive_rates where policy_version = v and course_id = r.course_id and slab = s;
    end if;
    if v_rate is null then raise exception 'No approved incentive rate for this course and slab'; end if;
    insert into public.payments(referral_id, milestone, reference, verified_by) values (p_referral, p_milestone, p_reference, auth.uid());
    insert into public.reward_transactions(referral_id, partner_id, tranche, admission_number, slab, rate, amount, policy_version, status) values
      (r.id, r.partner_id, 1, n, s, v_rate, v_rate / 2, v, st),
      (r.id, r.partner_id, 2, n, s, v_rate, v_rate - v_rate / 2, v, 'not_due');
    update public.referrals set stage = 4 where id = r.id;
  elsif p_milestone = 'first_instalment' then
    if r.stage <> 4 then raise exception 'The admission fee must be verified first'; end if;
    insert into public.payments(referral_id, milestone, reference, verified_by) values (p_referral, p_milestone, p_reference, auth.uid());
    update public.reward_transactions set status = st where referral_id = r.id and tranche = 2 and status = 'not_due';
    update public.referrals set stage = 5 where id = r.id;
  else raise exception 'Unknown milestone %', p_milestone; end if;
  insert into public.referral_stage_events(referral_id, from_stage, to_stage, note, actor) values (r.id, r.stage, r.stage + 1, p_milestone || ' ' || p_reference, auth.uid());
  perform public.audit('Verified ' || p_milestone, 'referral', r.ref_no, jsonb_build_object('reference', p_reference));
  return (select jsonb_agg(to_jsonb(t)) from public.reward_transactions t where t.referral_id = r.id);
end $$;

-- ---- payout batches: suspended partners are skipped, open recoveries are netted automatically
create or replace function public.recalc_batch(p_batch uuid) returns void
language sql security definer set search_path = public as $$
  update public.payout_batches b set total = coalesce((select sum(amount) from public.reward_transactions where batch_id = b.id), 0)
                                           + coalesce((select sum(amount) from public.adjustments where batch_id = b.id), 0) where b.id = p_batch
$$;

create or replace function public.prepare_payout_batch() returns uuid
language plpgsql security definer set search_path = public as $$
declare bid uuid; no text; k integer := 1; pr record; a record; avail numeric; need numeric; take numeric;
begin
  perform public.require_role('finance');
  if not exists (select 1 from public.reward_transactions rt join public.partner_bank_details b on b.partner_id = rt.partner_id
                 join public.partners pp on pp.id = rt.partner_id where rt.status = 'eligible' and pp.status = 'VERIFIED') then
    raise exception 'No eligible payments with bank details';
  end if;
  no := 'PB-' || to_char(now(), 'YYYY-MM');
  while exists (select 1 from public.payout_batches where batch_no = no) loop k := k + 1; no := 'PB-' || to_char(now(), 'YYYY-MM') || '-' || k; end loop;
  insert into public.payout_batches(batch_no, prepared_by) values (no, auth.uid()) returning id into bid;
  update public.reward_transactions rt set status = 'in_batch', batch_id = bid
   where rt.status = 'eligible' and exists (select 1 from public.partner_bank_details b where b.partner_id = rt.partner_id)
     and exists (select 1 from public.partners pp where pp.id = rt.partner_id and pp.status = 'VERIFIED');
  -- net each partner's outstanding recoveries against what they are owed in this batch, never below zero
  for pr in select partner_id, sum(amount) as gross from public.reward_transactions where batch_id = bid group by partner_id loop
    avail := pr.gross;
    for a in select * from public.adjustments where partner_id = pr.partner_id and kind = 'recovery' and status = 'Open' and batch_id is null and amount < 0
             order by created_at, id for update loop
      exit when avail <= 0;
      need := -a.amount; take := least(need, avail);
      if take = need then
        update public.adjustments set batch_id = bid where id = a.id;
      else
        update public.adjustments set amount = -(need - take) where id = a.id;
        insert into public.adjustments(partner_id, referral_id, amount, reason, kind, status, created_by, batch_id)
        values (a.partner_id, a.referral_id, -take, a.reason || ' (part applied in ' || no || ')', 'recovery', 'Open', a.created_by, bid);
      end if;
      avail := avail - take;
    end loop;
  end loop;
  perform public.recalc_batch(bid);
  perform public.audit('Prepared payout batch ' || no, 'payout_batch', bid::text, null);
  return bid;
end $$;

create or replace function public.decide_payout_batch(p_batch uuid, p_approve boolean) returns void
language plpgsql security definer set search_path = public as $$
declare b public.payout_batches;
begin
  perform public.require_role('ceo');
  select * into b from public.payout_batches where id = p_batch for update;
  if b.status <> 'pending' then raise exception 'This batch is not waiting for approval'; end if;
  if b.prepared_by = auth.uid() then raise exception 'You can’t approve a batch you prepared'; end if;
  if p_approve then
    update public.payout_batches set status = 'approved', approved_by = auth.uid(), approved_at = now() where id = b.id;
    update public.reward_transactions set status = 'approved' where batch_id = b.id and status = 'in_batch';
  else
    update public.payout_batches set status = 'returned' where id = b.id;
    update public.reward_transactions set status = 'eligible', batch_id = null where batch_id = b.id and status = 'in_batch';
    update public.adjustments set batch_id = null where batch_id = b.id and status = 'Open';
  end if;
  perform public.audit((case when p_approve then 'Approved' else 'Returned' end) || ' payout batch ' || b.batch_no, 'payout_batch', b.id::text, null);
end $$;

create or replace function public.record_payout_transfer(p_batch uuid, p_transfer_ref text, p_proof_path text default null) returns void
language plpgsql security definer set search_path = public as $$
declare b public.payout_batches;
begin
  perform public.require_role('finance');
  select * into b from public.payout_batches where id = p_batch for update;
  if b.status <> 'approved' then raise exception 'Only approved batches can be paid'; end if;
  if coalesce(trim(p_transfer_ref), '') = '' then raise exception 'Enter the bank transfer reference'; end if;
  if exists (select 1 from public.payout_batches where transfer_ref = trim(p_transfer_ref) and id <> b.id) then raise exception 'That transfer reference is already used on another batch'; end if;
  update public.payout_batches set status = 'paid', transfer_ref = trim(p_transfer_ref), proof_path = p_proof_path, paid_at = now() where id = b.id;
  update public.reward_transactions set status = 'paid', paid_at = now() where batch_id = b.id and status = 'approved';
  update public.adjustments set status = 'Settled' where batch_id = b.id and status = 'Open';
  perform public.audit('Recorded transfer ' || trim(p_transfer_ref) || ' for ' || b.batch_no, 'payout_batch', b.id::text, null);
end $$;

create or replace function public.get_payout_bank_details(p_batch uuid)
returns table(partner_name text, account_holder text, account_number text, ifsc text, amount numeric)
language plpgsql security definer set search_path = public as $$
declare b public.payout_batches;
begin
  perform public.require_role('finance');
  select * into b from public.payout_batches where id = p_batch;
  if b.status not in ('approved', 'paid') then raise exception 'Bank details are released only for approved batches'; end if;
  perform public.audit('Downloaded payout sheet for ' || b.batch_no, 'payout_batch', b.id::text, null);
  return query
  select p.full_name, bd.account_holder, extensions.pgp_sym_decrypt(bd.account_number_enc, public._bank_key()), bd.ifsc, t.gross + coalesce(adj.total, 0)
  from (select rt.partner_id, sum(rt.amount) as gross from public.reward_transactions rt where rt.batch_id = b.id group by rt.partner_id) t
  join public.partners p on p.id = t.partner_id
  left join public.partner_bank_details bd on bd.partner_id = t.partner_id
  left join (select a.partner_id, sum(a.amount) as total from public.adjustments a where a.batch_id = b.id group by a.partner_id) adj on adj.partner_id = t.partner_id
  order by p.full_name;
end $$;

-- a cancellation after a batch is prepared also releases that partner's netted recoveries from it
create or replace function public.record_cancellation(p_referral uuid, p_note text default null) returns numeric
language plpgsql security definer set search_path = public as $$
declare r public.referrals; recov numeric; b uuid;
begin
  perform public.require_role('admissions', 'finance');
  select * into r from public.referrals where id = p_referral for update;
  if r.cancelled then return 0; end if;
  update public.referrals set cancelled = true where id = r.id;
  for b in select distinct batch_id from public.reward_transactions where referral_id = r.id and status not in ('paid', 'reversed') and batch_id is not null loop
    update public.reward_transactions set batch_id = null where referral_id = r.id and batch_id = b and status <> 'paid';
    update public.adjustments set batch_id = null where batch_id = b and partner_id = r.partner_id and status = 'Open';
    perform public.recalc_batch(b);
  end loop;
  update public.reward_transactions set status = 'reversed' where referral_id = r.id and status not in ('paid', 'reversed');
  select coalesce(sum(amount), 0) into recov from public.reward_transactions where referral_id = r.id and status = 'paid';
  if recov > 0 then
    insert into public.adjustments(partner_id, referral_id, amount, reason, kind, created_by)
    values (r.partner_id, r.id, -recov, 'Admission cancelled after payout. Recovered automatically from the next payout.', 'recovery', auth.uid());
  end if;
  perform public.audit('Recorded cancellation', 'referral', r.ref_no, jsonb_build_object('recovery', recov, 'note', p_note));
  return recov;
end $$;

-- ---- least privilege: nobody signed in can write the audit log directly, or truncate any table
revoke insert, update, delete on public.audit_logs from anon, authenticated;
revoke truncate, trigger, references on all tables in schema public from anon, authenticated;
