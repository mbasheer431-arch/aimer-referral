-- Automatic partner verification: a partner is VERIFIED as soon as their email is confirmed and (when required)
-- their mobile number is confirmed by a one-time code. No manual review. The category is self-declared at sign-up.
insert into public.app_settings (key, value) values ('require_phone_otp', 'true') on conflict (key) do nothing;

create or replace function public.maybe_verify_partner(p_id uuid) returns void
language plpgsql security definer set search_path = public as $$
declare u record; p public.partners; need boolean;
begin
  select id, email_confirmed_at, phone, phone_confirmed_at into u from auth.users where id = p_id;
  select * into p from public.partners where id = p_id;
  if u.id is null or p.id is null or p.status not in ('PENDING', 'EMAIL_VERIFIED') then return; end if;
  if u.email_confirmed_at is null then return; end if;
  select coalesce((select (value #>> '{}')::boolean from public.app_settings where key = 'require_phone_otp'), true) into need;
  if need and (u.phone_confirmed_at is null or regexp_replace(coalesce(u.phone, ''), '\D', '', 'g') <> p.phone_normalized) then
    update public.partners set status = 'EMAIL_VERIFIED' where id = p_id and status = 'PENDING';
    return;
  end if;
  update public.partners set status = 'VERIFIED' where id = p_id;
  perform public.audit('Partner verified automatically (email' || case when need then ' and mobile' else '' end || ' confirmed)', 'partner', p_id::text, null);
end $$;
revoke execute on function public.maybe_verify_partner(uuid) from public, anon, authenticated;

create or replace function public.handle_new_auth_user() returns trigger
language plpgsql security definer set search_path = public as $$
declare v_cat text := new.raw_user_meta_data->>'category';
begin
  if new.raw_user_meta_data->>'account_type' = 'partner' then
    insert into public.partners (id, full_name, phone, email, country, status)
    values (new.id,
            coalesce(new.raw_user_meta_data->>'full_name', split_part(new.email, '@', 1)),
            coalesce(new.raw_user_meta_data->>'phone', new.phone, ''),
            lower(new.email),
            new.raw_user_meta_data->>'country',
            case when new.email_confirmed_at is not null then 'EMAIL_VERIFIED' else 'PENDING' end)
    on conflict (id) do nothing;
    if v_cat in ('Student', 'Employee', 'Alumni', 'MKC Network', 'Ambassador') then
      insert into public.partner_affiliations (partner_id, category, details, status)
      values (new.id, v_cat, jsonb_build_object('note', nullif(left(coalesce(new.raw_user_meta_data->>'category_note', ''), 120), '')), 'VERIFIED')
      on conflict (partner_id, category) do nothing;
    end if;
    perform public.maybe_verify_partner(new.id);
  end if;
  return new;
end $$;

create or replace function public.handle_auth_user_confirmed() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  if new.email_confirmed_at is not null then
    update public.partners set status = 'EMAIL_VERIFIED' where id = new.id and status = 'PENDING';
  end if;
  perform public.maybe_verify_partner(new.id);
  return new;
end $$;
drop trigger if exists on_auth_user_confirmed on auth.users;
create trigger on_auth_user_confirmed after update of email_confirmed_at, phone_confirmed_at, phone on auth.users for each row execute function public.handle_auth_user_confirmed();

-- Adding a category later (from the profile page) is instant; it never changes the partner's status
create or replace function public.submit_affiliation(p_category text, p_details jsonb) returns text
language plpgsql security definer set search_path = public as $$
begin
  if not exists (select 1 from public.partners where id = auth.uid() and status in ('EMAIL_VERIFIED', 'VERIFIED', 'UNDER_REVIEW')) then
    raise exception 'Your account can’t add a category right now';
  end if;
  if p_category not in ('Student', 'Employee', 'Alumni', 'MKC Network', 'Ambassador') then raise exception 'Choose one of the listed categories'; end if;
  insert into public.partner_affiliations(partner_id, category, details, status)
  values (auth.uid(), p_category, coalesce(p_details, '{}'::jsonb), 'VERIFIED')
  on conflict (partner_id, category) do nothing;
  perform public.audit('Added partner category ' || p_category, 'partner', auth.uid()::text, p_details);
  return 'VERIFIED';
end $$;

create or replace function public.my_verification() returns table(email_ok boolean, phone_ok boolean, phone_required boolean)
language sql stable security definer set search_path = public as $$
  select u.email_confirmed_at is not null,
         u.phone_confirmed_at is not null and regexp_replace(coalesce(u.phone, ''), '\D', '', 'g') = p.phone_normalized,
         coalesce((select (value #>> '{}')::boolean from public.app_settings where key = 'require_phone_otp'), true)
  from auth.users u join public.partners p on p.id = u.id where u.id = auth.uid()
$$;

create or replace function public.public_catalog() returns jsonb
language sql stable security definer set search_path = public as $$
  select jsonb_build_object(
    'show_rates', coalesce((select (value #>> '{}')::boolean from public.app_settings where key = 'public_show_rates'), true),
    'require_phone_otp', coalesce((select (value #>> '{}')::boolean from public.app_settings where key = 'require_phone_otp'), true),
    'courses', coalesce((select jsonb_agg(jsonb_build_object('code', c.code, 'name', c.name, 'short', c.short_description, 'color', c.color,
        'rates', (select jsonb_agg(r.amount order by r.slab) from public.incentive_rates r where r.course_id = c.id and r.policy_version = public.current_policy_version()))
        order by c.created_at) from public.courses c where c.status = 'Active' and c.referral_eligible and public.active_campaign_for(c.id) is not null), '[]'::jsonb))
$$;
