-- AIMER Ambassador Program: hardening, bank encryption, duplicate protection and front-end support

-- ===== 1. Course launch notifications happen once per course =====
alter table public.courses add column if not exists notified_at timestamptz;
update public.courses set notified_at = coalesce(launched_at, now()) where status = 'Active' and notified_at is null;

-- ===== 2. Bank details encrypted with a key held in Supabase Vault =====
do $$ begin
  if not exists (select 1 from vault.secrets where name = 'bank_encryption_key') then
    perform vault.create_secret(encode(extensions.gen_random_bytes(32), 'hex'), 'bank_encryption_key', 'Encrypts partner bank account numbers');
  end if;
end $$;

drop policy if exists "bank: self read" on public.partner_bank_details;
drop policy if exists "bank: self insert" on public.partner_bank_details;
drop policy if exists "bank: self update" on public.partner_bank_details;
alter table public.partner_bank_details drop column if exists account_last4;
alter table public.partner_bank_details drop column if exists account_number;
alter table public.partner_bank_details add column if not exists account_number_enc bytea not null default ''::bytea;
alter table public.partner_bank_details add column if not exists last4 text not null default '';
alter table public.partner_bank_details alter column account_number_enc drop default;
alter table public.partner_bank_details alter column last4 drop default;
revoke all on public.partner_bank_details from anon, authenticated;

create or replace function public._bank_key() returns text
language sql stable security definer set search_path = '' as $$
  select decrypted_secret from vault.decrypted_secrets where name = 'bank_encryption_key' limit 1
$$;

create or replace function public.set_bank_details(p_holder text, p_account text, p_ifsc text) returns void
language plpgsql security definer set search_path = public as $$
declare acct text := regexp_replace(coalesce(p_account, ''), '\D', '', 'g'); ifsc text := upper(trim(coalesce(p_ifsc, '')));
begin
  if not exists (select 1 from public.partners where id = auth.uid()) then raise exception 'Not allowed' using errcode = '42501'; end if;
  if length(trim(coalesce(p_holder, ''))) < 2 then raise exception 'Enter the account holder name'; end if;
  if length(acct) < 6 or length(acct) > 20 then raise exception 'Check the account number'; end if;
  if ifsc !~ '^[A-Z]{4}0[A-Z0-9]{6}$' then raise exception 'Check the IFSC code'; end if;
  insert into public.partner_bank_details(partner_id, account_holder, account_number_enc, last4, ifsc, updated_at)
  values (auth.uid(), trim(p_holder), extensions.pgp_sym_encrypt(acct, public._bank_key()), right(acct, 4), ifsc, now())
  on conflict (partner_id) do update set account_holder = excluded.account_holder, account_number_enc = excluded.account_number_enc,
    last4 = excluded.last4, ifsc = excluded.ifsc, updated_at = now();
  perform public.audit('Partner saved bank details (account ending ' || right(acct, 4) || ')', 'partner', auth.uid()::text, null);
end $$;

create or replace function public.get_my_bank() returns table(account_holder text, last4 text, ifsc text)
language sql stable security definer set search_path = public as $$
  select b.account_holder, b.last4, b.ifsc from public.partner_bank_details b where b.partner_id = auth.uid()
$$;

create or replace function public.admin_bank_summary() returns table(partner_id uuid, last4 text)
language sql stable security definer set search_path = public as $$
  select b.partner_id, case when public.has_role('finance') then b.last4 end
  from public.partner_bank_details b where public.has_role('finance', 'ceo')
$$;

-- Finance only, approved or paid batches: the details needed to make the bank transfers. Every call is audited.
create or replace function public.get_payout_bank_details(p_batch uuid)
returns table(partner_name text, account_holder text, account_number text, ifsc text, amount numeric)
language plpgsql security definer set search_path = public as $$
declare b public.payout_batches;
begin
  perform public.require_role('finance');
  select * into b from public.payout_batches where id = p_batch;
  if b.status not in ('approved', 'paid') then raise exception 'Bank details are released only for approved batches'; end if;
  perform public.audit('Downloaded payout sheet for ' || b.batch_no, 'payout_batch', b.id::text, null);
  return query
  select p.full_name, bd.account_holder, extensions.pgp_sym_decrypt(bd.account_number_enc, public._bank_key()), bd.ifsc, sum(rt.amount)
  from public.reward_transactions rt join public.partners p on p.id = rt.partner_id
  left join public.partner_bank_details bd on bd.partner_id = rt.partner_id
  where rt.batch_id = b.id group by p.full_name, bd.account_holder, bd.account_number_enc, bd.ifsc order by p.full_name;
end $$;

-- ===== 3. Duplicate protection and attribution window =====
create unique index if not exists referrals_one_per_partner_phone on public.referrals (partner_id, phone_normalized) where attribution <> 'rejected' and not cancelled;

create or replace function public.capture_referral(
  p_code text, p_course_code text, p_source text, p_student_name text, p_phone text,
  p_email text default null, p_country text default null, p_level text default null,
  p_resource uuid default null, p_course_link boolean default false, p_in_crm boolean default false)
returns jsonb language plpgsql security definer set search_path = public as $$
declare p public.partners; c public.courses; v_phone text := regexp_replace(p_phone, '\D', '', 'g');
        dupe public.referrals; v_flag text; v_camp uuid; r public.referrals; v_days integer;
begin
  perform pg_advisory_xact_lock(hashtext('referral:' || v_phone));            -- two simultaneous submissions can't both win
  select * into c from public.courses where code = p_course_code and status = 'Active';
  if c.id is null then return jsonb_build_object('credited', false, 'reason', 'course_not_open'); end if;
  if p_code is not null and p_code <> '' then select * into p from public.partners where referral_code = upper(p_code); end if;
  if p.id is null then return jsonb_build_object('credited', false, 'reason', 'no_partner'); end if;
  if p.phone_normalized = v_phone or (p_email is not null and lower(p_email) = p.email) then
    return jsonb_build_object('credited', false, 'reason', 'self_referral', 'error', 'Partners can’t refer themselves.');
  end if;
  if p.event_campaign_id is not null and not exists (select 1 from public.campaigns where id = p.event_campaign_id and status = 'Active') then
    return jsonb_build_object('credited', false, 'reason', 'event_not_active');
  end if;
  if not public.partner_eligible(p.id, c.id) then return jsonb_build_object('credited', false, 'reason', 'partner_not_eligible'); end if;
  select coalesce((select (value #>> '{}')::integer from public.app_settings where key = 'attribution_window_days'), 90) into v_days;
  select * into dupe from public.referrals
   where phone_normalized = v_phone and attribution <> 'rejected' and not cancelled
     and (created_at > now() - make_interval(days => v_days) or stage >= 3)
   order by created_at limit 1;
  if dupe.id is not null and dupe.partner_id = p.id then
    return jsonb_build_object('credited', false, 'reason', 'duplicate_same_partner', 'error', 'This student is already registered through this partner.');
  end if;
  v_flag := case when dupe.id is not null then 'conflict' when p_in_crm then 'existing_lead' end;
  v_camp := coalesce(p.event_campaign_id, public.active_campaign_for(c.id));
  insert into public.referrals(partner_id, course_id, campaign_id, source, via_course_link, via_resource_id, student_name, phone, email, country, current_level, flag, attribution, lsq_lead_id)
  values (p.id, c.id, v_camp, p_source, p_course_link, p_resource, p_student_name, p_phone, nullif(p_email, ''), p_country, p_level, v_flag,
          case when v_flag is null then 'verified' else 'review' end, dupe.lsq_lead_id)
  returning * into r;
  insert into public.referral_stage_events(referral_id, from_stage, to_stage, note) values (r.id, null, 0, 'Captured via ' || p_source);
  return jsonb_build_object('credited', true, 'referral_id', r.id, 'ref_no', r.ref_no, 'flag', v_flag,
    'partner_code', p.referral_code, 'campaign_code', (select code from public.campaigns where id = v_camp),
    'partner_category', (select string_agg(category, ', ') from public.partner_affiliations where partner_id = p.id and status = 'VERIFIED'));
end $$;

-- ===== 4. Course launch and campaign activation notify eligible partners once =====
create or replace function public.maybe_notify_course(p_course uuid) returns integer
language plpgsql security definer set search_path = public as $$
declare c public.courses; n integer := 0;
begin
  select * into c from public.courses where id = p_course for update;
  if c.status = 'Active' and c.notified_at is null and public.active_campaign_for(c.id) is not null then
    n := public.notify_partners('course', 'New course: ' || c.name, coalesce(c.short_description, c.name) || '. Share your course link to start earning on admissions.',
                                jsonb_build_object('view', 'courses', 'course', c.code), c.id);
    update public.courses set notified_at = now() where id = c.id;
  end if;
  return n;
end $$;

create or replace function public.announce_course(p_course uuid) returns integer
language plpgsql security definer set search_path = public as $$
declare n integer;
begin
  perform public.require_role('marketing');
  n := public.maybe_notify_course(p_course);
  if n > 0 then perform public.audit('Course open for referrals; ' || n || ' partners notified', 'course', p_course::text, null); end if;
  return n;
end $$;

create or replace function public.set_course_status(p_course uuid, p_status text) returns integer
language plpgsql security definer set search_path = public as $$
declare c public.courses; n integer := 0;
begin
  perform public.require_role('marketing');
  if p_status not in ('Draft','Active','Inactive','Archived') then raise exception 'Unknown status'; end if;
  select * into c from public.courses where id = p_course for update;
  update public.courses set status = p_status, launched_at = case when p_status = 'Active' then coalesce(launched_at, now()) else launched_at end where id = p_course;
  if p_status = 'Active' then n := public.maybe_notify_course(p_course); end if;
  insert into public.integration_logs(event, ok, message) values ('Programme list', true, 'mx_Programme option ' || p_status || ': ' || c.name);
  perform public.audit('Set course ' || c.name || ' to ' || p_status || ' (' || n || ' partners notified)', 'course', c.code, null);
  return n;
end $$;

create or replace function public.set_campaign_status(p_campaign uuid, p_status text) returns void
language plpgsql security definer set search_path = public as $$
declare c public.campaigns; cc record;
begin
  select * into c from public.campaigns where id = p_campaign for update;
  if c.kind = 'event' then perform public.require_role('marketing','event');
    if p_status = 'Active' and c.organizer_id is null then raise exception 'Register an organizer before activating the event'; end if;
  else perform public.require_role('marketing');
    if p_status not in ('Active','Paused','Closed') or c.status not in ('Approved','Active','Paused') then raise exception 'Programme campaigns go live only after Management approval'; end if;
  end if;
  perform set_config('app.bypass', 'on', true);
  update public.campaigns set status = p_status where id = p_campaign;
  if p_status = 'Active' then for cc in select course_id from public.campaign_courses where campaign_id = p_campaign loop perform public.maybe_notify_course(cc.course_id); end loop; end if;
  perform public.audit('Set campaign ' || c.name || ' to ' || p_status, 'campaign', c.code, null);
end $$;

create or replace function public.partners_before_update() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  if new.status = 'VERIFIED' and new.referral_code is null then
    new.referral_code := public.gen_referral_code();
    new.verified_at := now();
  end if;
  return new;
end $$;

-- ===== 5. Functions the web app calls =====
create or replace function public.create_campaign(p_name text, p_description text, p_terms text, p_start date, p_end date, p_course_codes text[]) returns text
language plpgsql security definer set search_path = public as $$
declare cid uuid; v_code text := 'CMP-' || upper(substr(md5(random()::text || clock_timestamp()::text), 1, 6));
begin
  perform public.require_role('marketing');
  if coalesce(trim(p_name), '') = '' or p_end < p_start or coalesce(array_length(p_course_codes, 1), 0) = 0 then raise exception 'Add a name, valid dates and at least one programme'; end if;
  insert into public.campaigns(code, name, kind, description, terms, start_date, end_date, status, created_by)
  values (v_code, trim(p_name), 'programme', p_description, p_terms, p_start, p_end, 'Draft', auth.uid()) returning id into cid;
  insert into public.campaign_courses(campaign_id, course_id) select cid, k.id from public.courses k where k.code = any(p_course_codes);
  perform public.request_approval('campaign', 'New campaign: ' || trim(p_name), jsonb_build_object('campaign_id', cid));
  return v_code;
end $$;

create or replace function public.rename_course_code(p_course uuid, p_code text) returns void
language plpgsql security definer set search_path = public as $$
begin
  perform public.require_role('superadmin');
  if trim(coalesce(p_code, '')) !~ '^[A-Za-z0-9][A-Za-z0-9 \-]{1,19}$' then raise exception 'Use 2 to 20 letters, numbers, spaces or hyphens'; end if;
  update public.courses set code = trim(p_code) where id = p_course;
  perform public.audit('Renamed course code to ' || trim(p_code), 'course', p_course::text, null);
exception when unique_violation then raise exception 'That course code is already used';
end $$;

create or replace function public.settle_adjustment(p_adjustment uuid) returns void
language plpgsql security definer set search_path = public as $$
begin
  perform public.require_role('finance');
  update public.adjustments set status = 'Settled' where id = p_adjustment;
  perform public.audit('Settled adjustment', 'adjustment', p_adjustment::text, null);
end $$;

create or replace function public.delete_notification(p_id uuid) returns void
language plpgsql security definer set search_path = public as $$
begin
  perform public.require_role('marketing');
  delete from public.notifications where id = p_id;
  perform public.audit('Removed a partner notification', 'notification', p_id::text, null);
end $$;

create or replace function public.staff_names() returns table(user_id uuid, full_name text, role text)
language sql stable security definer set search_path = public as $$
  select a.user_id, a.full_name, a.role from public.admin_users a where public.is_admin()
$$;

create or replace function public.check_signup(p_phone text, p_email text) returns text
language sql stable security definer set search_path = public as $$
  select case when exists (select 1 from public.partners where phone_normalized = regexp_replace(coalesce(p_phone, ''), '\D', '', 'g')) then 'phone_taken'
              when exists (select 1 from public.partners where email = lower(trim(p_email))) or exists (select 1 from public.admin_users where email = lower(trim(p_email))) then 'email_taken'
              else 'ok' end
$$;

create or replace function public.public_catalog() returns jsonb
language sql stable security definer set search_path = public as $$
  select jsonb_build_object(
    'show_rates', coalesce((select (value #>> '{}')::boolean from public.app_settings where key = 'public_show_rates'), true),
    'courses', coalesce((select jsonb_agg(jsonb_build_object('code', c.code, 'name', c.name, 'short', c.short_description, 'color', c.color,
        'rates', (select jsonb_agg(r.amount order by r.slab) from public.incentive_rates r where r.course_id = c.id and r.policy_version = public.current_policy_version()))
        order by c.created_at) from public.courses c where c.status = 'Active' and c.referral_eligible and public.active_campaign_for(c.id) is not null), '[]'::jsonb))
$$;

drop function if exists public.admin_list_referrals();
create function public.admin_list_referrals()
returns table(id uuid, ref_no text, partner_id uuid, partner_name text, course_code text, campaign_code text, source text, via_course_link boolean, via_resource_id uuid,
              student_name text, phone text, stage smallint, attribution text, flag text, cancelled boolean, counsellor text, admission_no text,
              lsq_lead_id text, sync_status text, fee_verified_at timestamptz, created_at timestamptz)
language plpgsql stable security definer set search_path = public as $$
begin
  if not public.has_role('marketing','admissions','finance','ceo','support','event') then raise exception 'Not allowed' using errcode = '42501'; end if;
  return query
  select r.id, r.ref_no, r.partner_id, p.full_name, c.code, camp.code, r.source, r.via_course_link, r.via_resource_id, r.student_name,
         case when public.has_role('admissions','support') then r.phone else left(r.phone, 4) || ' ••• ' || right(r.phone_normalized, 4) end,
         r.stage, r.attribution, r.flag, r.cancelled, r.counsellor, r.admission_no, r.lsq_lead_id, r.sync_status,
         (select pm.verified_at from public.payments pm where pm.referral_id = r.id and pm.milestone = 'admission_fee'), r.created_at
  from public.referrals r join public.partners p on p.id = r.partner_id join public.courses c on c.id = r.course_id left join public.campaigns camp on camp.id = r.campaign_id
  where public.has_role('marketing','admissions','finance','ceo','support') or camp.id = p.event_campaign_id
  order by r.created_at desc;
end $$;

create or replace function public.staff_upload_event_leads(p_campaign_code text, p_rows jsonb) returns jsonb
language plpgsql security definer set search_path = public as $$
declare c public.campaigns; org public.partners; x jsonb; res jsonb; ok integer := 0; skip integer := 0;
begin
  perform public.require_role('marketing','event');
  select * into c from public.campaigns where code = p_campaign_code and kind = 'event';
  if c.id is null or c.organizer_id is null then raise exception 'Choose an event that has an organizer'; end if;
  select * into org from public.partners where id = c.organizer_id;
  for x in select * from jsonb_array_elements(p_rows) loop
    res := public.capture_referral(org.referral_code, x->>'course', 'event', x->>'name', x->>'phone', null, null, null, null, false, false);
    if (res->>'credited')::boolean then ok := ok + 1; else skip := skip + 1; end if;
  end loop;
  perform public.audit('Uploaded ' || ok || ' event leads for ' || c.name, 'campaign', c.code, jsonb_build_object('skipped', skip));
  return jsonb_build_object('ok', ok, 'skipped', skip);
end $$;

-- ===== 6. Service-only helpers for the edge functions =====
create table if not exists public.rate_limits (key text primary key, window_start timestamptz not null default now(), hits integer not null default 0);
alter table public.rate_limits enable row level security;
revoke all on public.rate_limits from anon, authenticated;

create or replace function public.hit_rate_limit(p_key text, p_limit integer, p_seconds integer) returns boolean
language plpgsql security definer set search_path = public as $$
declare h integer;
begin
  insert into public.rate_limits(key, window_start, hits) values (p_key, now(), 1)
  on conflict (key) do update set
    hits = case when public.rate_limits.window_start < now() - make_interval(secs => p_seconds) then 1 else public.rate_limits.hits + 1 end,
    window_start = case when public.rate_limits.window_start < now() - make_interval(secs => p_seconds) then now() else public.rate_limits.window_start end
  returning hits into h;
  return h <= p_limit;
end $$;

create or replace function public.referrals_to_sync(p_limit integer default 20, p_referral uuid default null) returns jsonb
language sql stable security definer set search_path = public as $$
  select coalesce(jsonb_agg(jsonb_build_object('referral_id', r.id, 'ref_no', r.ref_no, 'name', r.student_name, 'phone', r.phone, 'email', r.email,
      'country', r.country, 'level', r.current_level, 'course', c.code, 'source', r.source, 'partner_code', p.referral_code,
      'partner_category', (select string_agg(category, ', ') from public.partner_affiliations a where a.partner_id = p.id and a.status = 'VERIFIED'),
      'campaign_code', camp.code, 'course_link', r.via_course_link, 'resource', r.via_resource_id)), '[]'::jsonb)
  from (select * from public.referrals where sync_status in ('pending','failed') and (p_referral is null or id = p_referral) order by created_at limit p_limit) r
  join public.courses c on c.id = r.course_id join public.partners p on p.id = r.partner_id left join public.campaigns camp on camp.id = r.campaign_id
$$;

-- ===== 7. Function privileges: nothing is callable without signing in, except the three public ones =====
revoke all on all tables in schema public from anon;
revoke all on all sequences in schema public from anon;
revoke execute on all functions in schema public from public, anon;
alter default privileges in schema public revoke execute on functions from public, anon;
alter default privileges in schema public revoke all on tables from anon;
alter default privileges in schema public revoke all on sequences from anon;

grant execute on function public.resolve_referral_code(text) to anon;
grant execute on function public.record_click(text, text, uuid) to anon;
grant execute on function public.public_catalog() to anon;
grant execute on function public.check_signup(text, text) to anon;

-- internal helpers: only other database functions use these
revoke execute on function public.audit(text, text, text, jsonb) from authenticated;
revoke execute on function public.require_role(text[]) from authenticated;
revoke execute on function public.partner_eligible(uuid, uuid) from authenticated;
revoke execute on function public.active_campaign_for(uuid) from authenticated;
revoke execute on function public.current_policy_version() from authenticated;
revoke execute on function public.gen_referral_code() from authenticated;
revoke execute on function public.slab_for(integer) from authenticated;
revoke execute on function public.maybe_notify_course(uuid) from authenticated;
revoke execute on function public._bank_key() from authenticated;
revoke execute on function public.handle_new_auth_user() from authenticated;
revoke execute on function public.handle_auth_user_confirmed() from authenticated;
revoke execute on function public.partners_before_update() from authenticated;
revoke execute on function public.campaigns_guard() from authenticated;
revoke execute on function public.touch_updated_at() from authenticated;
revoke execute on function public.hit_rate_limit(text, integer, integer) from authenticated;
revoke execute on function public.referrals_to_sync(integer, uuid) from authenticated;
grant execute on function public.hit_rate_limit(text, integer, integer) to service_role;
grant execute on function public.referrals_to_sync(integer, uuid) to service_role;
grant execute on function public.capture_referral(text,text,text,text,text,text,text,text,uuid,boolean,boolean) to service_role;
revoke execute on function public.capture_referral(text,text,text,text,text,text,text,text,uuid,boolean,boolean) from authenticated;
