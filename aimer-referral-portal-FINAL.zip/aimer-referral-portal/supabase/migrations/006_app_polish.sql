-- Admin last-login stamp, and Management can see who opened a partner notification
create or replace function public.touch_admin_login() returns void
language sql security definer set search_path = public as $$
  update public.admin_users set last_login_at = now() where user_id = auth.uid()
$$;
revoke execute on function public.touch_admin_login() from public, anon;
grant execute on function public.touch_admin_login() to authenticated;

drop policy if exists "recipients: own or staff" on public.notification_recipients;
create policy "recipients: own or staff" on public.notification_recipients for select using (partner_id = auth.uid() or public.has_role('marketing', 'ceo'));
