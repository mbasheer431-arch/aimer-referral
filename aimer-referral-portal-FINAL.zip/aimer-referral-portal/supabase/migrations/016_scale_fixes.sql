-- 016: made for around 1,000 partners using the portal at the same time.
-- 1) Security rules evaluate the role lookup once per request instead of once per row.
-- 2) Every foreign key gets an index.

do $$
declare r record; q text; w text;
begin
  for r in select schemaname, tablename, policyname, qual, with_check from pg_policies where schemaname = 'public' loop
    q := r.qual; w := r.with_check;
    continue when coalesce(q, '') || coalesce(w, '') !~ '(has_role|is_admin|admin_role|auth\.uid)\(';
    continue when coalesce(q, '') || coalesce(w, '') ~* 'select\s+(public\.)?(has_role|is_admin|admin_role|auth\.uid)';   -- already done
    if q is not null then
      q := regexp_replace(q, '(has_role\(VARIADIC ARRAY\[[^\]]*\]\))', '(select public.\1)', 'g');
      q := regexp_replace(q, '\mis_admin\(\)', '(select public.is_admin())', 'g');
      q := regexp_replace(q, '\madmin_role\(\)', '(select public.admin_role())', 'g');
      q := regexp_replace(q, 'auth\.uid\(\)', '(select auth.uid())', 'g');
    end if;
    if w is not null then
      w := regexp_replace(w, '(has_role\(VARIADIC ARRAY\[[^\]]*\]\))', '(select public.\1)', 'g');
      w := regexp_replace(w, '\mis_admin\(\)', '(select public.is_admin())', 'g');
      w := regexp_replace(w, '\madmin_role\(\)', '(select public.admin_role())', 'g');
      w := regexp_replace(w, 'auth\.uid\(\)', '(select auth.uid())', 'g');
    end if;
    execute format('alter policy %I on %I.%I %s %s', r.policyname, r.schemaname, r.tablename,
                   case when q is not null then 'using (' || q || ')' else '' end,
                   case when w is not null then 'with check (' || w || ')' else '' end);
  end loop;
end $$;

do $$
declare r record;
begin
  for r in
    select c.conrelid::regclass as tbl, c.conname,
           (select string_agg(quote_ident(a.attname), ', ' order by k.ord) from unnest(c.conkey) with ordinality k(attnum, ord)
              join pg_attribute a on a.attrelid = c.conrelid and a.attnum = k.attnum) as cols
    from pg_constraint c
    where c.contype = 'f' and c.connamespace = 'public'::regnamespace
      and not exists (select 1 from pg_index i where i.indrelid = c.conrelid
                      and (string_to_array(i.indkey::text, ' ')::int2[])[1:array_length(c.conkey, 1)] = c.conkey)
  loop
    execute format('create index if not exists %I on %s (%s)', left(r.conname, 55) || '_idx', r.tbl, r.cols);
  end loop;
end $$;
