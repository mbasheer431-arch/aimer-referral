-- 019: instant registration. By default a new partner is created by the server as a verified account, with no confirmation email in the way.
-- Super Admin can switch on "require email confirmation" in Integrations & Settings to use the email link instead.
insert into public.app_settings (key, value) values ('email_confirmation_required', 'false') on conflict (key) do nothing;

create or replace function public.public_catalog() returns jsonb
language sql stable security definer set search_path = public as $$
  select jsonb_build_object(
    'show_rates', coalesce((select (value #>> '{}')::boolean from public.app_settings where key = 'public_show_rates'), true),
    'require_phone_otp', coalesce((select (value #>> '{}')::boolean from public.app_settings where key = 'require_phone_otp'), false),
    'email_confirmation_required', coalesce((select (value #>> '{}')::boolean from public.app_settings where key = 'email_confirmation_required'), false),
    'employee_domains', coalesce((select value from public.app_settings where key = 'employee_email_domains'), '[]'::jsonb),
    'courses', coalesce((select jsonb_agg(jsonb_build_object('code', c.code, 'name', c.name, 'short', c.short_description, 'color', c.color,
        'rates', (select jsonb_agg(r.amount order by r.slab) from public.incentive_rates r where r.course_id = c.id and r.policy_version = public.current_policy_version()))
        order by c.created_at) from public.courses c where c.status = 'Active' and c.referral_eligible and public.active_campaign_for(c.id) is not null), '[]'::jsonb))
$$;
