-- If mobile-code verification is switched off, partners who were only waiting for it are verified straight away.
create or replace function public.verify_pending_partners() returns trigger
language plpgsql security definer set search_path = public as $$
declare r record;
begin
  if new.key = 'require_phone_otp' and (new.value #>> '{}') = 'false' then
    for r in select id from public.partners where status = 'EMAIL_VERIFIED' loop perform public.maybe_verify_partner(r.id); end loop;
  end if;
  return new;
end $$;
revoke execute on function public.verify_pending_partners() from public, anon, authenticated;
drop trigger if exists app_settings_verify_pending on public.app_settings;
create trigger app_settings_verify_pending after insert or update on public.app_settings for each row execute function public.verify_pending_partners();
