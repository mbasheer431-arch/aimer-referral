-- AIMER Ambassador Program: core schema
create extension if not exists pgcrypto with schema extensions;

-- ---------- people ----------
create table public.admin_users (
  user_id uuid primary key references auth.users(id) on delete cascade,
  full_name text not null,
  email text not null unique,
  role text not null check (role in ('superadmin','marketing','admissions','finance','ceo','support','event')),
  status text not null default 'Active' check (status in ('Active','Deactivated')),
  created_at timestamptz not null default now(),
  last_login_at timestamptz
);

create table public.partners (
  id uuid primary key references auth.users(id) on delete cascade,
  full_name text not null,
  phone text not null,
  phone_normalized text generated always as (regexp_replace(phone, '\D', '', 'g')) stored unique,
  email text not null unique,
  country text,
  status text not null default 'EMAIL_VERIFIED'
    check (status in ('PENDING','EMAIL_VERIFIED','UNDER_REVIEW','VERIFIED','REJECTED','SUSPENDED')),
  referral_code text unique,
  event_campaign_id uuid,
  visits integer not null default 0,
  verified_at timestamptz,
  verified_by uuid references auth.users(id),
  created_at timestamptz not null default now()
);

create table public.partner_affiliations (
  id uuid primary key default gen_random_uuid(),
  partner_id uuid not null references public.partners(id) on delete cascade,
  category text not null check (category in ('Student','Employee','Alumni','MKC Network','Ambassador','Event organizer')),
  details jsonb not null default '{}'::jsonb,
  status text not null default 'UNDER_REVIEW' check (status in ('UNDER_REVIEW','VERIFIED','REJECTED')),
  reviewed_by uuid references auth.users(id),
  reviewed_at timestamptz,
  created_at timestamptz not null default now(),
  unique (partner_id, category)
);

create table public.partner_bank_details (
  partner_id uuid primary key references public.partners(id) on delete cascade,
  account_holder text not null,
  account_number text not null,            -- move to Supabase Vault / column encryption before go-live
  account_last4 text generated always as (right(account_number, 4)) stored,
  ifsc text not null check (ifsc ~ '^[A-Z]{4}0[A-Z0-9]{6}$'),
  updated_at timestamptz not null default now()
);

-- ---------- catalogue & campaigns ----------
create table public.courses (
  id uuid primary key default gen_random_uuid(),
  code text not null unique,
  name text not null,
  short_description text,
  description text,
  eligibility text,
  duration text,
  fee numeric(12,2) default 0,
  mode text,
  benefits text[] not null default '{}',
  image_path text,
  brochure_path text,
  landing_url text,
  color text not null default '#008BA5',
  status text not null default 'Draft' check (status in ('Draft','Active','Inactive','Archived')),
  referral_eligible boolean not null default true,
  eligible_categories text[] not null default array['Student','Employee','Alumni','MKC Network','Ambassador','Event organizer'],
  launched_at timestamptz,
  created_by uuid references auth.users(id),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table public.campaigns (
  id uuid primary key default gen_random_uuid(),
  code text not null unique,
  name text not null,
  kind text not null default 'programme' check (kind in ('programme','event')),
  description text,
  terms text,
  location text,
  start_date date not null,
  end_date date not null,
  status text not null default 'Draft' check (status in ('Draft','Pending approval','Approved','Active','Paused','Closed','Rejected')),
  organizer_id uuid references public.partners(id),
  created_by uuid references auth.users(id),
  created_at timestamptz not null default now(),
  check (end_date >= start_date)
);
alter table public.partners add constraint partners_event_fk foreign key (event_campaign_id) references public.campaigns(id);

create table public.campaign_courses (
  campaign_id uuid not null references public.campaigns(id) on delete cascade,
  course_id uuid not null references public.courses(id) on delete cascade,
  primary key (campaign_id, course_id)
);

create table public.policy_versions (
  version integer primary key,
  note text,
  approved_by uuid references auth.users(id),
  approved_at timestamptz not null default now()
);

create table public.incentive_rates (
  policy_version integer not null references public.policy_versions(version),
  course_id uuid not null references public.courses(id) on delete cascade,
  slab smallint not null check (slab between 0 and 3),   -- 0: 1-5, 1: 6-10, 2: 11-15, 3: 16+
  amount numeric(12,2) not null check (amount >= 0),
  primary key (policy_version, course_id, slab)
);

create table public.app_settings (
  key text primary key,
  value jsonb not null,
  updated_at timestamptz not null default now()
);

-- ---------- referrals ----------
create sequence public.referral_no_seq start 1001;

create table public.referrals (
  id uuid primary key default gen_random_uuid(),
  ref_no text not null unique default ('REF-' || lpad(nextval('public.referral_no_seq')::text, 6, '0')),
  partner_id uuid not null references public.partners(id),
  course_id uuid not null references public.courses(id),
  campaign_id uuid references public.campaigns(id),
  source text not null check (source in ('link','code','event')),
  via_course_link boolean not null default false,
  via_resource_id uuid,
  student_name text not null,
  phone text not null,
  phone_normalized text generated always as (regexp_replace(phone, '\D', '', 'g')) stored,
  email text,
  country text,
  current_level text,
  stage smallint not null default 0 check (stage between 0 and 5),  -- 0 Enquiry,1 Contacted,2 Application,3 Admission,4 Fee paid,5 First instalment
  attribution text not null default 'verified' check (attribution in ('verified','review','rejected')),
  flag text check (flag in ('existing_lead','related_party','conflict','risk')),
  cancelled boolean not null default false,
  counsellor text,
  admission_no text unique,
  lsq_lead_id text,
  sync_status text not null default 'pending' check (sync_status in ('pending','ok','failed')),
  sync_attempts integer not null default 0,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index referrals_partner_idx on public.referrals(partner_id);
create index referrals_phone_idx on public.referrals(phone_normalized);

create table public.referral_stage_events (
  id bigint generated always as identity primary key,
  referral_id uuid not null references public.referrals(id) on delete cascade,
  from_stage smallint, to_stage smallint, note text,
  actor uuid references auth.users(id),
  created_at timestamptz not null default now()
);

create table public.referral_clicks (
  id bigint generated always as identity primary key,
  partner_id uuid not null references public.partners(id) on delete cascade,
  course_id uuid references public.courses(id),
  campaign_id uuid references public.campaigns(id),
  resource_id uuid,
  created_at timestamptz not null default now()
);

-- ---------- money ----------
create table public.payments (
  id uuid primary key default gen_random_uuid(),
  referral_id uuid not null references public.referrals(id),
  milestone text not null check (milestone in ('admission_fee','first_instalment')),
  reference text not null,
  verified_by uuid not null references auth.users(id),
  verified_at timestamptz not null default now(),
  unique (referral_id, milestone)
);

create table public.payout_batches (
  id uuid primary key default gen_random_uuid(),
  batch_no text not null unique,
  status text not null default 'pending' check (status in ('pending','approved','paid','returned')),
  total numeric(12,2) not null default 0,
  prepared_by uuid not null references auth.users(id),
  approved_by uuid references auth.users(id),
  approved_at timestamptz,
  transfer_ref text unique,
  proof_path text,
  paid_at timestamptz,
  reconciled boolean not null default false,
  created_at timestamptz not null default now(),
  check (approved_by is null or approved_by <> prepared_by)
);

create table public.reward_transactions (
  id uuid primary key default gen_random_uuid(),
  referral_id uuid not null references public.referrals(id),
  partner_id uuid not null references public.partners(id),
  tranche smallint not null check (tranche in (1,2)),
  admission_number integer not null,
  slab smallint not null,
  rate numeric(12,2) not null,
  amount numeric(12,2) not null,
  policy_version integer not null references public.policy_versions(version),
  status text not null check (status in ('not_due','eligible','on_hold','in_batch','approved','paid','reversed')),
  batch_id uuid references public.payout_batches(id),
  paid_at timestamptz,
  created_at timestamptz not null default now(),
  unique (referral_id, tranche)
);
create index reward_partner_idx on public.reward_transactions(partner_id);

create table public.adjustments (
  id uuid primary key default gen_random_uuid(),
  partner_id uuid not null references public.partners(id),
  referral_id uuid references public.referrals(id),
  amount numeric(12,2) not null,
  reason text not null,
  kind text not null check (kind in ('recovery','manual')),
  status text not null default 'Open' check (status in ('Open','Settled')),
  created_by uuid references auth.users(id),
  created_at timestamptz not null default now()
);

create table public.approvals (
  id uuid primary key default gen_random_uuid(),
  type text not null check (type in ('campaign','policy','attribution','adjustment')),
  summary text not null,
  payload jsonb not null default '{}'::jsonb,
  status text not null default 'Pending' check (status in ('Pending','Approved','Rejected')),
  requested_by uuid not null references auth.users(id),
  decided_by uuid references auth.users(id),
  decided_at timestamptz,
  created_at timestamptz not null default now()
);

-- ---------- resources & notifications ----------
create table public.resources (
  id uuid primary key default gen_random_uuid(),
  type text not null check (type in ('Creative','Poster','Video','Brochure','Testimonial','WhatsApp message','Social caption')),
  title text not null,
  course_id uuid references public.courses(id),        -- null = all programmes
  campaign_id uuid references public.campaigns(id),
  language text not null default 'English',
  file_path text,
  thumb_path text,
  body_text text,
  status text not null default 'Published' check (status in ('Draft','Published','Unpublished')),
  created_by uuid references auth.users(id),
  created_at timestamptz not null default now(),
  check (file_path is not null or body_text is not null)
);
alter table public.referrals add constraint referrals_resource_fk foreign key (via_resource_id) references public.resources(id);
alter table public.referral_clicks add constraint clicks_resource_fk foreign key (resource_id) references public.resources(id);

create table public.resource_events (
  id bigint generated always as identity primary key,
  resource_id uuid not null references public.resources(id) on delete cascade,
  partner_id uuid not null references public.partners(id) on delete cascade,
  action text not null check (action in ('preview','download','share','copy','qr')),
  created_at timestamptz not null default now()
);

create table public.course_events (
  id bigint generated always as identity primary key,
  course_id uuid not null references public.courses(id) on delete cascade,
  partner_id uuid not null references public.partners(id) on delete cascade,
  action text not null check (action in ('view','brochure','share','qr')),
  created_at timestamptz not null default now()
);

create table public.notifications (
  id uuid primary key default gen_random_uuid(),
  kind text not null check (kind in ('course','resource','announcement','system')),
  title text not null,
  body text,
  target jsonb not null default '{}'::jsonb,
  created_by uuid references auth.users(id),
  created_at timestamptz not null default now()
);
create table public.notification_recipients (
  notification_id uuid not null references public.notifications(id) on delete cascade,
  partner_id uuid not null references public.partners(id) on delete cascade,
  read_at timestamptz,
  primary key (notification_id, partner_id)
);

-- ---------- support, audit, integrations ----------
create table public.support_tickets (
  id uuid primary key default gen_random_uuid(),
  ticket_no bigint generated always as identity (start with 1001) unique,
  partner_id uuid not null references public.partners(id) on delete cascade,
  category text not null check (category in ('Registration','Verification','Referral link','Attribution dispute','Payout','Other')),
  subject text not null,
  status text not null default 'Open' check (status in ('Open','In progress','Escalated','Resolved')),
  team text not null default 'Support' check (team in ('Support','Marketing','Finance')),
  created_at timestamptz not null default now()
);
create table public.ticket_messages (
  id bigint generated always as identity primary key,
  ticket_id uuid not null references public.support_tickets(id) on delete cascade,
  author uuid not null references auth.users(id),
  is_staff boolean not null default false,
  body text not null,
  created_at timestamptz not null default now()
);

create table public.audit_logs (
  id bigint generated always as identity primary key,
  actor uuid,
  actor_role text,
  action text not null,
  entity text,
  entity_id text,
  details jsonb,
  created_at timestamptz not null default now()
);

create table public.integration_logs (
  id bigint generated always as identity primary key,
  referral_id uuid references public.referrals(id) on delete set null,
  event text not null,
  ok boolean not null,
  message text,
  payload jsonb,
  created_at timestamptz not null default now()
);
