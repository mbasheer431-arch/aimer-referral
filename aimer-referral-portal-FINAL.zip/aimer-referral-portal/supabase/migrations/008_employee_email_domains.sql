-- Employees whose confirmed login email is on an official AIMER domain are verified at once.
-- The domains live in app_settings ('employee_email_domains') so they can be changed without a deploy.
insert into public.app_settings (key, value) values ('employee_email_domains', '["aimerbusinessschool.com","aimerbusinessschool.in"]')
on conflict (key) do update set value = excluded.value, updated_at = now();

create or replace function public.submit_affiliation(p_category text, p_details jsonb) returns text
language plpgsql security definer set search_path = public as $$
declare v_status text := 'UNDER_REVIEW'; v_email text; v_domains text[];
begin
  if not exists (select 1 from public.partners where id = auth.uid() and status in ('EMAIL_VERIFIED','UNDER_REVIEW','VERIFIED')) then
    raise exception 'Confirm your email before choosing a category';
  end if;
  if p_category = 'Event organizer' then raise exception 'Event organizer accounts are created by the AIMER team'; end if;
  select lower(email) into v_email from auth.users where id = auth.uid() and email_confirmed_at is not null;
  select coalesce(array(select lower(jsonb_array_elements_text(value)) from public.app_settings where key = 'employee_email_domains'), '{}') into v_domains;
  if p_category = 'Employee' and split_part(v_email, '@', 2) = any(v_domains) then v_status := 'VERIFIED'; end if;
  insert into public.partner_affiliations(partner_id, category, details, status)
  values (auth.uid(), p_category, coalesce(p_details, '{}'::jsonb), v_status)
  on conflict (partner_id, category) do nothing;
  update public.partners set status = case when v_status = 'VERIFIED' then 'VERIFIED' when status = 'VERIFIED' then 'VERIFIED' else 'UNDER_REVIEW' end
  where id = auth.uid();
  perform public.audit('Submitted partner category ' || p_category, 'partner', auth.uid()::text, p_details);
  return v_status;
end $$;
