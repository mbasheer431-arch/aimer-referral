-- AIMER Ambassador Program: helpers, triggers, business logic and row-level security

-- ---------- helpers ----------
create or replace function public.admin_role() returns text
language sql stable security definer set search_path = public as $$
  select role from public.admin_users where user_id = auth.uid() and status = 'Active'
$$;

create or replace function public.has_role(variadic roles text[]) returns boolean
language sql stable security definer set search_path = public as $$
  select coalesce(public.admin_role() = 'superadmin' or public.admin_role() = any(roles), false)
$$;

create or replace function public.is_admin() returns boolean
language sql stable security definer set search_path = public as $$
  select public.admin_role() is not null
$$;

create or replace function public.is_verified_partner() returns boolean
language sql stable security definer set search_path = public as $$
  select exists (select 1 from public.partners where id = auth.uid() and status = 'VERIFIED')
$$;

create or replace function public.audit(p_action text, p_entity text default null, p_entity_id text default null, p_details jsonb default null)
returns void language sql security definer set search_path = public as $$
  insert into public.audit_logs(actor, actor_role, action, entity, entity_id, details)
  values (auth.uid(), coalesce(public.admin_role(), case when auth.uid() is null then 'system' else 'partner' end), p_action, p_entity, p_entity_id, p_details)
$$;

create or replace function public.require_role(variadic roles text[]) returns void
language plpgsql stable security definer set search_path = public as $$
begin
  if not public.has_role(variadic roles) then
    raise exception 'Your role is not allowed to do this' using errcode = '42501';
  end if;
end $$;

create or replace function public.gen_referral_code() returns text
language plpgsql volatile set search_path = public as $$
declare alphabet text := 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789'; c text;
begin
  loop
    c := '';
    for i in 1..7 loop c := c || substr(alphabet, 1 + floor(random() * length(alphabet))::int, 1); end loop;
    exit when not exists (select 1 from public.partners where referral_code = c);
  end loop;
  return c;
end $$;

create or replace function public.current_policy_version() returns integer
language sql stable security definer set search_path = public as $$
  select coalesce(max(version), 0) from public.policy_versions
$$;

create or replace function public.slab_for(n integer) returns smallint
language sql immutable set search_path = public as $$ select case when n <= 5 then 0 when n <= 10 then 1 when n <= 15 then 2 else 3 end::smallint $$;

create or replace function public.active_campaign_for(p_course uuid) returns uuid
language sql stable security definer set search_path = public as $$
  select c.id from public.campaigns c join public.campaign_courses cc on cc.campaign_id = c.id
  where cc.course_id = p_course and c.kind = 'programme' and c.status = 'Active' and current_date between c.start_date and c.end_date
  order by (select count(*) from public.campaign_courses x where x.campaign_id = c.id), c.created_at
  limit 1
$$;

create or replace function public.partner_eligible(p_partner uuid, p_course uuid) returns boolean
language sql stable security definer set search_path = public as $$
  select exists (
    select 1 from public.partners p, public.courses c
    where p.id = p_partner and c.id = p_course and p.status = 'VERIFIED'
      and c.status = 'Active' and c.referral_eligible
      and public.active_campaign_for(c.id) is not null
      and exists (select 1 from public.partner_affiliations a where a.partner_id = p.id and a.status = 'VERIFIED' and a.category = any(c.eligible_categories))
  )
$$;

-- ---------- auth integration ----------
-- Partners sign up with Supabase Auth (email + password, email confirmation on).
-- Sign-up metadata: { account_type: 'partner', full_name, phone, country }
create or replace function public.handle_new_auth_user() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  if new.raw_user_meta_data->>'account_type' = 'partner' then
    insert into public.partners (id, full_name, phone, email, country, status)
    values (new.id,
            coalesce(new.raw_user_meta_data->>'full_name', split_part(new.email, '@', 1)),
            coalesce(new.raw_user_meta_data->>'phone', new.phone, ''),
            lower(new.email),
            new.raw_user_meta_data->>'country',
            case when new.email_confirmed_at is not null then 'EMAIL_VERIFIED' else 'PENDING' end)
    on conflict (id) do nothing;
  end if;
  return new;
end $$;
create trigger on_auth_user_created after insert on auth.users for each row execute function public.handle_new_auth_user();

create or replace function public.handle_auth_user_confirmed() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  if new.email_confirmed_at is not null and old.email_confirmed_at is null then
    update public.partners set status = 'EMAIL_VERIFIED' where id = new.id and status = 'PENDING';
  end if;
  return new;
end $$;
create trigger on_auth_user_confirmed after update of email_confirmed_at on auth.users for each row execute function public.handle_auth_user_confirmed();

create or replace function public.partners_before_update() returns trigger
language plpgsql set search_path = public as $$
begin
  if new.status = 'VERIFIED' and new.referral_code is null then
    new.referral_code := public.gen_referral_code();
    new.verified_at := now();
  end if;
  return new;
end $$;
create trigger partners_before_update before update on public.partners for each row execute function public.partners_before_update();

-- campaign status may only change through set_campaign_status / decide_approval
create or replace function public.campaigns_guard() returns trigger
language plpgsql set search_path = public as $$
begin
  if coalesce(current_setting('app.bypass', true), '') <> 'on' then
    if tg_op = 'INSERT' and new.kind = 'programme' and new.status not in ('Draft','Pending approval') then
      raise exception 'New programme campaigns start as Draft or Pending approval';
    elsif tg_op = 'UPDATE' and new.status is distinct from old.status then
      raise exception 'Use set_campaign_status to change a campaign status';
    end if;
  end if;
  return new;
end $$;
create trigger campaigns_guard before insert or update on public.campaigns for each row execute function public.campaigns_guard();

create or replace function public.touch_updated_at() returns trigger language plpgsql set search_path = public as $$ begin new.updated_at := now(); return new; end $$;
create trigger courses_touch before update on public.courses for each row execute function public.touch_updated_at();
create trigger referrals_touch before update on public.referrals for each row execute function public.touch_updated_at();

-- ---------- notifications ----------
create or replace function public.notify_partners(p_kind text, p_title text, p_body text, p_target jsonb, p_course uuid default null)
returns integer language plpgsql security definer set search_path = public as $$
declare nid uuid; n integer;
begin
  insert into public.notifications(kind, title, body, target, created_by) values (p_kind, p_title, p_body, coalesce(p_target, '{}'::jsonb), auth.uid()) returning id into nid;
  insert into public.notification_recipients(notification_id, partner_id)
  select nid, p.id from public.partners p
  where p.status = 'VERIFIED' and (p_course is null or public.partner_eligible(p.id, p_course));
  get diagnostics n = row_count;
  return n;
end $$;

create or replace function public.mark_notifications_read(p_ids uuid[] default null) returns void
language sql security definer set search_path = public as $$
  update public.notification_recipients set read_at = now()
  where partner_id = auth.uid() and read_at is null and (p_ids is null or notification_id = any(p_ids))
$$;

-- ---------- partners ----------
create or replace function public.submit_affiliation(p_category text, p_details jsonb) returns text
language plpgsql security definer set search_path = public as $$
declare v_status text := 'UNDER_REVIEW'; v_email text;
begin
  if not exists (select 1 from public.partners where id = auth.uid() and status in ('EMAIL_VERIFIED','UNDER_REVIEW','VERIFIED')) then
    raise exception 'Confirm your email before choosing a category';
  end if;
  if p_category = 'Event organizer' then raise exception 'Event organizer accounts are created by the AIMER team'; end if;
  select lower(email) into v_email from auth.users where id = auth.uid() and email_confirmed_at is not null;
  -- Employees whose confirmed login email is an official AIMER address are verified at once.
  if p_category = 'Employee' and v_email like '%@aimerbusinessschool.com' then v_status := 'VERIFIED'; end if;
  -- Students: verified here once the LMS lookup (edge function) is connected; until then Marketing reviews.
  insert into public.partner_affiliations(partner_id, category, details, status)
  values (auth.uid(), p_category, coalesce(p_details, '{}'::jsonb), v_status)
  on conflict (partner_id, category) do nothing;
  update public.partners set status = case when v_status = 'VERIFIED' then 'VERIFIED' when status = 'VERIFIED' then 'VERIFIED' else 'UNDER_REVIEW' end
  where id = auth.uid();
  perform public.audit('Submitted partner category ' || p_category, 'partner', auth.uid()::text, p_details);
  return v_status;
end $$;

create or replace function public.review_partner(p_partner uuid, p_decision text, p_note text default null) returns void
language plpgsql security definer set search_path = public as $$
begin
  perform public.require_role('marketing');
  if p_decision = 'verify' then
    update public.partner_affiliations set status = 'VERIFIED', reviewed_by = auth.uid(), reviewed_at = now() where partner_id = p_partner and status = 'UNDER_REVIEW';
    update public.partners set status = 'VERIFIED', verified_by = auth.uid() where id = p_partner;
  elsif p_decision = 'reject' then
    update public.partner_affiliations set status = 'REJECTED', reviewed_by = auth.uid(), reviewed_at = now() where partner_id = p_partner and status = 'UNDER_REVIEW';
    update public.partners set status = 'REJECTED' where id = p_partner and status <> 'VERIFIED';
  elsif p_decision = 'suspend' then update public.partners set status = 'SUSPENDED' where id = p_partner;
  elsif p_decision = 'reinstate' then update public.partners set status = 'VERIFIED' where id = p_partner and status = 'SUSPENDED';
  else raise exception 'Unknown decision %', p_decision; end if;
  perform public.audit('Partner ' || p_decision, 'partner', p_partner::text, jsonb_build_object('note', p_note));
end $$;

create or replace function public.regenerate_referral_code(p_partner uuid) returns text
language plpgsql security definer set search_path = public as $$
declare c text;
begin
  perform public.require_role('marketing');
  c := public.gen_referral_code();
  update public.partners set referral_code = c where id = p_partner and status = 'VERIFIED';
  perform public.audit('Regenerated referral code', 'partner', p_partner::text, null);
  return c;
end $$;

-- Public: what the referral landing page needs to know about a code
create or replace function public.resolve_referral_code(p_code text)
returns table(first_name text, active boolean, event_name text, courses jsonb)
language sql stable security definer set search_path = public as $$
  select split_part(p.full_name, ' ', 1), p.status = 'VERIFIED',
         (select name from public.campaigns where id = p.event_campaign_id),
         coalesce((select jsonb_agg(jsonb_build_object('code', c.code, 'name', c.name, 'short', c.short_description) order by c.name)
                   from public.courses c where public.partner_eligible(p.id, c.id)), '[]'::jsonb)
  from public.partners p where p.referral_code = upper(p_code)
$$;

create or replace function public.record_click(p_code text, p_course_code text default null, p_resource uuid default null) returns void
language plpgsql security definer set search_path = public as $$
declare pid uuid; cid uuid;
begin
  select id into pid from public.partners where referral_code = upper(p_code) and status = 'VERIFIED';
  if pid is null then return; end if;
  select id into cid from public.courses where code = p_course_code;
  insert into public.referral_clicks(partner_id, course_id, resource_id) values (pid, cid, p_resource);
  update public.partners set visits = visits + 1 where id = pid;
end $$;

-- ---------- referral capture (called by the submit-referral edge function only) ----------
create or replace function public.capture_referral(
  p_code text, p_course_code text, p_source text, p_student_name text, p_phone text,
  p_email text default null, p_country text default null, p_level text default null,
  p_resource uuid default null, p_course_link boolean default false, p_in_crm boolean default false)
returns jsonb language plpgsql security definer set search_path = public as $$
declare p public.partners; c public.courses; v_phone text := regexp_replace(p_phone, '\D', '', 'g');
        dupe public.referrals; v_flag text; v_camp uuid; r public.referrals;
begin
  select * into c from public.courses where code = p_course_code and status = 'Active';
  if c.id is null then return jsonb_build_object('credited', false, 'reason', 'course_not_open'); end if;
  if p_code is not null and p_code <> '' then select * into p from public.partners where referral_code = upper(p_code); end if;
  if p.id is null then return jsonb_build_object('credited', false, 'reason', 'no_partner'); end if;
  if p.phone_normalized = v_phone or (p_email is not null and lower(p_email) = p.email) then
    return jsonb_build_object('credited', false, 'reason', 'self_referral', 'error', 'Partners can’t refer themselves.');
  end if;
  if not public.partner_eligible(p.id, c.id) then return jsonb_build_object('credited', false, 'reason', 'partner_not_eligible'); end if;
  select * into dupe from public.referrals where phone_normalized = v_phone and attribution <> 'rejected' order by created_at limit 1;
  if dupe.id is not null and dupe.partner_id = p.id then
    return jsonb_build_object('credited', false, 'reason', 'duplicate_same_partner', 'error', 'This student is already registered through this partner.');
  end if;
  v_flag := case when dupe.id is not null then 'conflict' when p_in_crm then 'existing_lead' end;
  v_camp := coalesce(p.event_campaign_id, public.active_campaign_for(c.id));
  insert into public.referrals(partner_id, course_id, campaign_id, source, via_course_link, via_resource_id, student_name, phone, email, country, current_level, flag, attribution, lsq_lead_id)
  values (p.id, c.id, v_camp, p_source, p_course_link, p_resource, p_student_name, p_phone, nullif(p_email, ''), p_country, p_level, v_flag,
          case when v_flag is null then 'verified' else 'review' end, dupe.lsq_lead_id)
  returning * into r;
  insert into public.referral_stage_events(referral_id, from_stage, to_stage, note) values (r.id, null, 0, 'Captured via ' || p_source);
  return jsonb_build_object('credited', true, 'referral_id', r.id, 'ref_no', r.ref_no, 'flag', v_flag,
    'partner_code', p.referral_code, 'campaign_code', (select code from public.campaigns where id = v_camp),
    'partner_category', (select string_agg(category, ', ') from public.partner_affiliations where partner_id = p.id and status = 'VERIFIED'));
end $$;

create or replace function public.set_sync_result(p_referral uuid, p_ok boolean, p_lsq_id text, p_message text, p_payload jsonb default null) returns void
language plpgsql security definer set search_path = public as $$
begin
  update public.referrals set sync_status = case when p_ok then 'ok' else 'failed' end, sync_attempts = sync_attempts + 1,
         lsq_lead_id = coalesce(p_lsq_id, lsq_lead_id) where id = p_referral;
  insert into public.integration_logs(referral_id, event, ok, message, payload) values (p_referral, 'Lead.Capture', p_ok, p_message, p_payload);
end $$;

-- LeadSquared webhook: stage updates for Contacted / Application (called by the lsq-webhook edge function)
create or replace function public.apply_crm_stage(p_lsq_id text, p_stage smallint, p_note text) returns void
language plpgsql security definer set search_path = public as $$
declare r public.referrals;
begin
  select * into r from public.referrals where lsq_lead_id = p_lsq_id and not cancelled order by created_at limit 1;
  if r.id is null or p_stage <= r.stage or p_stage > 2 then return; end if;   -- admissions & payments stay with AIMER staff
  update public.referrals set stage = p_stage where id = r.id;
  insert into public.referral_stage_events(referral_id, from_stage, to_stage, note) values (r.id, r.stage, p_stage, p_note);
  insert into public.integration_logs(referral_id, event, ok, message) values (r.id, 'Webhook.StageChange', true, p_note);
end $$;

-- Partner-safe view of their own referrals (no contact details)
create or replace function public.get_my_referrals()
returns table(id uuid, ref_no text, student_name text, course_code text, source text, stage smallint, attribution text, cancelled boolean, created_at timestamptz)
language sql stable security definer set search_path = public as $$
  select r.id, r.ref_no, r.student_name, c.code, r.source, r.stage, r.attribution, r.cancelled, r.created_at
  from public.referrals r join public.courses c on c.id = r.course_id
  where r.partner_id = auth.uid() order by r.created_at desc
$$;

-- Admin list with contact details masked for roles that shouldn't see them
create or replace function public.admin_list_referrals()
returns table(id uuid, ref_no text, partner_id uuid, partner_name text, course_code text, source text, student_name text, phone text,
              stage smallint, attribution text, flag text, cancelled boolean, counsellor text, admission_no text, lsq_lead_id text, sync_status text, created_at timestamptz)
language plpgsql stable security definer set search_path = public as $$
begin
  if not public.has_role('marketing','admissions','finance','ceo','support') then raise exception 'Not allowed' using errcode = '42501'; end if;
  return query
  select r.id, r.ref_no, r.partner_id, p.full_name, c.code, r.source, r.student_name,
         case when public.has_role('admissions','support') then r.phone else left(r.phone, 4) || ' ••• ' || right(r.phone_normalized, 4) end,
         r.stage, r.attribution, r.flag, r.cancelled, r.counsellor, r.admission_no, r.lsq_lead_id, r.sync_status, r.created_at
  from public.referrals r join public.partners p on p.id = r.partner_id join public.courses c on c.id = r.course_id
  order by r.created_at desc;
end $$;

-- ---------- admissions ----------
create or replace function public.advance_referral(p_referral uuid, p_admission_no text default null, p_note text default null) returns smallint
language plpgsql security definer set search_path = public as $$
declare r public.referrals;
begin
  perform public.require_role('admissions');
  select * into r from public.referrals where id = p_referral for update;
  if r.cancelled or r.attribution = 'rejected' then raise exception 'This referral is closed'; end if;
  if r.stage >= 3 then raise exception 'Payment milestones are verified by Finance'; end if;
  if r.stage = 2 and coalesce(trim(p_admission_no), '') = '' then raise exception 'Enter the admission number'; end if;
  update public.referrals set stage = stage + 1, admission_no = coalesce(nullif(trim(p_admission_no), ''), admission_no) where id = p_referral;
  insert into public.referral_stage_events(referral_id, from_stage, to_stage, note, actor) values (p_referral, r.stage, r.stage + 1, p_note, auth.uid());
  perform public.audit('Moved referral to stage ' || (r.stage + 1), 'referral', r.ref_no, null);
  return r.stage + 1;
end $$;

create or replace function public.assign_counsellor(p_referral uuid, p_counsellor text) returns void
language plpgsql security definer set search_path = public as $$
begin
  perform public.require_role('admissions');
  update public.referrals set counsellor = nullif(p_counsellor, '') where id = p_referral;
  perform public.audit('Assigned counsellor ' || coalesce(p_counsellor, 'none'), 'referral', p_referral::text, null);
end $$;

-- ---------- reward engine ----------
create or replace function public.verify_payment(p_referral uuid, p_milestone text, p_reference text) returns jsonb
language plpgsql security definer set search_path = public as $$
declare r public.referrals; n integer; s smallint; v integer; v_rate numeric; st text;
begin
  perform public.require_role('finance');
  if coalesce(trim(p_reference), '') = '' then raise exception 'Enter the payment reference'; end if;
  select * into r from public.referrals where id = p_referral for update;
  if r.cancelled or r.attribution = 'rejected' then raise exception 'This referral is closed'; end if;
  st := case when r.attribution = 'review' then 'on_hold' else 'eligible' end;
  if p_milestone = 'admission_fee' then
    if r.stage <> 3 then raise exception 'The admission must be confirmed first'; end if;
    select count(distinct rt.referral_id) + 1 into n from public.reward_transactions rt join public.referrals x on x.id = rt.referral_id
      where rt.partner_id = r.partner_id and x.course_id = r.course_id and rt.tranche = 1 and not x.cancelled and x.attribution <> 'rejected';
    s := public.slab_for(n); v := public.current_policy_version();
    select amount into v_rate from public.incentive_rates where policy_version = v and course_id = r.course_id and slab = s;
    if v_rate is null then raise exception 'No approved incentive rate for this course and slab'; end if;
    insert into public.payments(referral_id, milestone, reference, verified_by) values (p_referral, p_milestone, p_reference, auth.uid());
    insert into public.reward_transactions(referral_id, partner_id, tranche, admission_number, slab, rate, amount, policy_version, status) values
      (r.id, r.partner_id, 1, n, s, v_rate, v_rate / 2, v, st),
      (r.id, r.partner_id, 2, n, s, v_rate, v_rate - v_rate / 2, v, 'not_due');
    update public.referrals set stage = 4 where id = r.id;
  elsif p_milestone = 'first_instalment' then
    if r.stage <> 4 then raise exception 'The admission fee must be verified first'; end if;
    insert into public.payments(referral_id, milestone, reference, verified_by) values (p_referral, p_milestone, p_reference, auth.uid());
    update public.reward_transactions set status = st where referral_id = r.id and tranche = 2 and status = 'not_due';
    update public.referrals set stage = 5 where id = r.id;
  else raise exception 'Unknown milestone %', p_milestone; end if;
  insert into public.referral_stage_events(referral_id, from_stage, to_stage, note, actor) values (r.id, r.stage, r.stage + 1, p_milestone || ' ' || p_reference, auth.uid());
  perform public.audit('Verified ' || p_milestone, 'referral', r.ref_no, jsonb_build_object('reference', p_reference));
  return (select jsonb_agg(to_jsonb(t)) from public.reward_transactions t where t.referral_id = r.id);
end $$;

create or replace function public.recalc_batch(p_batch uuid) returns void language sql security definer set search_path = public as $$
  update public.payout_batches b set total = coalesce((select sum(amount) from public.reward_transactions where batch_id = b.id), 0) where b.id = p_batch
$$;

create or replace function public.record_cancellation(p_referral uuid, p_note text default null) returns numeric
language plpgsql security definer set search_path = public as $$
declare r public.referrals; recov numeric; b uuid;
begin
  perform public.require_role('admissions','finance');
  select * into r from public.referrals where id = p_referral for update;
  if r.cancelled then return 0; end if;
  update public.referrals set cancelled = true where id = r.id;
  for b in select distinct batch_id from public.reward_transactions where referral_id = r.id and status not in ('paid','reversed') and batch_id is not null loop
    update public.reward_transactions set batch_id = null where referral_id = r.id and batch_id = b and status <> 'paid';
    perform public.recalc_batch(b);
  end loop;
  update public.reward_transactions set status = 'reversed' where referral_id = r.id and status not in ('paid','reversed');
  select coalesce(sum(amount), 0) into recov from public.reward_transactions where referral_id = r.id and status = 'paid';
  if recov > 0 then
    insert into public.adjustments(partner_id, referral_id, amount, reason, kind, created_by)
    values (r.partner_id, r.id, -recov, 'Admission cancelled after payout. Recover from a future payout.', 'recovery', auth.uid());
  end if;
  perform public.audit('Recorded cancellation', 'referral', r.ref_no, jsonb_build_object('recovery', recov, 'note', p_note));
  return recov;
end $$;

create or replace function public.review_attribution(p_referral uuid, p_decision text) returns void
language plpgsql security definer set search_path = public as $$
declare r public.referrals;
begin
  perform public.require_role('marketing');
  select * into r from public.referrals where id = p_referral for update;
  if r.attribution <> 'review' then raise exception 'This referral is not under review'; end if;
  if p_decision = 'confirm' then
    update public.referrals set attribution = 'verified' where id = r.id;
    update public.reward_transactions set status = 'eligible' where referral_id = r.id and status = 'on_hold';
  elsif p_decision = 'reject' then
    update public.referrals set attribution = 'rejected' where id = r.id;
    update public.reward_transactions set status = 'reversed' where referral_id = r.id and status not in ('paid','reversed');
  else raise exception 'Unknown decision'; end if;
  perform public.audit('Attribution ' || p_decision, 'referral', r.ref_no, null);
end $$;

-- ---------- approvals ----------
create or replace function public.request_approval(p_type text, p_summary text, p_payload jsonb) returns uuid
language plpgsql security definer set search_path = public as $$
declare aid uuid;
begin
  if p_type in ('campaign','policy','attribution') then perform public.require_role('marketing');
  elsif p_type = 'adjustment' then perform public.require_role('finance');
  else raise exception 'Unknown approval type'; end if;
  if p_type = 'campaign' then
    perform set_config('app.bypass', 'on', true);
    update public.campaigns set status = 'Pending approval' where id = (p_payload->>'campaign_id')::uuid and status in ('Draft','Rejected');
  end if;
  insert into public.approvals(type, summary, payload, requested_by) values (p_type, p_summary, p_payload, auth.uid()) returning id into aid;
  perform public.audit('Requested approval: ' || p_summary, 'approval', aid::text, p_payload);
  return aid;
end $$;

create or replace function public.decide_approval(p_approval uuid, p_approve boolean) returns void
language plpgsql security definer set search_path = public as $$
declare a public.approvals; v integer; k text; arr jsonb; r public.referrals; n integer; s smallint; v_rate numeric;
begin
  perform public.require_role('ceo');
  select * into a from public.approvals where id = p_approval for update;
  if a.status <> 'Pending' then raise exception 'Already decided'; end if;
  if a.requested_by = auth.uid() then raise exception 'You can’t approve your own request'; end if;
  perform set_config('app.bypass', 'on', true);
  if a.type = 'campaign' then
    update public.campaigns set status = case when p_approve then 'Approved' else 'Rejected' end where id = (a.payload->>'campaign_id')::uuid;
  elsif p_approve and a.type = 'policy' then
    v := public.current_policy_version() + 1;
    insert into public.policy_versions(version, note, approved_by) values (v, a.summary, auth.uid());
    insert into public.incentive_rates(policy_version, course_id, slab, amount)
      select v, course_id, slab, amount from public.incentive_rates where policy_version = v - 1;
    for k, arr in select * from jsonb_each(a.payload->'rates') loop   -- { "<course_id>": [a, b, c, d] }
      for i in 0..3 loop
        insert into public.incentive_rates(policy_version, course_id, slab, amount) values (v, k::uuid, i, (arr->>i)::numeric)
        on conflict (policy_version, course_id, slab) do update set amount = excluded.amount;
      end loop;
    end loop;
  elsif p_approve and a.type = 'attribution' then
    select * into r from public.referrals where id = (a.payload->>'referral_id')::uuid for update;
    if exists (select 1 from public.reward_transactions where referral_id = r.id and status = 'paid') then raise exception 'Incentive already paid; use an adjustment instead'; end if;
    update public.referrals set partner_id = (a.payload->>'to_partner')::uuid, attribution = 'verified' where id = r.id;
    if exists (select 1 from public.reward_transactions where referral_id = r.id) then
      select count(distinct rt.referral_id) + 1 into n from public.reward_transactions rt join public.referrals x on x.id = rt.referral_id
        where rt.partner_id = (a.payload->>'to_partner')::uuid and x.course_id = r.course_id and rt.tranche = 1 and not x.cancelled and x.id <> r.id;
      s := public.slab_for(n);
      select amount into v_rate from public.incentive_rates where policy_version = public.current_policy_version() and course_id = r.course_id and slab = s;
      update public.reward_transactions set partner_id = (a.payload->>'to_partner')::uuid, admission_number = n, slab = s, rate = v_rate,
        amount = case when tranche = 1 then v_rate / 2 else v_rate - v_rate / 2 end,
        status = case when status = 'on_hold' then 'eligible' else status end, batch_id = null,
        policy_version = public.current_policy_version()
      where referral_id = r.id;
    end if;
  elsif p_approve and a.type = 'adjustment' then
    insert into public.adjustments(partner_id, amount, reason, kind, created_by)
    values ((a.payload->>'partner_id')::uuid, (a.payload->>'amount')::numeric, a.payload->>'reason', 'manual', a.requested_by);
  end if;
  update public.approvals set status = case when p_approve then 'Approved' else 'Rejected' end, decided_by = auth.uid(), decided_at = now() where id = a.id;
  perform public.audit((case when p_approve then 'Approved ' else 'Rejected ' end) || a.summary, 'approval', a.id::text, null);
end $$;

create or replace function public.set_campaign_status(p_campaign uuid, p_status text) returns void
language plpgsql security definer set search_path = public as $$
declare c public.campaigns;
begin
  select * into c from public.campaigns where id = p_campaign for update;
  if c.kind = 'event' then perform public.require_role('marketing','event');
    if p_status = 'Active' and c.organizer_id is null then raise exception 'Register an organizer before activating the event'; end if;
  else perform public.require_role('marketing');
    if p_status not in ('Active','Paused','Closed') or c.status not in ('Approved','Active','Paused') then raise exception 'Programme campaigns go live only after Management approval'; end if;
  end if;
  perform set_config('app.bypass', 'on', true);
  update public.campaigns set status = p_status where id = p_campaign;
  perform public.audit('Set campaign ' || c.name || ' to ' || p_status, 'campaign', c.code, null);
end $$;

-- ---------- payouts ----------
create or replace function public.prepare_payout_batch() returns uuid
language plpgsql security definer set search_path = public as $$
declare bid uuid; no text; k integer := 1;
begin
  perform public.require_role('finance');
  if not exists (select 1 from public.reward_transactions rt join public.partner_bank_details b on b.partner_id = rt.partner_id where rt.status = 'eligible') then
    raise exception 'No eligible payments with bank details';
  end if;
  no := 'PB-' || to_char(now(), 'YYYY-MM');
  while exists (select 1 from public.payout_batches where batch_no = no) loop k := k + 1; no := 'PB-' || to_char(now(), 'YYYY-MM') || '-' || k; end loop;
  insert into public.payout_batches(batch_no, prepared_by) values (no, auth.uid()) returning id into bid;
  update public.reward_transactions rt set status = 'in_batch', batch_id = bid
  where rt.status = 'eligible' and exists (select 1 from public.partner_bank_details b where b.partner_id = rt.partner_id);
  perform public.recalc_batch(bid);
  perform public.audit('Prepared payout batch ' || no, 'payout_batch', bid::text, null);
  return bid;
end $$;

create or replace function public.decide_payout_batch(p_batch uuid, p_approve boolean) returns void
language plpgsql security definer set search_path = public as $$
declare b public.payout_batches;
begin
  perform public.require_role('ceo');
  select * into b from public.payout_batches where id = p_batch for update;
  if b.status <> 'pending' then raise exception 'This batch is not waiting for approval'; end if;
  if b.prepared_by = auth.uid() then raise exception 'You can’t approve a batch you prepared'; end if;
  if p_approve then
    update public.payout_batches set status = 'approved', approved_by = auth.uid(), approved_at = now() where id = b.id;
    update public.reward_transactions set status = 'approved' where batch_id = b.id and status = 'in_batch';
  else
    update public.payout_batches set status = 'returned' where id = b.id;
    update public.reward_transactions set status = 'eligible', batch_id = null where batch_id = b.id and status = 'in_batch';
  end if;
  perform public.audit((case when p_approve then 'Approved' else 'Returned' end) || ' payout batch ' || b.batch_no, 'payout_batch', b.id::text, null);
end $$;

create or replace function public.record_payout_transfer(p_batch uuid, p_transfer_ref text, p_proof_path text default null) returns void
language plpgsql security definer set search_path = public as $$
declare b public.payout_batches;
begin
  perform public.require_role('finance');
  select * into b from public.payout_batches where id = p_batch for update;
  if b.status <> 'approved' then raise exception 'Only approved batches can be paid'; end if;
  if coalesce(trim(p_transfer_ref), '') = '' then raise exception 'Enter the bank transfer reference'; end if;
  update public.payout_batches set status = 'paid', transfer_ref = trim(p_transfer_ref), proof_path = p_proof_path, paid_at = now() where id = b.id;
  update public.reward_transactions set status = 'paid', paid_at = now() where batch_id = b.id and status = 'approved';
  perform public.audit('Recorded transfer ' || p_transfer_ref || ' for ' || b.batch_no, 'payout_batch', b.id::text, null);
end $$;

create or replace function public.reconcile_payout_batch(p_batch uuid) returns void
language plpgsql security definer set search_path = public as $$
begin
  perform public.require_role('finance');
  update public.payout_batches set reconciled = true where id = p_batch and status = 'paid';
  perform public.audit('Reconciled payout batch', 'payout_batch', p_batch::text, null);
end $$;

-- ---------- catalogue & resources ----------
create or replace function public.set_course_status(p_course uuid, p_status text) returns integer
language plpgsql security definer set search_path = public as $$
declare c public.courses; n integer := 0;
begin
  perform public.require_role('marketing');
  select * into c from public.courses where id = p_course for update;
  update public.courses set status = p_status, launched_at = case when p_status = 'Active' then coalesce(launched_at, now()) else launched_at end where id = p_course;
  if p_status = 'Active' and c.launched_at is null and public.active_campaign_for(c.id) is not null then
    n := public.notify_partners('course', 'New course: ' || c.name, coalesce(c.short_description, c.name) || '. Share your course link to start earning on admissions.',
                                jsonb_build_object('view', 'courses', 'course', c.code), c.id);
  end if;
  insert into public.integration_logs(event, ok, message) values ('Programme list', true, 'mx_Programme option ' || p_status || ': ' || c.name);
  perform public.audit('Set course ' || c.name || ' to ' || p_status || ' (' || n || ' partners notified)', 'course', c.code, null);
  return n;
end $$;

create or replace function public.publish_resource(p_resource uuid, p_notify boolean default true) returns integer
language plpgsql security definer set search_path = public as $$
declare r public.resources; n integer := 0;
begin
  perform public.require_role('marketing');
  update public.resources set status = 'Published' where id = p_resource returning * into r;
  if p_notify then
    n := public.notify_partners('resource', 'New material: ' || r.title, 'A new ' || lower(r.type) || ' is ready to share.', jsonb_build_object('view', 'resources', 'resource', r.id), r.course_id);
  end if;
  perform public.audit('Published material ' || r.title || ' (' || n || ' partners notified)', 'resource', r.id::text, null);
  return n;
end $$;

create or replace function public.track_resource(p_resource uuid, p_action text) returns void
language plpgsql security definer set search_path = public as $$
begin
  if not public.is_verified_partner() then return; end if;
  insert into public.resource_events(resource_id, partner_id, action) values (p_resource, auth.uid(), p_action);
end $$;

create or replace function public.track_course(p_course uuid, p_action text) returns void
language plpgsql security definer set search_path = public as $$
begin
  if not public.is_verified_partner() then return; end if;
  insert into public.course_events(course_id, partner_id, action) values (p_course, auth.uid(), p_action);
end $$;

create or replace function public.post_announcement(p_title text, p_body text) returns integer
language plpgsql security definer set search_path = public as $$
begin
  perform public.require_role('marketing');
  return public.notify_partners('announcement', p_title, p_body, '{}'::jsonb, null);
end $$;

create or replace function public.get_leaderboard()
returns table(rank bigint, display_name text, categories text, admissions bigint, referrals bigint, is_me boolean)
language sql stable security definer set search_path = public as $$
  select row_number() over (order by count(*) filter (where r.stage >= 3 and not r.cancelled) desc, count(r.id) desc),
         split_part(p.full_name, ' ', 1) || coalesce(' ' || left(nullif(split_part(p.full_name, ' ', 2), ''), 1) || '.', ''),
         (select string_agg(category, ', ') from public.partner_affiliations a where a.partner_id = p.id and a.status = 'VERIFIED'),
         count(*) filter (where r.stage >= 3 and not r.cancelled), count(r.id), p.id = auth.uid()
  from public.partners p join public.referrals r on r.partner_id = p.id and r.attribution <> 'rejected'
  where p.status = 'VERIFIED' and public.is_verified_partner()
  group by p.id
$$;

-- ---------- row-level security ----------
do $$ declare t text; begin
  foreach t in array array['admin_users','partners','partner_affiliations','partner_bank_details','courses','campaigns','campaign_courses','policy_versions',
    'incentive_rates','app_settings','referrals','referral_stage_events','referral_clicks','payments','payout_batches','reward_transactions','adjustments',
    'approvals','resources','resource_events','course_events','notifications','notification_recipients','support_tickets','ticket_messages','audit_logs','integration_logs']
  loop execute format('alter table public.%I enable row level security', t); end loop;
end $$;

create policy "admins: own row, super/ceo all" on public.admin_users for select using (user_id = auth.uid() or public.has_role('ceo'));
create policy "admins: superadmin manages" on public.admin_users for all using (public.has_role('superadmin')) with check (public.has_role('superadmin'));

create policy "partners: self or staff" on public.partners for select using (id = auth.uid() or public.is_admin());
create policy "partners: self update" on public.partners for update using (id = auth.uid()) with check (id = auth.uid());

create policy "affiliations: self or staff" on public.partner_affiliations for select using (partner_id = auth.uid() or public.is_admin());

create policy "bank: self read" on public.partner_bank_details for select using (partner_id = auth.uid() or public.has_role('finance'));
create policy "bank: self insert" on public.partner_bank_details for insert with check (partner_id = auth.uid());
create policy "bank: self update" on public.partner_bank_details for update using (partner_id = auth.uid()) with check (partner_id = auth.uid());

create policy "courses: public active, staff all" on public.courses for select using (status = 'Active' or public.is_admin());
create policy "courses: marketing insert" on public.courses for insert with check (public.has_role('marketing'));
create policy "courses: marketing update" on public.courses for update using (public.has_role('marketing')) with check (public.has_role('marketing'));

create policy "campaigns: public active, staff all" on public.campaigns for select using (status = 'Active' or public.is_admin());
create policy "campaigns: marketing or event insert" on public.campaigns for insert with check (public.has_role('marketing') or (kind = 'event' and public.has_role('event')));
create policy "campaigns: marketing or event update" on public.campaigns for update using (public.has_role('marketing') or (kind = 'event' and public.has_role('event')));
create policy "campaign_courses: read" on public.campaign_courses for select using (true);
create policy "campaign_courses: marketing write" on public.campaign_courses for all using (public.has_role('marketing')) with check (public.has_role('marketing'));

create policy "policy: read" on public.policy_versions for select using (true);
create policy "rates: read" on public.incentive_rates for select using (true);
create policy "settings: staff read" on public.app_settings for select using (public.is_admin());
create policy "settings: super write" on public.app_settings for all using (public.has_role('superadmin')) with check (public.has_role('superadmin'));

create policy "referrals: contact-level staff" on public.referrals for select using (public.has_role('admissions','support'));
create policy "stage events: staff" on public.referral_stage_events for select using (public.is_admin());
create policy "clicks: staff" on public.referral_clicks for select using (public.has_role('marketing','ceo'));
create policy "payments: staff" on public.payments for select using (public.has_role('finance','admissions','marketing','ceo'));

create policy "rewards: own or staff" on public.reward_transactions for select using (partner_id = auth.uid() or public.has_role('finance','marketing','ceo'));
create policy "batches: staff or own payouts" on public.payout_batches for select using (public.has_role('finance','ceo')
  or exists (select 1 from public.reward_transactions rt where rt.batch_id = payout_batches.id and rt.partner_id = auth.uid()));
create policy "adjustments: own or staff" on public.adjustments for select using (partner_id = auth.uid() or public.has_role('finance','ceo'));
create policy "approvals: staff" on public.approvals for select using (public.has_role('ceo','marketing','finance'));

create policy "resources: partners see published" on public.resources for select using ((status = 'Published' and public.is_verified_partner()) or public.is_admin());
create policy "resources: marketing write" on public.resources for all using (public.has_role('marketing')) with check (public.has_role('marketing'));
create policy "resource events: staff" on public.resource_events for select using (public.has_role('marketing','ceo'));
create policy "course events: staff" on public.course_events for select using (public.has_role('marketing','ceo'));

create policy "notifications: recipients or staff" on public.notifications for select using (public.is_admin()
  or exists (select 1 from public.notification_recipients nr where nr.notification_id = notifications.id and nr.partner_id = auth.uid()));
create policy "recipients: own or staff" on public.notification_recipients for select using (partner_id = auth.uid() or public.has_role('marketing'));

create policy "tickets: own, support, escalated team" on public.support_tickets for select using (partner_id = auth.uid() or public.has_role('support')
  or (status = 'Escalated' and ((team = 'Marketing' and public.has_role('marketing')) or (team = 'Finance' and public.has_role('finance')))));
create policy "tickets: partner opens" on public.support_tickets for insert with check (partner_id = auth.uid() and status = 'Open' and team = 'Support');
create policy "tickets: staff update" on public.support_tickets for update using (public.has_role('support')
  or (team = 'Marketing' and public.has_role('marketing')) or (team = 'Finance' and public.has_role('finance')));
create policy "messages: visible with ticket" on public.ticket_messages for select using (exists (select 1 from public.support_tickets t where t.id = ticket_id));
create policy "messages: write" on public.ticket_messages for insert with check (author = auth.uid() and (
  (not is_staff and exists (select 1 from public.support_tickets t where t.id = ticket_id and t.partner_id = auth.uid() and t.status <> 'Resolved'))
  or (is_staff and public.has_role('support','marketing','finance'))));

create policy "audit: super/ceo all, teams own" on public.audit_logs for select using (public.has_role('ceo')
  or (public.has_role('marketing','finance') and actor_role = public.admin_role()));
create policy "integration logs: marketing" on public.integration_logs for select using (public.has_role('marketing'));

-- column-level protection: partners may only edit their name and country
revoke update on public.partners from anon, authenticated;
grant update (full_name, country) on public.partners to authenticated;

-- service-only functions
revoke execute on function public.capture_referral(text,text,text,text,text,text,text,text,uuid,boolean,boolean) from public, anon, authenticated;
revoke execute on function public.set_sync_result(uuid,boolean,text,text,jsonb) from public, anon, authenticated;
revoke execute on function public.apply_crm_stage(text,smallint,text) from public, anon, authenticated;
revoke execute on function public.notify_partners(text,text,text,jsonb,uuid) from public, anon, authenticated;
revoke execute on function public.recalc_batch(uuid) from public, anon, authenticated;
grant execute on function public.capture_referral(text,text,text,text,text,text,text,text,uuid,boolean,boolean) to service_role;
grant execute on function public.set_sync_result(uuid,boolean,text,text,jsonb) to service_role;
grant execute on function public.apply_crm_stage(text,smallint,text) to service_role;
