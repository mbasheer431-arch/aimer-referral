-- Storage: course images and brochures (public), marketing resources (verified partners and staff), payment proofs (finance only)
insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types) values
  ('course-media', 'course-media', true, 8388608, array['image/jpeg','image/png','image/webp','application/pdf']),
  ('resources', 'resources', false, 52428800, array['image/jpeg','image/png','image/webp','application/pdf','video/mp4','video/quicktime']),
  ('payment-proofs', 'payment-proofs', false, 10485760, array['image/jpeg','image/png','application/pdf'])
on conflict (id) do update set file_size_limit = excluded.file_size_limit, allowed_mime_types = excluded.allowed_mime_types;

create policy "course-media: marketing uploads" on storage.objects for insert to authenticated with check (bucket_id = 'course-media' and public.has_role('marketing'));
create policy "course-media: marketing updates" on storage.objects for update to authenticated using (bucket_id = 'course-media' and public.has_role('marketing'));
create policy "course-media: marketing deletes" on storage.objects for delete to authenticated using (bucket_id = 'course-media' and public.has_role('marketing'));

create policy "resources: verified partners and staff read" on storage.objects for select to authenticated using (bucket_id = 'resources' and (public.is_verified_partner() or public.is_admin()));
create policy "resources: marketing uploads" on storage.objects for insert to authenticated with check (bucket_id = 'resources' and public.has_role('marketing'));
create policy "resources: marketing updates" on storage.objects for update to authenticated using (bucket_id = 'resources' and public.has_role('marketing'));
create policy "resources: marketing deletes" on storage.objects for delete to authenticated using (bucket_id = 'resources' and public.has_role('marketing'));

create policy "payment-proofs: finance and management read" on storage.objects for select to authenticated using (bucket_id = 'payment-proofs' and public.has_role('finance','ceo'));
create policy "payment-proofs: finance uploads" on storage.objects for insert to authenticated with check (bucket_id = 'payment-proofs' and public.has_role('finance'));
