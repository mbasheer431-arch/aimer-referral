# Launch checklist for referral.aimerbschool.com

Do these in order. Tick each one off.

## 1. Publish the site
- [ ] Create a **private** GitHub repository and push this folder to it.
- [ ] Netlify: Add new site, Import an existing project, GitHub, pick the repository. Leave the build command empty (the publish folder is `site`, set by `netlify.toml`).
- [ ] Netlify, Domain management: add `referral.aimerbschool.com`.
- [ ] DNS for `aimerbschool.com`: add a CNAME named `referral` that points to your Netlify site address (Netlify shows the exact value). Wait until Netlify shows the domain as verified with HTTPS.
- [ ] Open https://referral.aimerbschool.com and check the landing page loads.

## 2. Tell Supabase the final address
- [ ] Authentication, URL Configuration: set **Site URL** to `https://referral.aimerbschool.com`. Under Redirect URLs add `https://referral.aimerbschool.com/**`.
- [ ] Edge Functions, Secrets: set `SITE_URL` to `https://referral.aimerbschool.com` and `ALLOWED_ORIGIN` to `https://referral.aimerbschool.com,https://aimer-portal.netlify.app`. Remove the Netlify address from `ALLOWED_ORIGIN` later if you stop using it.
- [ ] Edge Functions, Secrets: confirm `LSQ_API_HOST`, `LSQ_ACCESS_KEY`, `LSQ_SECRET_KEY` are set. Add `LSQ_WEBHOOK_SECRET` (a long random string) only when you connect LeadSquared stage updates.

## 3. Email (password reset) and sign-in limits
- [ ] Authentication, SMTP Settings: connect a real email sender (Google Workspace SMTP, for example) with a sender on your own domain, such as `noreply@aimerbschool.com`. Sign-up does not need email any more, but **password reset does**.
- [ ] Authentication, Rate Limits: raise the email limit, and the sign-in and token-refresh limits. These are counted per network address, and employees in one office share one.
- [ ] Authentication, Password security: turn on leaked-password protection if your plan allows it.

## 4. Plan and backups
- [ ] Upgrade the Supabase project from Free to **Pro**, with a larger compute size for launch week. Free has the smallest database, no daily backups, and pauses after a week without activity.
- [ ] Copy the bank encryption key (Database, Vault, `bank_encryption_key`) into the company password manager.
- [ ] Set up the nightly backup: see `docs/backup-and-restore.md`. Run it once by hand and check it produces two `.enc` files.

## 5. LeadSquared
- [ ] Integrations & Settings (portal, `/admin`): press **Test connection**. It should say LeadSquared accepted the keys.
- [ ] **Owner:** the mapping sends the owner in the `OwnerId` field with `adharsh.m@aimerbschool.in` as the value. The server looks up that person's LeadSquared user ID from the email and sends the ID. If new leads still show the owner as "System", open the lead's entry in the portal's sync log: a note "owner not set: user not found in LeadSquared" means the email does not match a LeadSquared user exactly (or the API keys cannot list users). Fix it by correcting the email, or paste the user's ID into the Value box. A LeadSquared automation that assigns new leads from this source to Adharsh also works. On an existing lead LeadSquared refuses owner changes; the portal then holds the claim for Marketing instead of retrying.
- [ ] Check that Programme appears where your marketing dashboard reads it. The portal fills "Course Interested in".

## 6. Smoke test (about 10 minutes)
- [ ] Register a partner on https://referral.aimerbschool.com. You should land on the dashboard within a couple of seconds, with no email step.
- [ ] Copy that partner's referral link. It must start with `https://referral.aimerbschool.com/r/`.
- [ ] Open the link in a private window and register a test student with a phone number that is **not** in LeadSquared.
- [ ] Check the lead in LeadSquared: name, phone, course, source fields and notes.
- [ ] Sign in at `/admin`, open Partners and Leads, and check both records are there.
- [ ] Press "Forgot password" on a test account and check the email arrives.
- [ ] Remove the test records, or keep them clearly named as tests.

## 7. Before you invite everyone
- [ ] Management signs off the incentive rates, attribution window and payout rules (section 13 of the requirements document).
- [ ] Replace the placeholder course descriptions and fees, upload brochures, and enter the real counsellors.
- [ ] Invite 10 to 20 people first, run two or three admissions through to a payout batch, then open it to everyone.
