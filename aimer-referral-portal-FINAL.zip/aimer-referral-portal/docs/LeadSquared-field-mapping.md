# LeadSquared field mapping (built from AIMER's "Add lead" form)

Every student registration (a partner's link, a manual referral code, an event list, or the general student form) creates or updates one lead through **Lead.Capture**. The student fills in only: programme, full name, contact mobile with country code, email (optional), country, current level, and a consent tick.

Field names below are **default schema names that I have guessed from your form labels**. LeadSquared's real schema names can differ (open Settings, Leads, Customize fields to see them). Your Super Admin can correct any name, switch fields on or off, and set fixed values in **Integrations & Settings, LeadSquared field mapping**. Changes apply to the next lead, with no redeploy.

## Sent by default

| Your form field | What we put in it | Default schema name | Example |
|---|---|---|---|
| First Name | First word of the student's name | `FirstName` | Muhammed |
| Last Name | The rest of the name, if any | `LastName` | Fayiz K |
| Email | Email, if the student gave one | `EmailAddress` | parent@example.com |
| Phone Number* | Contact mobile with country code, sent as `+` and digits. Also used to find an existing lead | `Phone` | +971504127731 |
| Course Interested in* | The programme chosen | `mx_Course_Interested_in` | HSBIP |
| Lead Stage* | The same value for every lead | `ProspectStage` | New Lead (L0.5) |
| Source Campaign | Campaign code (referral leads only) | `SourceCampaign` | REF-26 |
| Source Medium | How the lead arrived: Tracked link, Manual code or Event list | `SourceMedium` | Tracked link |
| Source Content | The referring partner's code | `SourceContent` | MBX7K92 |
| Notes | One line: "Ambassador referral REF-001042. Partner MBX7K92 (Student). Campaign REF-26. Arrived via Tracked link. Level: Class 11 to 12. Country: United Arab Emirates" | `Notes` | |

## Built in but switched off until you confirm the values
These are dropdowns in LeadSquared. A value that is not in the dropdown can make the lead fail, so they stay off until you give me the exact options.

| Your form field | What we would put in it | Default schema name |
|---|---|---|
| Lead Source | `Referral` for partner leads, `Website` for general enquiries (both editable) | `Source` |
| Country | Full country name, for example United Arab Emirates | `Country` |
| Qualification | The student's current level (Class 10, Class 11 to 12, Undergraduate, Graduate, Working professional) | `mx_Qualification` |
| Owner* | The owner's email address or LeadSquared user ID, the same for every lead. An email is looked up and sent as the user ID | `OwnerId` |
| Lead Origin | A fixed value, for example "Ambassador Referral" | `mx_Lead_Origin` |
| Lead Acquisition method | A fixed value | `mx_Lead_Acquisition_method` |
| (new field you could create) Referral ID | The platform's referral number, for filtering | `mx_Referral_ID` |
| (new field you could create) Partner code | The referring partner's code | `mx_Partner_Code` |

Even while these are off, the level and country are not lost: they are written into Notes.

## Not used
Company, Website, the Do Not boxes, Webinar Campaign, Job Title, the address fields, Stream, Passing Year, Preferred Course, Interest Level, Follow up date, Location, Status and the concern fields, utm_ fields, Distribute Leads, Language, College, and the admissions tracking fields (Exam Link Sent through Lead Qualified). Admissions keeps managing those inside LeadSquared. If you want any of them captured at registration, tell me.

## Already settled (live on the project)
- **Owner\*:** every lead goes to Adharsh, `adharsh.m@aimerbschool.in`. The portal looks up his LeadSquared user ID and sends it in `OwnerId`. `OwnerIdEmailAddress` is read-only in LeadSquared and cannot be set.
- **Lead Source:** `Referral` for partner leads. General website enquiries send no Lead Source, so LeadSquared applies its own default.
- **Course Interested in:** options are exactly UGBIP, PGBIP and HSBIP.

## Decided
- **Phone format:** `+` followed by the digits with the country code, for example `+971504127731`.
- **Qualification:** left off. The student's level is written into Notes instead.
- **Schema names:** the defaults above are used as they are. They have not been checked against LeadSquared yet. If one is wrong, the lead stays in the portal as "waiting for retry" with LeadSquared's error; fix the name in settings and press Retry.

## What I need from you
1. **Owner\*:** is it always one person (your form shows Adharsh), or should LeadSquared distribute leads automatically? If one person, their email address.
2. **Schema names** for Course Interested in, Qualification, Lead Origin and Lead Acquisition method.
3. **Lead Source** dropdown: the exact values, and which one to use for partner referrals and for general website enquiries.
4. **Course Interested in** options: are they exactly UGBIP, PGBIP and HSBIP?
5. **Country** options: full names such as "United Arab Emirates"?
6. **Qualification** options, so I can match our five levels to yours (or change ours).
7. **Lead Origin** and **Lead Acquisition method** values for ambassador leads.
8. **Phone format** your existing leads use (for example `+91-9876543210`, `+919876543210`, or without the country code). This decides whether duplicates are recognised.
9. Anything else to capture at registration: parent name, city, stream, passing year, preferred course.
10. One sample webhook for a stage change, so the early-stage updates can be checked.

## Check in your first test
- Submit one test student and open the lead: check the name, phone format, course, stage and the Source fields.
- Submit the same phone number again: confirm LeadSquared updates the lead instead of creating a second one, and check whether Notes were replaced or added to.
- If a lead fails, it stays saved in the portal as "waiting for retry" with LeadSquared's error message, and nothing is lost.

- If LeadSquared answers that the owner or stage "cannot be updated", it matched an existing lead. The portal then holds the claim for Marketing's review and does not change that lead.
