# Capacity and launch settings

Measured on a test copy of the database with 1,000 partners and about 20,000 referrals (test hardware, not Supabase; sign-in and network not included):

| Scenario | Before migration 016 | After |
| --- | --- | --- |
| One partner reads their reward lines | 6,019 ms | 13 ms |
| 50 partners open their dashboard at once | 77.6 s | 4.3 s |
| 1,000 partners open their dashboard in the same second (19,000 requests) | not finished in 280 s | 29 s, no errors |
| 1,000 employees register at the same moment | not measured | 1.6 s, no errors, 1,000 unique codes |
| 1,000 students registered through links at the same moment | not measured | 2.2 s, no errors |

Logging in (migration 018): the app used to make 23 requests to log a partner in (3 one after another, then 19 together), and the same 19 again on every menu click. It now makes 1 request to log in, and 1 per menu click. The response is about 27 KB instead of 142 KB because the leaderboard shows the top 20 plus the viewer's own position. Temporary links for thumbnails are reused for 50 minutes instead of being requested again on every click. 1,000 partners logging in at the same moment finish in about 13 seconds on test hardware with no errors.

Cause: every row-level security rule ran a role lookup once per row. Migration 016 makes each rule evaluate once per request and indexes all 41 foreign keys. `tests/run3.js` (section 11) fails if either regresses.

Change in the Supabase dashboard before an employee launch:
- Email: a real sender (custom SMTP) and a higher email rate limit. Sign-up no longer needs email (instant registration), but password reset still does. The built-in sender only reaches your own team.
- Authentication, Rate Limits: sign-in, sign-up and token-refresh limits are per IP address. Employees on one office network share one.
- Plan: Pro, with a larger compute size for the launch (Free has the smallest database, no daily backups, and pauses after a week of inactivity).
- Authentication, Password security: leaked-password protection, if your plan allows it.

Next optimisations as volume grows: cache the leaderboard, and replace partners' direct reads of reward lines with a function that filters by partner.
