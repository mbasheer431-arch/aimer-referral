# Backup and restore

## What protects what

| What | How it is protected |
| --- | --- |
| Database (partners, referrals, rewards, payouts, settings, audit log, sign-in accounts) | Supabase daily backups on the **Pro** plan (the Free plan has no automatic backups), plus the nightly encrypted backup in this repository |
| Web app and server functions | This Git repository |
| Bank encryption key | **Not in any backup.** Keep a copy in the company password manager (see below) |
| LeadSquared keys and other function secrets | **Not in any backup.** Keep them in the password manager |
| Uploaded files (brochures, posters, payment proofs) | **Not in database backups.** Keep the originals elsewhere, for example Google Drive |

## Save the bank encryption key now
Bank account numbers are encrypted with a key held in Supabase Vault. A restored database is useless for bank details without the same key.
1. Supabase, Database, Vault.
2. Open the secret named `bank_encryption_key`, reveal the value, and copy it into the company password manager.
3. Do not put it in GitHub, email or chat.

## Nightly encrypted backup (works on every plan)
`.github/workflows/backup.yml` runs every night at 02:00 India time and can also be started by hand. It saves two encrypted files as a GitHub artifact for 30 days: the app's data and the sign-in accounts.

Set up once, under the repository's Settings, Secrets and variables, Actions:
- `SUPABASE_DB_URL`: in Supabase press **Connect**, choose **Session pooler**, copy the connection string and put the database password in it. GitHub's servers need the pooler address. If you forgot the password, reset it under Project Settings, Database.
- `BACKUP_PASSPHRASE`: a long random passphrase. Store it in the password manager. Without it the backups cannot be opened.

Then open the Actions tab, choose **nightly-backup**, and press **Run workflow**. A successful run lists two `.enc` files. GitHub emails the repository owner if a run fails.

The files hold student contact details and encrypted bank numbers, so keep the repository **private**.

To run it from your own computer instead: `DB_URL=... BACKUP_PASSPHRASE=... sh scripts/backup.sh` (needs the PostgreSQL 17 client and openssl).

## Restore into a new project
Do this if the live project is lost or damaged. Before you start, create a new Supabase project and download the latest backup artifact.

1. Decrypt the two files:
   `openssl enc -d -aes-256-cbc -pbkdf2 -iter 200000 -pass env:BACKUP_PASSPHRASE -in public-....dump.enc -out public.dump` and the same for the `auth-` file.
2. In the new project, apply the files in `supabase/migrations/` in order. This creates the structure, rules and sign-up triggers. Skip `004_storage.sql` only if you will create the storage buckets another way.
3. Empty the seed data that step 2 created: truncate every table in the `public` schema and `auth.users` (cascade).
4. Load the data. Switching off triggers during the load keeps it exact:
   `PGOPTIONS="-c session_replication_role=replica" pg_restore --data-only --no-owner -d "$NEW_DB_URL" public.dump`
   then the same command with `auth.dump`.
5. Put the original bank key back: in the SQL editor run
   `select vault.update_secret((select id from vault.secrets where name = 'bank_encryption_key'), 'THE-ORIGINAL-KEY');`
6. Deploy the four server functions, set the function secrets, set the Auth settings (site address, email sender, rate limits), and point `site/config.js` at the new project.

This procedure was tested on a copy of the database: every table, row count and checksum matched, a wrong passphrase was refused, and a new sign-up worked afterwards. Steps 5 and 6 depend on Supabase itself and have not been tried.

## Practise it
Run the restore once before launch, and again every few months, into a spare project. A backup that has never been restored is only a hope.
