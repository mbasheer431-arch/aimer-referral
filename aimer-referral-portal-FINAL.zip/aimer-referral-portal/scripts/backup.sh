#!/bin/sh
# Encrypted backup of the AIMER database.
#   DB_URL             connection string (Supabase: Project, Connect, Session pooler)
#   BACKUP_PASSPHRASE  the passphrase the files are encrypted with. Keep it in the company password manager.
# Usage: sh scripts/backup.sh [output-folder]
# Not included: uploaded files in Supabase Storage, and the bank encryption key (see docs/backup-and-restore.md).
set -eu
: "${DB_URL:?Set DB_URL}"; : "${BACKUP_PASSPHRASE:?Set BACKUP_PASSPHRASE}"
OUT="${1:-backup}"; STAMP="$(date -u +%Y%m%d-%H%M%S)"; mkdir -p "$OUT"

# 1) the app's own data and structure
pg_dump "$DB_URL" --no-owner --no-privileges --format=custom --schema=public --file="$OUT/public-$STAMP.dump"

# 2) sign-in accounts (data only) so partners keep their passwords after a restore
TABLES="--table=auth.users"
if [ "$(psql "$DB_URL" -Atc "select to_regclass('auth.identities') is not null")" = "t" ]; then TABLES="$TABLES --table=auth.identities"; fi
# shellcheck disable=SC2086
pg_dump "$DB_URL" --no-owner --no-privileges --data-only --format=custom $TABLES --file="$OUT/auth-$STAMP.dump"

for f in "$OUT/public-$STAMP.dump" "$OUT/auth-$STAMP.dump"; do
  openssl enc -aes-256-cbc -pbkdf2 -iter 200000 -salt -pass env:BACKUP_PASSPHRASE -in "$f" -out "$f.enc"
  rm -f "$f"
done
ls -l "$OUT"/*"$STAMP"*.enc
