const H=require('./harness.js');
module.exports=async function seed(){
  const {as,q,ids}=H;const U=(id,email,meta,phone)=>q('insert into auth.users(id,email,phone,raw_user_meta_data,email_confirmed_at,phone_confirmed_at) values ($1,$2,$3,$4,now(),$5)',[id,email,phone||null,JSON.stringify(meta),phone?new Date():null]);
  const admins=[['a1','superadmin'],['a2','marketing'],['a3','admissions'],['a4','finance'],['a5','ceo'],['a6','support'],['a7','event']];
  for(const [k,r] of admins){await U(ids[k],`${r}@aimer.test`,{account_type:'admin'});await q('insert into public.admin_users(user_id,full_name,email,role) values ($1,$2,$3,$4)',[ids[k],`${r[0].toUpperCase()+r.slice(1)} Admin`,`${r}@aimer.test`,r])}
  const ps=[['p1','student@x.com','Fathima Nidha','+91 94470 11820'],['p2','emp@aimerbschool.com','Rizwan M','+91 98950 22411'],['p3','alumni@x.com','Hiba Rahman','+966 55 410 2290'],['p4','amb@x.com','Ajmal T','+974 3301 7720'],['p5','org@x.com','Anas Saquafi','+971 50 220 1180'],['p6','new@x.com','Shameem K','+91 81290 33017']];
  const CATG={p1:'Student',p2:'Employee',p3:'Alumni',p4:'Ambassador',p6:'Student'};for(const [k,e,n,ph] of ps)await U(ids[k],e,{account_type:'partner',full_name:n,phone:ph,country:'India',category:CATG[k]},k==='p6'?null:ph.replace(/\D/g,''));
  await as(ids.p1,c=>c.query(`select public.submit_affiliation('Student','{"student_id":"AIM-UG-1"}')`));
  await as(ids.p2,c=>c.query(`select public.submit_affiliation('Employee','{"employee_id":"E7"}')`));
  await as(ids.p3,c=>c.query(`select public.submit_affiliation('Alumni','{"programme":"UGBP","year":"2024"}')`));
  await as(ids.p4,c=>c.query(`select public.submit_affiliation('Ambassador','{"city":"Doha","how":"Parents groups"}')`));
  await as(ids.a2,async c=>{await c.query(`select public.review_partner($1,'verify')`,[ids.p1]);await c.query(`select public.review_partner($1,'verify')`,[ids.p4])});
  await q(`update public.partners set status='UNDER_REVIEW' where id=$1`,[ids.p3]);await q(`update public.partner_affiliations set status='UNDER_REVIEW' where partner_id=$1`,[ids.p3]);
  await q(`select set_config('app.bypass','on',false)`);
  await q(`insert into public.campaigns(code,name,kind,location,start_date,end_date,status,organizer_id,terms) values ('EVT-T','Markaz Dubai Career Day','event','Dubai',current_date,current_date+60,'Active',$1,'Leads attributed to the organizer')`,[ids.p5]);
  await q(`select set_config('app.bypass','',false)`);
  await q(`insert into public.partner_affiliations(partner_id,category,status) values ($1,'Event organizer','VERIFIED')`,[ids.p5]);
  await q(`update public.partners set status='VERIFIED',event_campaign_id=(select id from public.campaigns where code='EVT-T') where id=$1`,[ids.p5]);
  const code=async e=>(await q('select referral_code c from public.partners where email=$1',[e]))[0].c;
  const cap=(c,course,name,phone,src='link',ok=true)=>as(null,async cl=>{const r=(await cl.query('select public.capture_referral($1,$2,$3,$4,$5) as v',[c,course,src,name,phone])).rows[0].v;if(r.credited)await cl.query('select public.set_sync_result($1,$2,$3,$4,null)',[r.referral_id,ok,ok?'LSQ-'+r.ref_no:null,ok?'Lead captured':'LeadSquared API timed out after 3 attempts']);return r},'service_role');
  const c1=await code('student@x.com'),c2=await code('emp@aimerbschool.com'),c4=await code('amb@x.com'),c5=await code('org@x.com');
  for(let i=1;i<=6;i++)await cap(c1,'UGBP','Kid '+i,`+971 50 100 000${i}`);
  await cap(c1,'PGBP','PG Kid','+971 50 100 0100');
  await cap(c2,'UGBP','Emp Lead 1','+91 90000 10001');await cap(c2,'HSBC','Emp Lead 2','+91 90000 10002','code');
  await cap(c4,'UGBP','Amb Lead','+974 55 100 0001');await cap(c4,'UGBP','Amb Dup of Kid1','+971 50 100 0001');
  await cap(c4,'PGBP','Amb Failed','+974 55 100 0000',undefined,false);
  await cap(c5,'UGBP','Event Kid 1','+971 56 200 0001','event');await cap(c5,'HSBC','Event Kid 2','+971 56 200 0002','event');
  const refId=async n=>(await q('select id from public.referrals where student_name=$1',[n]))[0].id;
  await as(ids.a3,async c=>{let n=1;for(const k of ['Kid 1','Kid 2','Kid 3','Kid 4']){const id=await refId(k);await c.query('select public.advance_referral($1)',[id]);await c.query('select public.advance_referral($1)',[id]);await c.query('select public.advance_referral($1,$2)',[id,'AIM/T/00'+n++])}
    await c.query('select public.advance_referral($1)',[await refId('Kid 5')])});
  await as(ids.a4,async c=>{for(const k of ['Kid 1','Kid 2','Kid 3'])await c.query(`select public.verify_payment($1,'admission_fee',$2)`,[await refId(k),'RCP-'+k]);for(const k of ['Kid 1','Kid 2'])await c.query(`select public.verify_payment($1,'first_instalment',$2)`,[await refId(k),'INST-'+k])});
  await as(ids.p1,c=>c.query(`select public.set_bank_details('Fathima Nidha','1234567890','FDRL0001234')`));
  await as(ids.a4,c=>c.query('select public.prepare_payout_batch()'));
  const b1=(await q('select id from public.payout_batches limit 1'))[0].id;
  await as(ids.a5,c=>c.query('select public.decide_payout_batch($1,true)',[b1]));
  await as(ids.a4,c=>c.query(`select public.record_payout_transfer($1,'NEFT-SEED-1')`,[b1]));
  await as(ids.a3,c=>c.query('select public.record_cancellation($1)',[null]).catch(()=>{}));
  await as(ids.a2,async c=>{
    await c.query(`insert into public.courses(code,name,short_description,status,created_by) values ('MBA','MBA','Master of Business Administration','Draft',$1)`,[ids.a2]);
    const r=(await c.query(`insert into public.resources(type,title,course_id,language,body_text,status,created_by) values ('WhatsApp message','Admissions are open',null,'English','Admissions are open at AIMER. Register here:','Draft',$1) returning id`,[ids.a2])).rows[0].id;
    await c.query('select public.publish_resource($1,true)',[r]);
    const r2=(await c.query(`insert into public.resources(type,title,course_id,language,file_path,thumb_path,status,created_by) values ('Poster','UGBP poster',(select id from public.courses where code='UGBP'),'English','poster/1-ugbp.jpg','poster/1-ugbp.jpg','Draft',$1) returning id`,[ids.a2])).rows[0].id;
    await c.query('select public.publish_resource($1,true)',[r2]);
    await c.query(`select public.post_announcement('Payout schedule','Approved batches are transferred within 5 working days.')`);
    await c.query(`select public.create_campaign('Spring Drive','d','t',current_date,current_date+30,array['UGBP'])`)});
  await as(ids.p4,async c=>{const t=(await c.query(`insert into public.support_tickets(partner_id,category,subject,status,team) values ($1,'Payout','When is my first payout?','Open','Support') returning id`,[ids.p4])).rows[0].id;
    await c.query(`insert into public.ticket_messages(ticket_id,author,is_staff,body) values ($1,$2,false,'Do I need bank details?')`,[t,ids.p4])});
  return{c1,c2,c4,c5};
};
