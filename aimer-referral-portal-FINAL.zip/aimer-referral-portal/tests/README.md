# Tests

The real web app (`../site/index.html`) runs in a simulated browser against a local PostgreSQL that has the real migrations applied. Only the network layer (the Supabase client and the server functions) is replaced.

You need Node 18 or newer and a local PostgreSQL where the `postgres` user can log in over 127.0.0.1 (default password `pgtest`, or set `PGHOST`, `PGUSER`, `PGPASSWORD`). The `psql` command must be on your PATH.

    cd tests
    npm install
    npm test

The run creates and drops a database called `app`. It ends with a line like `TOTAL: 252 passed, 0 failed`.

Not covered: real email delivery, LeadSquared, file uploads, and the server functions running on Supabase. Check those by hand after a deploy.
