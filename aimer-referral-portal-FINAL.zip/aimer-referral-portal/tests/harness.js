// Integration harness: runs the real app code (dist/index.html) in jsdom against a local Postgres
// that has the real migrations applied. Only the network layer (supabase-js + edge functions) is replaced.
const {Client,Pool,types}=require('pg');
const {JSDOM,VirtualConsole}=require('jsdom');
const fs=require('fs'),cp=require('child_process'),path=require('path');
types.setTypeParser(1184,v=>v.replace(' ','T').replace(/([+-]\d\d)$/,'$1:00'));types.setTypeParser(1082,v=>v);types.setTypeParser(1700,v=>parseFloat(v));types.setTypeParser(20,v=>Number(v));
const SQL=path.join(__dirname,'..','supabase','migrations')+'/';
const CONN={host:process.env.PGHOST||'127.0.0.1',user:process.env.PGUSER||'postgres',password:process.env.PGPASSWORD||'pgtest'};
const ids={a1:'00000000-0000-0000-0000-0000000000a1',a2:'00000000-0000-0000-0000-0000000000a2',a3:'00000000-0000-0000-0000-0000000000a3',a4:'00000000-0000-0000-0000-0000000000a4',a5:'00000000-0000-0000-0000-0000000000a5',a6:'00000000-0000-0000-0000-0000000000a6',a7:'00000000-0000-0000-0000-0000000000a7',
  p1:'00000000-0000-0000-0000-0000000000b1',p2:'00000000-0000-0000-0000-0000000000b2',p3:'00000000-0000-0000-0000-0000000000b3',p4:'00000000-0000-0000-0000-0000000000b4',p5:'00000000-0000-0000-0000-0000000000b5',p6:'00000000-0000-0000-0000-0000000000b6'};
const ROLE={a1:'superadmin',a2:'marketing',a3:'admissions',a4:'finance',a5:'ceo',a6:'support',a7:'event'};
let handlerMod;const registerHandler=async()=>handlerMod||(handlerMod=await import('data:text/javascript;base64,'+Buffer.from(fs.readFileSync(path.join(__dirname,'..','supabase','functions','register','handler.js'),'utf8')).toString('base64')));
let pool,admin;
async function resetDb(){
  const c=new Client({...CONN,database:'postgres'});await c.connect();await c.query('drop database if exists app');await c.query('create database app');await c.end();
  for(const f of [path.join(__dirname,'stub.sql'),path.join(__dirname,'stub2.sql'),SQL+'001_core_schema.sql',SQL+'002_security_and_logic.sql',SQL+'003_seed.sql',SQL+'005_hardening_and_app_support.sql',SQL+'006_app_polish.sql',SQL+'007_friendly_errors.sql',SQL+'008_employee_email_domains.sql',SQL+'010_auto_verification.sql',SQL+'011_email_only_and_employee_domains.sql',SQL+'012_verify_pending_on_setting_change.sql',SQL+'013_aimerbschool_domains.sql',SQL+'015_review_fixes.sql',SQL+'016_scale_fixes.sql',SQL+'017_conflict_protection.sql',SQL+'018_session_bootstrap.sql',SQL+'019_instant_registration.sql']){
    const r=cp.spawnSync('psql',['-q','-v','ON_ERROR_STOP=1',...(f.includes('003_seed')?['-1']:[]),'-h',CONN.host,'-U',CONN.user,'-d','app','-f',f],{encoding:'utf8',env:{...process.env,PGPASSWORD:CONN.password}});if(r.status!==0)throw new Error('migration failed '+f+'\n'+r.stderr)}
  pool=new Pool({...CONN,database:'app',max:6});admin=await pool.connect();
}
async function as(uid,fn,role){ // run fn(client) as a signed-in user (or anon / service_role)
  const c=await pool.connect();
  try{await c.query('begin');await c.query(`set local role ${role||(uid?'authenticated':'anon')}`);await c.query(`select set_config('request.jwt.claim.sub',$1,true)`,[uid||'']);const r=await fn(c);await c.query('commit');return r}
  catch(e){await c.query('rollback').catch(()=>{});throw e}finally{c.release()}}
const q=(sql,p)=>admin.query(sql,p).then(r=>r.rows);
let colTypes={};
async function colType(table){if(colTypes[table])return colTypes[table];const r=await q(`select column_name,data_type from information_schema.columns where table_schema='public' and table_name=$1`,[table]);colTypes[table]=Object.fromEntries(r.map(x=>[x.column_name,x.data_type]));return colTypes[table]}
const fix=async(table,row)=>{const t=await colType(table),o={};for(const[k,v]of Object.entries(row))o[k]=(t[k]==='jsonb'&&v!==null&&v!==undefined)?JSON.stringify(v):v;return o};
async function fnArgs(name){const r=await q(`select p.proretset, pg_get_function_identity_arguments(p.oid) as args, format_type(p.prorettype,null) as ret from pg_proc p where p.proname=$1 and p.pronamespace='public'::regnamespace order by p.pronargs desc limit 1`,[name]);
  if(!r.length)throw new Error('no function '+name);const types={};r[0].args.split(', ').filter(Boolean).forEach(a=>{const m=a.replace(/^(VARIADIC|IN)\s+/,'').match(/^(\S+)\s+(.+)$/);if(m)types[m[1]]=m[2]});return{set:r[0].proretset,types,ret:r[0].ret}}

function makeDB(state){
  const uid=()=>state.user&&state.user.id||null;
  const D={
    async select(table,o={}){if(!/^[a-z_]+$/.test(table))throw new Error('bad table');const w=[],p=[];for(const[k,v]of Object.entries(o.eq||{})){p.push(v);w.push(`"${k}"=$${p.length}`)}
      for(const[k,v]of Object.entries(o.in||{})){p.push(v);w.push(`"${k}"=any($${p.length})`)}
      const sql=`select ${o.cols||'*'} from public.${table}${w.length?' where '+w.join(' and '):''}${o.order?` order by "${o.order}" ${o.asc===true?'asc':'desc'}`:''} limit ${o.limit||1000}`;
      try{return await as(uid(),c=>c.query(sql,p).then(r=>r.rows))}catch(e){throw new Error(e.message)}},
    async one(table,o={}){const r=await D.select(table,{...o,limit:1});return r[0]||null},
    async rpc(name,args={}){if(name==='public_catalog'&&state.catalogFail)throw new Error(state.catalogFail);const f=await fnArgs(name),keys=Object.keys(args),vals=keys.map(k=>{const v=args[k];return(f.types[k]==='jsonb'&&v!==null&&v!==undefined)?JSON.stringify(v):v});
      const sql=`select * from public.${name}(${keys.map((k,i)=>`${k} => $${i+1}`).join(', ')})`;
      try{const rows=await as(uid(),c=>c.query(sql,vals).then(r=>r.rows));if(f.set)return rows;if(f.ret==='void')return null;const r=rows[0];return r?r[name]:null}catch(e){throw new Error(e.message)}},
    async insert(table,row){const r=await fix(table,row),k=Object.keys(r);try{return await as(uid(),c=>c.query(`insert into public.${table}(${k.map(x=>`"${x}"`).join(',')}) values (${k.map((x,i)=>`$${i+1}`).join(',')}) returning *`,k.map(x=>r[x])).then(x=>x.rows))}catch(e){throw new Error(e.message)}},
    async update(table,patch,eq){const r=await fix(table,patch),k=Object.keys(r),e=Object.keys(eq);try{return await as(uid(),c=>c.query(`update public.${table} set ${k.map((x,i)=>`"${x}"=$${i+1}`).join(',')} where ${e.map((x,i)=>`"${x}"=$${k.length+i+1}`).join(' and ')} returning *`,[...k.map(x=>r[x]),...e.map(x=>eq[x])]).then(x=>x.rows))}catch(er){throw new Error(er.message)}},
    async upsert(table,rows,conflict){for(const row of[].concat(rows)){const r=await fix(table,row),k=Object.keys(r);try{await as(uid(),c=>c.query(`insert into public.${table}(${k.map(x=>`"${x}"`).join(',')}) values (${k.map((x,i)=>`$${i+1}`).join(',')}) on conflict (${conflict}) do update set ${k.filter(x=>x!==conflict).map(x=>`"${x}"=excluded."${x}"`).join(',')}`,k.map(x=>r[x])))}catch(e){throw new Error(e.message)}}return[]},
    async del(table,eq){const e=Object.keys(eq);try{await as(uid(),c=>c.query(`delete from public.${table} where ${e.map((x,i)=>`"${x}"=$${i+1}`).join(' and ')}`,e.map(x=>eq[x])))}catch(er){throw new Error(er.message)}},
    async remove(){},async upload(b,p){state.uploads.push(b+'/'+p);return p},publicUrl(b,p){return p?`https://storage.test/${b}/${p}`:null},
    async signed(b,paths){const o={};paths.forEach(p=>o[p]='https://signed.test/'+p);return o},async signedOne(b,p){return 'https://signed.test/'+p},
    async invoke(fn,body){return edge(state,fn,body)},
    async register(body){if(state.registerDown)return{ok:false,fallback:true};state.registerCalls=(state.registerCalls||0)+1;
      const {register}=await registerHandler();
      const out=await register({...body},{ip:'127.0.0.1',
        rpc:async(fn,args)=>{try{const r=await as(null,c=>c.query(`select public.${fn}(${Object.keys(args).map((_,i)=>'$'+(i+1)).join(',')}) as v`,Object.values(args)),'service_role');return{data:r.rows[0].v,error:null}}catch(e){return{data:null,error:e}}},
        createUser:async u=>{try{await q('insert into auth.users(email,raw_user_meta_data,email_confirmed_at) values ($1,$2,now())',[u.email,JSON.stringify(u.user_metadata)]);state.pw[u.email.toLowerCase()]=u.password;return{error:null}}catch(e){return{error:e}}}});
      if(out.status===200)return{ok:true};if(out.status>=500)return{ok:false,fallback:true};return{ok:false,error:out.body.error}},
    auth:{
      async signIn(email,password){const u=(await q('select id,email from auth.users where lower(email)=$1',[email.toLowerCase()]))[0];
        if(!u||(state.pw[email.toLowerCase()]||'Pass12345')!==password)throw new Error('That email or password isn’t right.');
        const conf=(await q('select email_confirmed_at from auth.users where id=$1',[u.id]))[0];if(!conf.email_confirmed_at)throw new Error('Please confirm your email first. Check your inbox for our message.');
        state.user=u;return{user:u}},
      async signUp(email,password,meta){await q('insert into auth.users(email,raw_user_meta_data,email_confirmed_at) values ($1,$2,$3)',[email,JSON.stringify(meta),state.autoConfirm?new Date():null]);state.pw[email.toLowerCase()]=password;
        const u=(await q('select id,email from auth.users where email=$1',[email]))[0];if(state.autoConfirm)state.user=u;return{session:state.autoConfirm?{}:null,user:u}},
      async updatePhone(phone){if(state.smsDown)throw new Error('SMS provider is not configured');state.pendingPhone=phone;state.codesSent=(state.codesSent||0)+1},
      async verifyPhone(phone,token){if(token!=='123456')throw new Error('Token has expired or is invalid');if(state.pendingPhone!==phone)throw new Error('Token has expired or is invalid');await q('update auth.users set phone=$2, phone_confirmed_at=now() where id=$1',[state.user.id,phone.replace(/\D/g,'')])},
      async resend(){state.resent=(state.resent||0)+1},async signOut(){state.user=null},async user(){return state.user},async sessionUser(){return state.user},async hasSession(){return !!state.user},
      async resetPassword(email){if(state.resetFail)throw new Error(state.resetFail);state.resets.push(email)},async updatePassword(p){if(state.user)state.pw[state.user.email.toLowerCase()]=p;state.pwUpdated=p},onChange(){}
    }};
  const wrap=(o)=>{for(const k of Object.keys(o)){if(typeof o[k]==='function'&&!['publicUrl','onChange'].includes(k)){const f=o[k];o[k]=async(...x)=>{if(!['sessionUser','hasSession','signed'].includes(k))state.reqs=(state.reqs||0)+1; /* sessionUser reads the device; signed links are cached for 50 minutes in the real app (tested separately) */state.inflight++;try{return await f(...x)}finally{state.inflight--}}}else if(o[k]&&typeof o[k]==='object')wrap(o[k])}};wrap(D);
  return D}

async function edge(state,fn,b){
  const uid=state.user&&state.user.id;
  if(fn==='submit-referral'){
    const digits=(b.phone||'').replace(/\D/g,'');if(b.website)return{ok:true};
    if(!b.name||digits.length<8||!b.course)throw new Error('Enter the student’s name, a WhatsApp number with country code, and a programme.');
    const svc=f=>as(null,f,'service_role');
    const ok1=await svc(c=>c.query('select public.hit_rate_limit($1,20,600) as v',['ip:test']).then(r=>r.rows[0].v)),ok2=await svc(c=>c.query('select public.hit_rate_limit($1,3,3600) as v',['phone:'+digits]).then(r=>r.rows[0].v));
    if(!ok1||!ok2)throw new Error('Too many requests. Please wait a few minutes and try again.');
    const cap=await svc(c=>c.query('select public.capture_referral($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12) as v',[b.code||null,b.course,b.source==='code'?'code':'link',b.name,b.phone,b.email||null,b.country||null,b.level||null,/^[0-9a-f-]{36}$/i.test(b.resource||'')?b.resource:null,b.courseLink===true,state.crmHas===true,state.crmDown===true]).then(r=>r.rows[0].v));
    if(cap.error)throw new Error(cap.error);if(cap.reason==='course_not_open')throw new Error('Enquiries for this programme are closed right now.');
    if(cap.reason==='no_partner'&&b.source==='code'&&b.code)throw new Error('We couldn’t find that referral code. Check it, or leave it blank.');
    const ok=!digits.endsWith('0000');state.lsqCalls.push({phone:b.phone,ok});
    if(cap.credited&&cap.held)return{ok:true,credited:true,ref_no:cap.ref_no,flagged:true,held:true,synced:false};
    if(cap.credited)await svc(c=>c.query('select public.set_sync_result($1,$2,$3,$4,null)',[cap.referral_id,ok,ok?'LSQ-'+Math.random().toString(36).slice(2,8):null,ok?'Lead captured':'LeadSquared keys are not configured yet']));
    return{ok:true,credited:!!cap.credited,ref_no:cap.ref_no||null,flagged:!!cap.flag,synced:ok}}
  const role=uid?(await as(uid,c=>c.query('select public.admin_role() as r').then(r=>r.rows[0].r))):null;
  if(fn==='lsq-admin'){if(!role)throw new Error('Sign in as an admin');
    if(b.action==='status')return{configured:false,host:null,keyLast4:null,webhookSecret:false};
    if(b.action==='test')return{ok:false,message:'LeadSquared keys are not configured yet. Add them as function secrets.'};
    if(b.action==='sync'){const items=await as(null,c=>c.query('select public.referrals_to_sync(25,$1) as v',[b.referral_id||null]).then(r=>r.rows[0].v),'service_role');
      for(const it of items){if(!it.flag&&(state.crmHas===true||state.crmDown===true)){await as(null,c=>c.query('select public.hold_referral_for_review($1,$2)',[it.referral_id,state.crmDown?'crm_unchecked':'existing_lead']),'service_role');continue}
        await as(null,c=>c.query('select public.set_sync_result($1,true,$2,$3,null)',[it.referral_id,'LSQ-'+it.ref_no,'Lead captured']),'service_role')}return{ok:true,synced:items.length,failed:0,message:'Synced'}}}
  if(fn==='admin-partners'){if(!role)throw new Error('Sign in as an admin');
    if(b.action==='invite_admin'){if(role!=='superadmin')throw new Error('Only a Super Admin can create admin accounts');const u=(await q('insert into auth.users(email,raw_user_meta_data) values ($1,$2) returning id',[b.email.toLowerCase(),JSON.stringify({account_type:'admin'})]))[0];await q('insert into public.admin_users(user_id,full_name,email,role) values ($1,$2,$3,$4)',[u.id,b.full_name,b.email.toLowerCase(),b.role]);return{ok:true}}
    if(!['superadmin','marketing','event'].includes(role))throw new Error('Your role can’t do this');
    if(b.action==='organizer'){const camp=(await q('select * from public.campaigns where code=$1',[b.campaign_code]))[0];if(!camp||camp.kind!=='event')throw new Error('Choose an event');if(camp.organizer_id)throw new Error('This event already has an organizer');
      const u=(await q('insert into auth.users(email,raw_user_meta_data) values ($1,$2) returning id',[b.email.toLowerCase(),JSON.stringify({account_type:'partner',full_name:b.name,phone:b.phone})]))[0];
      await q(`insert into public.partner_affiliations(partner_id,category,status) values ($1,'Event organizer','VERIFIED')`,[u.id]);await q(`update public.partners set status='VERIFIED',event_campaign_id=$2 where id=$1`,[u.id,camp.id]);await q('update public.campaigns set organizer_id=$2 where id=$1',[camp.id,u.id]);return{ok:true}}
    if(b.action==='import'){let n=0;const sk=[];for(const r of b.rows){if(!r.name||!r.email||!r.category){sk.push(r.name+': invalid');continue}
      const u=(await q('insert into auth.users(email,raw_user_meta_data) values ($1,$2) returning id',[r.email.toLowerCase(),JSON.stringify({account_type:'partner',full_name:r.name,phone:r.phone})]))[0];const tr=['Employee','MKC Network'].includes(r.category);
      await q(`insert into public.partner_affiliations(partner_id,category,status) values ($1,$2,$3)`,[u.id,r.category,tr?'VERIFIED':'UNDER_REVIEW']);await q(`update public.partners set status=$2 where id=$1`,[u.id,tr?'VERIFIED':'UNDER_REVIEW']);n++}return{ok:true,imported:n,skipped:sk}}}
  throw new Error('Unknown action')}

function openApp(opts={}){const {url='http://localhost/',user=null,autoConfirm=false,hash=''}=opts;
  const html=fs.readFileSync(path.join(__dirname,'..','site','index.html'),'utf8').replace(/<script src[^>]*><\/script>/g,'');
  const errs=[],state={user:user?{id:ids[user],email:null}:null,pw:{},uploads:[],resets:[],lsqCalls:[],downloads:[],inflight:0,autoConfirm,catalogFail:opts.catalogFail||null};
  const vc=new VirtualConsole();vc.on('jsdomError',e=>errs.push(String(e.message).slice(0,300)));
  const dom=new JSDOM(html,{url:url+hash,runScripts:'dangerously',pretendToBeVisual:true,virtualConsole:vc,beforeParse(w){w.__NO_AUTO_INIT=true;w.AIMER_CONFIG={url:'https://x.supabase.co',key:'k',siteUrl:'http://localhost'};w.scrollTo=()=>{};w.confirm=()=>true;
    w.HTMLDialogElement.prototype.showModal=function(){this.open=true};w.HTMLDialogElement.prototype.close=function(){this.open=false;this.dispatchEvent(new w.Event('close'))};
    w.addEventListener('unhandledrejection',e=>errs.push('unhandledrejection '+(e.reason&&e.reason.message)));w.navigator.clipboard={writeText:async()=>{}};w.open=u=>{state.opened=u};w.URL.createObjectURL=()=>'blob:x';w.URL.revokeObjectURL=()=>{};const oc=w.HTMLAnchorElement.prototype.click;w.HTMLAnchorElement.prototype.click=function(){if(this.hasAttribute('download')){state.downloads.push(this.download);return}return oc.call(this)}}});
  const w=dom.window,d=w.document;
  const real=w.eval('DB'),mock=makeDB(state);for(const k of Object.keys(mock)){if(k==='auth'){for(const a of Object.keys(mock.auth))real.auth[a]=mock.auth[a]}else real[k]=mock[k]}
  d.addEventListener('click',e=>{const a=e.target.closest&&e.target.closest('a');if(a&&a.getAttribute('href'))e.preventDefault()});
  const api={w,d,state,errs,S:()=>w.eval('S'),
    $:s=>d.querySelector(s),$$:s=>[...d.querySelectorAll(s)],
    async tick(n=6){for(let i=0;i<n;i++)await new Promise(r=>setTimeout(r,25));let quiet=0,guard=0;while(quiet<3&&guard++<200){await new Promise(r=>setTimeout(r,20));quiet=state.inflight===0?quiet+1:0}},
    async click(s){const e=typeof s==='string'?d.querySelector(s):s;if(!e)throw new Error('missing '+s);e.click();await api.tick()},
    async type(id,v){const e=d.getElementById(id);if(!e)throw new Error('no #'+id);e.value=v;e.dispatchEvent(new w.Event('input',{bubbles:true}))},
    async check(id,on=true){const e=d.getElementById(id);if(!e)throw new Error('no #'+id);e.checked=on;e.dispatchEvent(new w.Event('change',{bubbles:true}))},
    async select(s,v){const e=typeof s==='string'?d.querySelector(s):s;e.value=v;e.dispatchEvent(new w.Event('change',{bubbles:true}));await api.tick()},
    nav:()=>[...d.querySelectorAll('.sb-nav [data-act=nav],.sb-foot [data-act=nav]')].map(b=>b.dataset.k),
    toast:()=>d.getElementById('toast').textContent,text:()=>d.getElementById('root').textContent+' '+d.getElementById('dlg').textContent,
    async init(){await w.eval('appInit()');await api.tick(8)},
    async login(email,pw='Pass12345',admin=false){if(admin){w.eval("S.view='adminlogin';render()");await api.tick()}else await api.click('[data-act=goto][data-v=login]');await api.type(admin?'ad-id':'li-id',email);await api.type(admin?'ad-pw':'li-pw',pw);await api.click(admin?'[data-act=alogin]':'[data-act=plogin]');await api.tick(10)},
    async visitAll(){const seen=[];for(const k of api.nav()){await api.click(`[data-act=nav][data-k="${k}"]`);await api.tick(8);if(!d.querySelector('main'))throw new Error('blank '+k);seen.push(k)}return seen}};
  return api}
module.exports={resetDb,as,q,ids,ROLE,openApp,registerHandler,close:async()=>{admin&&admin.release();await pool.end()}};
