// Tests for the fixes made after the PRD and architecture review. Database level, with real roles.
module.exports=async function(H,ok,section){
  const {q,ids,as}=H;
  const code=async id=>(await q('select referral_code from public.partners where id=$1',[id]))[0].referral_code;
  const svc=(sql,p)=>as(null,c=>c.query(sql,p).then(r=>r.rows),'service_role');
  const cap=async(c,course,name,phone,email=null,x={})=>(await svc('select public.capture_referral($1,$2,$3,$4,$5,$6,null,null,$7,false,$8,$9) as v',[c,course,'link',name,phone,email,x.resource||null,!!x.inCrm,!!x.unknown]))[0].v;
  const c1=await code(ids.p1),c2=await code(ids.p2);
  const num=x=>Number(x);
  const UG=(await q("select code from public.courses where code in ('UGBP','UGBIP') and status='Active' limit 1"))[0].code;
  const adv=async(id,adm)=>as(ids.a3,async c=>{await c.query('select public.advance_referral($1)',[id]);await c.query('select public.advance_referral($1)',[id]);await c.query('select public.advance_referral($1,$2)',[id,adm])});
  const fee=async(id,ref)=>as(ids.a4,c=>c.query(`select public.verify_payment($1,'admission_fee',$2)`,[id,ref]));

  section('9. Review fixes: duplicates, validation, CRM uncertainty');
  let r=await cap(c2,UG,'Mail A','+91 91111 00001','dup.mail@x.com');ok(r.credited&&!r.flag&&r.held===false,'a first claim is credited and clean');
  r=await cap(c1,UG,'Mail A again','+91 92222 00002','DUP.Mail@x.com');ok(r.credited&&r.flag==='conflict'&&r.held===true,'the same email under another partner is a conflict held for review');
  r=await cap(c2,UG,'Mail A third','+91 93333 00003','dup.mail@x.com');ok(!r.credited&&r.reason==='duplicate_same_partner','the same partner cannot hold the same email twice');
  r=await cap(c2,UG,'Mail A same phone','+91-91111-00001');ok(!r.credited&&r.reason==='duplicate_same_partner','the same partner cannot hold the same number twice, however it is typed');
  await q(`update public.app_settings set value='"mobile_only"' where key='duplicate_rule'`);
  r=await cap(c1,UG,'Mail B','+91 94444 00004','dup.mail@x.com');ok(r.credited&&!r.flag,'with the rule set to mobile only, a matching email alone is not a conflict');
  await q(`update public.app_settings set value='"mobile_or_email"' where key='duplicate_rule'`);
  r=await cap(c2,UG,'','+91 95555 00005');ok(!r.credited&&r.reason==='invalid','an empty name is refused by the database');
  r=await cap(c2,UG,'x'.repeat(121),'+91 95555 00006');ok(!r.credited&&r.reason==='invalid','an over-long name is refused');
  r=await cap(c2,UG,'Short Phone','+91 123');ok(!r.credited&&r.reason==='invalid','a number that is too short is refused');
  r=await cap(c2,UG,'Bad Mail','+91 96666 00006','not-an-email');ok(!r.credited&&r.reason==='invalid','a malformed email is refused');
  r=await cap(c2,UG,'Ghost Resource','+91 97777 00007',null,{resource:'11111111-1111-1111-1111-111111111111'});
  ok(r.credited&&(await q('select via_resource_id v from public.referrals where id=$1',[r.referral_id]))[0].v===null,'an unknown material id is ignored instead of breaking the save');
  const unk=await cap(c2,UG,'Crm Unknown','+91 98888 00008',null,{unknown:true});
  const ex=await cap(c2,UG,'Crm Exists','+91 98888 00009',null,{inCrm:true});
  const clean=await cap(c2,UG,'Crm Clean','+91 98888 00010');
  const row=async id=>(await q('select flag,attribution,sync_status,policy_version from public.referrals where id=$1',[id]))[0];
  let w=await row(unk.referral_id);ok(unk.flag==='crm_unchecked'&&w.attribution==='review'&&w.sync_status==='held','a failed CRM lookup is flagged as unchecked, put under review and held back');
  w=await row(ex.referral_id);ok(ex.flag==='existing_lead'&&w.sync_status==='held','a lead already in the CRM is held back, not overwritten');
  w=await row(clean.referral_id);ok(!clean.flag&&w.sync_status==='pending'&&w.attribution==='verified','a clean claim is queued to sync');
  let list=(await svc('select public.referrals_to_sync(100,null) as v'))[0].v;
  ok(!list.some(x=>x.ref_no===unk.ref_no)&&list.some(x=>x.ref_no===clean.ref_no),'held claims are not in the retry list');
  await as(ids.a2,c=>c.query('select public.review_attribution($1,$2)',[unk.referral_id,'confirm']));
  list=(await svc('select public.referrals_to_sync(100,null) as v'))[0].v;
  ok(list.some(x=>x.ref_no===unk.ref_no&&x.flag==='crm_unchecked'),'once Marketing confirms, the claim is released to sync and marked as reviewed');
  await svc('select public.hold_referral_for_review($1,$2)',[clean.referral_id,'existing_lead']);
  w=await row(clean.referral_id);ok(w.flag==='existing_lead'&&w.attribution==='review'&&w.sync_status==='held','a CRM check made later on retry can put a claim on hold');
  let denied=0;for(const f of ['hold_referral_for_review','capture_referral']){try{await as(ids.p1,c=>c.query(`select public.${f}(null,null)`))}catch(e){denied++}}ok(denied===2,'signed-in users cannot call the server-only functions');

  section('10. Review fixes: policy version, slab order, recoveries, suspension, audit');
  const cur=(await q('select public.current_policy_version() v'))[0].v;
  const old=await cap(c2,UG,'Old Policy','+91 98888 00011');ok((await row(old.referral_id)).policy_version===cur,'the policy version is stored when the referral is submitted');
  await q(`insert into public.policy_versions(version,note,approved_by) values ($1,'review test',$2)`,[cur+1,ids.a5]);
  await q(`insert into public.incentive_rates(policy_version,course_id,slab,amount) select $1,course_id,slab,amount+1000 from public.incentive_rates where policy_version=$2`,[cur+1,cur]);
  const nu=await cap(c2,UG,'New Policy','+91 98888 00012');ok((await row(nu.referral_id)).policy_version===cur+1,'a referral submitted after a rate change carries the new version');
  await adv(old.referral_id,'AIM/R/001');await adv(nu.referral_id,'AIM/R/002');await fee(old.referral_id,'RCP-OLD');await fee(nu.referral_id,'RCP-NEW');
  const rt=async id=>(await q(`select rate,policy_version from public.reward_transactions where referral_id=$1 and tranche=1`,[id]))[0];
  const ro=await rt(old.referral_id),rn=await rt(nu.referral_id);
  ok(ro.policy_version===cur&&rn.policy_version===cur+1&&num(rn.rate)-num(ro.rate)>=1000-1&&num(rn.rate)!==num(ro.rate),'an older referral keeps its original rate after a rate change ('+ro.rate+' vs '+rn.rate+')');

  const sa=await cap(c1,UG,'Slab A','+91 99111 00001'),sb=await cap(c1,UG,'Slab B','+91 99111 00002');
  await adv(sa.referral_id,'AIM/S/001');await adv(sb.referral_id,'AIM/S/002');
  await Promise.all([fee(sa.referral_id,'RCP-SA'),fee(sb.referral_id,'RCP-SB')]);
  const pos=(await q(`select admission_number n from public.reward_transactions where referral_id in ($1,$2) and tranche=1 order by 1`,[sa.referral_id,sb.referral_id])).map(x=>x.n);
  ok(pos.length===2&&pos[0]!==pos[1]&&pos[1]-pos[0]===1,'two admissions confirmed at the same moment get different, consecutive slab positions ('+pos+')');

  // recoveries are netted from the next batch automatically
  await q(`delete from public.adjustments where partner_id=$1 and status='Open' and kind='recovery'`,[ids.p1]);
  await q(`insert into public.adjustments(partner_id,amount,reason,kind,status,created_by) values ($1,-4000,'Test recovery one','recovery','Open',$2),($1,-2000,'Test recovery two','recovery','Open',$2)`,[ids.p1,ids.a4]);
  const b1=(await as(ids.a4,c=>c.query('select public.prepare_payout_batch() as v'))).rows[0].v;
  const sum=async(sql,p)=>num((await q(sql,p))[0].s);
  const g1=await sum(`select coalesce(sum(amount),0) s from public.reward_transactions where batch_id=$1 and partner_id=$2`,[b1,ids.p1]);
  const a1=await sum(`select coalesce(sum(amount),0) s from public.adjustments where batch_id=$1 and partner_id=$2`,[b1,ids.p1]);
  const tot=await sum(`select total s from public.payout_batches where id=$1`,[b1]);
  const allRewards=await sum(`select coalesce(sum(amount),0) s from public.reward_transactions where batch_id=$1`,[b1]);
  ok(a1===-6000&&tot===allRewards-6000,'both open recoveries are netted into the batch and the total is net ('+a1+', total '+tot+')');
  await as(ids.a5,c=>c.query('select public.decide_payout_batch($1,true)',[b1]));
  const sheet=(await as(ids.a4,c=>c.query('select * from public.get_payout_bank_details($1)',[b1]))).rows.find(x=>x.partner_name==='Fathima Nidha');
  ok(sheet&&num(sheet.amount)===g1-6000,'the payout sheet shows the net amount after recoveries ('+(sheet&&sheet.amount)+')');
  await as(ids.a4,c=>c.query(`select public.record_payout_transfer($1,'NEFT-NET-1')`,[b1]));
  ok((await sum(`select count(*) s from public.adjustments where batch_id=$1 and status='Settled'`,[b1]))===2&&(await sum(`select count(*) s from public.adjustments where partner_id=$1 and status='Open' and kind='recovery'`,[ids.p1]))===0,'recoveries are marked settled when the transfer is recorded');

  // a recovery larger than what is owed is applied in part and the rest stays open
  const sc=await cap(c1,UG,'Slab C','+91 99111 00003');await adv(sc.referral_id,'AIM/S/003');await fee(sc.referral_id,'RCP-SC');
  await q(`insert into public.adjustments(partner_id,amount,reason,kind,status,created_by) values ($1,-999999,'Big recovery','recovery','Open',$2)`,[ids.p1,ids.a4]);
  const b2=(await as(ids.a4,c=>c.query('select public.prepare_payout_batch() as v'))).rows[0].v;
  const g2=await sum(`select coalesce(sum(amount),0) s from public.reward_transactions where batch_id=$1 and partner_id=$2`,[b2,ids.p1]);
  const a2=await sum(`select coalesce(sum(amount),0) s from public.adjustments where batch_id=$1 and partner_id=$2`,[b2,ids.p1]);
  const left=await sum(`select coalesce(sum(amount),0) s from public.adjustments where partner_id=$1 and status='Open' and batch_id is null`,[ids.p1]);
  ok(a2===-g2&&g2>0&&left===-(999999-g2),'a larger recovery is applied only up to what is owed (net never below zero) and the rest stays open ('+a2+' applied, '+left+' left)');
  await as(ids.a5,c=>c.query('select public.decide_payout_batch($1,false)',[b2]));
  ok((await sum(`select count(*) s from public.adjustments where batch_id=$1`,[b2]))===0&&(await sum(`select count(*) s from public.reward_transactions where partner_id=$1 and status='eligible'`,[ids.p1]))>0,'a returned batch releases its netted recoveries and rewards');

  // a suspended partner's rewards are not paid
  await q(`update public.partners set status='SUSPENDED' where id=$1`,[ids.p1]);
  let err='';try{await as(ids.a4,c=>c.query('select public.prepare_payout_batch()'))}catch(e){err=e.message}
  const inB=await sum(`select count(*) s from public.reward_transactions where partner_id=$1 and status='in_batch'`,[ids.p1]);
  ok(inB===0,'a suspended partner’s rewards are left out of new batches'+(err?' ('+err+')':''));
  await q(`update public.partners set status='VERIFIED' where id=$1`,[ids.p1]);

  // audit log and privileges
  let blocked=0;for(const sql of [`insert into public.audit_logs(action) values ('fake')`,`update public.audit_logs set action='x'`,`delete from public.audit_logs`,`truncate public.referrals`]){for(const u of [ids.p1,ids.a2]){try{await as(u,c=>c.query(sql))}catch(e){blocked++}}}
  ok(blocked===8,'no signed-in user, partner or admin, can write or truncate the audit log or tables directly ('+blocked+'/8 blocked)');

  section('11. Scale: rules evaluate once per request, every foreign key is indexed');
  const wrapped=(await q(`select count(*)::int n from pg_policies where schemaname='public' and (coalesce(qual,'')||coalesce(with_check,'')) ~ '(has_role|is_admin|admin_role|auth\\.uid)\\(' and (coalesce(qual,'')||coalesce(with_check,'')) !~* 'select\\s+(public\\.)?(has_role|is_admin|admin_role|auth\\.uid)'`))[0].n;
  ok(wrapped===0,'no security rule runs a role lookup once per row ('+wrapped+' left)');
  const noIdx=(await q(`select count(*)::int n from pg_constraint c where c.contype='f' and c.connamespace='public'::regnamespace and not exists (select 1 from pg_index i where i.indrelid=c.conrelid and (string_to_array(i.indkey::text,' ')::int2[])[1:array_length(c.conkey,1)]=c.conkey)`))[0].n;
  ok(noIdx===0,'every foreign key has an index ('+noIdx+' missing)');
  await q(`insert into public.referrals(partner_id,course_id,campaign_id,source,student_name,phone,stage,attribution,sync_status,policy_version)
           select $1,(select id from public.courses where status='Active' limit 1),null,'link','Bulk '||g,'+9177'||lpad(g::text,8,'0'),4,'verified','ok',1 from generate_series(1,3000) g`,[ids.p2]);
  await q(`insert into public.reward_transactions(referral_id,partner_id,tranche,admission_number,slab,rate,amount,policy_version,status)
           select r.id,r.partner_id,t,1,1,30000,15000,1,'eligible' from public.referrals r, generate_series(1,2) t where r.student_name like 'Bulk %'`);
  const t0=Date.now();const own=await as(ids.p1,c=>c.query('select count(*)::int n from public.reward_transactions').then(r=>r.rows[0].n));const ms=Date.now()-t0;
  ok(ms<1500,'a partner reads their rewards quickly while the table holds 6,000+ rows ('+ms+' ms)');
  const own2=await as(ids.p2,c=>c.query('select count(*)::int n from public.reward_transactions').then(r=>r.rows[0].n));
  ok(own2>=6000&&own<own2,'each partner still sees only their own reward lines ('+own+' for one partner, '+own2+' for the one with bulk data)');
  const fin=await as(ids.a4,c=>c.query('select count(*)::int n from public.reward_transactions').then(r=>r.rows[0].n));
  ok(fin>=own2,'Finance still sees every reward line ('+fin+')');

  section('12. Collisions: double clicks, bank details during a payout, simultaneous batches');
  const dv=await cap(c1,UG,'Double Click','+91 99222 00001');
  const both=await Promise.allSettled([0,1].map(()=>as(ids.a3,c=>c.query('select public.advance_referral($1,null,null,0::smallint)',[dv.referral_id]))));
  const okN=both.filter(x=>x.status==='fulfilled').length,bad=both.filter(x=>x.status==='rejected');
  ok(okN===1&&bad.length===1&&/already moved on/.test(bad[0].reason.message),'two simultaneous clicks on the same stage move the referral once; the second is told to refresh');
  ok((await q('select stage from public.referrals where id=$1',[dv.referral_id]))[0].stage===1,'the referral moved exactly one stage');
  let nf='';try{await as(ids.a3,c=>c.query('select public.advance_referral($1)',['11111111-1111-1111-1111-111111111111']))}catch(e){nf=e.message}
  ok(/Referral not found/.test(nf),'moving a referral that does not exist gives a clear error');

  await q(`update public.reward_transactions set status='paid' where partner_id=$1 and status in ('in_batch','approved')`,[ids.p1]);
  const bank=()=>as(ids.p1,c=>c.query(`select public.set_bank_details('Fathima Nidha','000123456789','HDFC0001234')`));
  let e1='';try{await bank()}catch(e){e1=e.message}
  ok(e1==='','a partner can update their bank details when no payout is in progress ('+e1+')');
  const anyReward=(await q('select id from public.reward_transactions where partner_id=$1 limit 1',[ids.p1]))[0].id;
  await q(`update public.reward_transactions set status='approved' where id=$1`,[anyReward]);
  let e2='';try{await bank()}catch(e){e2=e.message}
  ok(/locked while a payout/.test(e2),'bank details are locked while a payout to the partner is approved or in a batch');
  await q(`update public.reward_transactions set status='paid' where id=$1`,[anyReward]);
  let e3='';try{await bank()}catch(e){e3=e.message}
  ok(e3==='','bank details unlock once the transfer is recorded');

  const ca=await cap(c1,UG,'Conc A','+91 99222 00002');await adv(ca.referral_id,'AIM/C/001');await fee(ca.referral_id,'RCP-CA');
  const batchesBefore=await sum('select count(*) s from public.payout_batches',[]);
  const prep=await Promise.allSettled([0,1].map(()=>as(ids.a4,c=>c.query('select public.prepare_payout_batch() as v'))));
  const made=prep.filter(x=>x.status==='fulfilled'),refused=prep.filter(x=>x.status==='rejected');
  ok(made.length===1&&refused.length===1&&/No eligible payments/.test(refused[0].reason.message),'two Finance users preparing a batch at the same moment create one batch; the other is told nothing is left');
  ok((await sum('select count(*) s from public.payout_batches',[]))===batchesBefore+1&&(await sum(`select count(*) s from public.payout_batches b where b.status='pending' and not exists (select 1 from public.reward_transactions rt where rt.batch_id=b.id)`,[]))===0,'no empty batch is left behind');

  const oldCode=await code(ids.p2);const newCode=(await as(ids.a2,c=>c.query('select public.regenerate_referral_code($1) as v',[ids.p2]))).rows[0].v;
  const au=(await q(`select action from public.audit_logs where action like 'Regenerated referral code%' order by created_at desc limit 1`))[0].action;
  ok(newCode!==oldCode&&au.includes(oldCode)&&au.includes(newCode),'reissuing a code records the old and the new code in the audit log ('+au+')');
  const gone=await cap(oldCode,UG,'Old Link Student','+91 99222 00003');ok(!gone.credited&&gone.reason==='no_partner','the old code stops crediting, as the screen warns');

  section('13. One request to log in and refresh');
  const boot=async(uid)=>(await as(uid,c=>c.query('select public.session_bootstrap() as v').then(x=>x.rows[0].v)));
  const pb=await boot(ids.p1);
  const keys=['courses','campaigns','campaign_courses','policy_versions','incentive_rates','resources','partners','partner_affiliations','notifications','notification_recipients','support_tickets','ticket_messages','referrals','reward_transactions','payout_batches','adjustments','bank','leaderboard','verification'];
  ok(pb.kind==='partner'&&keys.every(k=>Array.isArray(pb[k])),'a partner gets all 19 lists in one response');
  const cnt=async(uid,sql)=>(await as(uid,c=>c.query(sql).then(x=>Number(x.rows[0].n))));
  const same=[['courses','select count(*) n from public.courses'],['campaigns','select count(*) n from public.campaigns'],['partner_affiliations','select count(*) n from public.partner_affiliations'],['reward_transactions','select count(*) n from public.reward_transactions'],['referrals','select count(*) n from public.get_my_referrals()'],['partners','select count(*) n from public.partners'],['resources','select count(*) n from public.resources']];
  let diff=[];for(const [k,sql] of same){const direct=Math.min(1000,await cnt(ids.p1,sql));if(pb[k].length!==direct)diff.push(k+' '+pb[k].length+' vs '+direct)}
  ok(diff.length===0,'every list has exactly the rows the separate requests returned ('+(diff.join('; ')||'all equal')+')');
  ok(pb.partners.length===1&&pb.partners[0].id===ids.p1,'a partner sees only their own record');
  const other=await boot(ids.p2);ok(other.partners.length===1&&other.partners[0].id===ids.p2&&other.referrals.every(r=>JSON.stringify(r).indexOf(ids.p1)<0),'another partner gets their own data, not the first partner’s');
  const ab=await boot(ids.a2);ok(ab.kind==='admin'&&ab.role==='marketing'&&!ab.courses,'an admin is told their role and nothing else is bundled');
  const none=await boot('99999999-9999-9999-9999-999999999999');ok(none.kind==='none','a login with no account is reported as none');
  const nobody=await as(null,c=>c.query('select public.session_bootstrap() as v').then(x=>x.rows[0].v),'authenticated').catch(e=>({err:e.message}));ok((nobody.kind==='none')||!!nobody.err,'a request with no login gets nothing');
  const con=(await q(`select pg_get_constraintdef(oid) d from pg_constraint where conrelid='public.admin_users'::regclass and contype='c' and pg_get_constraintdef(oid) ilike '%status%'`))[0].d;
  const off=(con.match(/'([A-Za-z]+)'/g)||[]).map(x=>x.replace(/'/g,'')).find(x=>x!=='Active')||'Inactive';
  await q(`update public.admin_users set status=$1 where user_id=$2`,[off,ids.a7]);const dead=await boot(ids.a7);await q(`update public.admin_users set status='Active' where user_id=$1`,[ids.a7]);
  ok(dead.kind==='admin_inactive','a deactivated admin is refused');
  let anonErr='';try{await as(null,c=>c.query('select public.session_bootstrap()'),'anon')}catch(e){anonErr=e.message}ok(/permission denied/.test(anonErr),'signed-out visitors cannot call it');

  await q(`insert into auth.users(id,email,raw_user_meta_data,email_confirmed_at) select gen_random_uuid(),'lb'||g||'@aimerbschool.com',jsonb_build_object('account_type','partner','full_name','Board '||g,'phone','+9193'||lpad(g::text,8,'0'),'category','Employee'),now() from generate_series(1,40) g`);
  await q(`insert into public.referrals(partner_id,course_id,source,student_name,phone,stage,attribution,sync_status,policy_version) select p.id,(select id from public.courses where status='Active' limit 1),'link','LB '||p.email,'+9192'||lpad((row_number() over ())::text,8,'0'),0,'verified','ok',1 from public.partners p where p.email like 'lb%@aimerbschool.com'`);
  const lb=await as(ids.p1,c=>c.query('select * from public.get_leaderboard()').then(x=>x.rows));
  ok(lb.length<=21&&lb.some(x=>x.is_me)&&lb.every((x,i)=>i===0||Number(x.rank)>=Number(lb[i-1].rank)),'the leaderboard shows at most the top 20 plus your own row, in rank order ('+lb.length+' rows)');
  const sz=JSON.stringify(await boot(ids.p1)).length;ok(sz<60000,'the login response stays small even with 40+ ranked partners ('+Math.round(sz/1024)+' KB)');
  const a=H.openApp();await a.init();a.state.reqs=0;await a.login('student@x.com');
  const loginReqs=a.state.reqs;ok(/Welcome back/.test(a.text())||a.nav().includes('referrals'),'a partner logs in and sees their dashboard');
  ok(loginReqs<=3,'logging in takes '+loginReqs+' requests (it used to take 23)');
  a.state.reqs=0;await a.click('[data-act=nav][data-k=referrals]');await a.click('[data-act=nav][data-k=home]');
  ok(a.state.reqs<=2,'moving between screens makes no extra requests ('+a.state.reqs+')');
  a.w.close();

  section('13. Instant registration: the real server rules');
  const {register}=await H.registerHandler();
  let created=0,last=null;
  const dep=(ip='9.9.9.9')=>({ip,rpc:async(fn,args)=>{try{const r=await as(null,c=>c.query(`select public.${fn}(${Object.keys(args).map((_,i)=>'$'+(i+1)).join(',')}) as v`,Object.values(args)),'service_role');return{data:r.rows[0].v,error:null}}catch(e){return{data:null,error:e}}},createUser:async u=>{created++;last=u;return{error:null}}});
  const good={name:'Rule Tester',phone:'+91 98000 11111',email:'rule1@aimerbschool.com',password:'secret123',country:'India',category:'Employee'};
  let o=await register({...good,website:'http://spam'},dep());ok(o.status===200&&created===0,'a filled-in hidden field is quietly ignored and creates nothing');
  o=await register({...good,phone:'98000 11111'},dep());ok(o.status===400&&/mobile/.test(o.body.error),'a number without the country code plus sign is refused');
  o=await register({...good,password:'short'},dep());ok(o.status===400&&/8 characters/.test(o.body.error),'a short password is refused');
  o=await register({...good,password:'x'.repeat(73)},dep());ok(o.status===400&&/72/.test(o.body.error),'a password over 72 characters is refused');
  o=await register({...good,category:'Admin'},dep());ok(o.status===400,'an unknown category is refused');
  o=await register({...good,email:'not-an-email'},dep());ok(o.status===400,'a malformed email is refused');
  o=await register({...good,email:'rule2@gmail.com'},dep());ok(o.status===409&&/official AIMER email/.test(o.body.error)&&created===0,'an Employee with a personal email is refused');
  o=await register({...good,account_type:'admin',role:'superadmin'},dep());
  ok(o.status===200&&created===1&&last.email_confirm===true&&last.user_metadata.account_type==='partner'&&!('role' in last.user_metadata)&&!('role' in last),'valid details create a confirmed partner account that can never be an admin');
  for(let i=0;i<5;i++)await register({...good,email:'rl@x.com',phone:'+91 97000 0000'+i,category:'Student'},dep());
  o=await register({...good,email:'rl@x.com',phone:'+91 97000 00009',category:'Student'},dep());ok(o.status===429,'the sixth attempt for the same email within an hour is rate limited');
  o=await register({...good,email:'boom@aimerbschool.com',phone:'+91 96000 00001'},{...dep(),createUser:async()=>({error:{message:'service unavailable'}})});ok(o.status===500,'a failure of the account service is a server error, so the app switches to the email route');
  o=await register({...good,email:'dupe@aimerbschool.com',phone:'+91 96000 00002'},{...dep(),createUser:async()=>({error:{message:'User already registered'}})});ok(o.status===409&&/already exists/.test(o.body.error),'an account created a moment earlier by someone else is reported as already existing');
};
